"""Load API keys from environment variables and create LLM clients."""
import os

import anthropic
import httpx


def _read_key(env_var: str) -> str:
    """Read a key from an environment variable."""
    key = os.environ.get(env_var, "")
    if key:
        return key
    raise EnvironmentError(
        f"Environment variable {env_var} is not set. "
        f"Copy .env.example to .env and fill in your keys, "
        f"then run: export $(cat .env | xargs)"
    )


def get_anthropic_api_key() -> str:
    """Read the Anthropic API key from the environment."""
    return _read_key("ANTHROPIC_API_KEY")


def get_together_api_key() -> str:
    """Read the Together AI API key from the environment."""
    return _read_key("TOGETHER_API_KEY")


def get_openrouter_api_key() -> str:
    """Read the OpenRouter API key from the environment."""
    return _read_key("OPENROUTER_API_KEY")


def make_anthropic_client() -> anthropic.Anthropic:
    """Create an Anthropic client using ANTHROPIC_API_KEY."""
    import urllib.request
    proxies = urllib.request.getproxies()
    proxy_url = proxies.get("https") or proxies.get("http")

    return anthropic.Anthropic(
        api_key=get_anthropic_api_key(),
        http_client=httpx.Client(
            proxy=proxy_url,
            timeout=120.0,
        ),
    )


def make_together_client():
    """Create an OpenAI-compatible client pointing at Together.ai."""
    import openai
    import urllib.request
    proxies = urllib.request.getproxies()
    proxy_url = proxies.get("https") or proxies.get("http")
    http_client = httpx.Client(
        proxy=proxy_url,
        timeout=httpx.Timeout(300.0, connect=10.0),
    )
    return openai.OpenAI(
        api_key=get_together_api_key(),
        base_url="https://api.together.xyz/v1",
        http_client=http_client,
    )


def make_openrouter_client():
    """Create an OpenAI-compatible client pointing at OpenRouter.

    OpenRouter proxies many providers (Anthropic, Together, etc.) via a unified
    OpenAI-compatible API at https://openrouter.ai/api/v1.
    """
    import openai
    import urllib.request
    proxies = urllib.request.getproxies()
    proxy_url = proxies.get("https") or proxies.get("http")
    http_client = httpx.Client(
        proxy=proxy_url,
        timeout=httpx.Timeout(300.0, connect=10.0),
    )
    return openai.OpenAI(
        api_key=get_openrouter_api_key(),
        base_url="https://openrouter.ai/api/v1",
        http_client=http_client,
        default_headers={
            "HTTP-Referer": "https://github.com/tdd-web-agent",
            "X-Title": "tdd-web-agent",
        },
    )
