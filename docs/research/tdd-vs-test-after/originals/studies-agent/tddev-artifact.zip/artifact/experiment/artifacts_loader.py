"""
ArtifactsBench dataset loader.

Fetches samples from the Tencent/ArtifactsBenchmark dataset hosted on
HuggingFace (https://huggingface.co/datasets/tencent/ArtifactsBenchmark)
via the HuggingFace datasets-server REST API — no extra Python dependencies.

Samples are cached in ``data/artifacts_cache.json`` to avoid re-downloading
on every run.

Public API
----------
    samples = fetch_artifacts_samples(n=3, seed=42)

Each sample dict:
    {
        "index":      int,
        "question":   str,   # natural-language requirement
        "checklist":  list[str],  # ground-truth atomic check items
        "class":      str,   # e.g. "Game Development", "Web Applications"
        "difficulty": str,   # "Easy" | "Medium" | "Hard"
    }
"""

import json
import random
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_HF_API = (
    "https://datasets-server.huggingface.co/rows"
    "?dataset=tencent%2FArtifactsBenchmark"
    "&config=default"
    "&split=train"
    "&offset={offset}"
    "&limit={limit}"
)

_CACHE_PATH = Path(__file__).parent.parent / "data" / "artifacts_cache.json"

# Total dataset size — used to decide the fetch window.
# Actual size is 1,825; we only need a small random sample.
_FETCH_LIMIT = 100   # rows to fetch per API call (HF max is 100)
_FETCH_OFFSET = 0    # start of window


# ---------------------------------------------------------------------------
# HuggingFace API helpers
# ---------------------------------------------------------------------------

def _fetch_rows(offset: int = 0, limit: int = _FETCH_LIMIT) -> list[dict]:
    """Fetch raw rows from the HF datasets-server REST API."""
    url = _HF_API.format(offset=offset, limit=limit)
    req = urllib.request.Request(url, headers={"User-Agent": "tdd-web-agent/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read())
    rows = data.get("rows", [])
    return [r["row"] for r in rows]


def _normalise(row: dict) -> dict:
    """Extract the fields we care about from a raw HF row."""
    checklist = row.get("checklist", [])
    # Checklist may arrive as a JSON string on some dataset versions
    if isinstance(checklist, str):
        try:
            checklist = json.loads(checklist)
        except json.JSONDecodeError:
            checklist = [checklist]
    return {
        "index":      row.get("index", -1),
        "question":   row.get("question", ""),
        "checklist":  checklist,
        "class":      row.get("class", "Unknown"),
        "difficulty": row.get("difficulty", "Unknown"),
    }


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _load_cache() -> list[dict]:
    if _CACHE_PATH.exists():
        try:
            return json.loads(_CACHE_PATH.read_text())
        except Exception:
            pass
    return []


def _save_cache(rows: list[dict]) -> None:
    _CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CACHE_PATH.write_text(json.dumps(rows, indent=2))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def fetch_artifacts_samples(n: int = 3, seed: int = 42) -> list[dict]:
    """
    Return *n* ArtifactsBench samples, chosen reproducibly with *seed*.

    Tries local cache first; falls back to the HuggingFace REST API.
    Filters out samples with empty questions or empty checklists.

    Parameters
    ----------
    n : int
        Number of samples to return.
    seed : int
        Random seed for reproducible sampling.

    Returns
    -------
    list[dict]
        Each dict has keys: index, question, checklist, class, difficulty.

    Raises
    ------
    RuntimeError
        If the cache is empty and the HuggingFace API is unreachable.
    """
    rows = _load_cache()

    if not rows:
        try:
            raw = _fetch_rows(offset=_FETCH_OFFSET, limit=_FETCH_LIMIT)
            rows = [_normalise(r) for r in raw]
            rows = [r for r in rows if r["question"] and r["checklist"]]
            _save_cache(rows)
        except (urllib.error.URLError, OSError) as exc:
            raise RuntimeError(
                f"ArtifactsBench cache is empty and HuggingFace API is "
                f"unreachable: {exc}\n"
                f"Run with network access once to populate {_CACHE_PATH}"
            ) from exc

    # Filter out any rows that slipped through without content
    valid = [r for r in rows if r["question"] and r["checklist"]]
    if len(valid) < n:
        raise RuntimeError(
            f"Only {len(valid)} valid ArtifactsBench samples available "
            f"(requested {n})."
        )

    rng = random.Random(seed)
    return rng.sample(valid, n)
