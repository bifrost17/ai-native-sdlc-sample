"""
Phase 5 — Experiment loader.

Loads WebGen-Bench items from a JSONL file, samples N cases with a
reproducible random seed, and joins each sampled item with its pre-converted
structured test cases.

Usage
-----
    from experiment.loader import sample_cases

    cases = sample_cases(
        bench_path     = "data/test.jsonl",
        converted_path = "data/converted_test_cases.jsonl",
        n              = 5,
        seed           = 42,
    )
    # Each case: all original bench fields + "test_cases": [...]
"""

import json
import random
from pathlib import Path


def load_jsonl(path: str) -> list:
    """Load all non-empty lines from a JSONL file as a list of dicts."""
    items = []
    with open(path, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                items.append(json.loads(line))
    return items


def sample_cases(
    bench_path: str,
    converted_path: str,
    n: int = 5,
    seed: int = 42,
) -> list:
    """
    Sample n WebGen-Bench cases and attach their converted test cases.

    Parameters
    ----------
    bench_path     : path to test.jsonl (WebGen-Bench benchmark file)
    converted_path : path to converted_test_cases.jsonl (from preprocess.py)
    n              : number of cases to sample (default 5)
    seed           : random seed for reproducibility (default 42)

    Returns
    -------
    List of dicts. Each dict contains all original bench fields plus
    a ``test_cases`` key with the list of structured test cases for that item.
    Items with no entry in the converted file receive an empty test_cases list.
    """
    items = load_jsonl(bench_path)

    converted_map: dict = {}
    for entry in load_jsonl(converted_path):
        converted_map[entry["id"]] = entry.get("test_cases", [])

    rng = random.Random(seed)
    sampled = rng.sample(items, min(n, len(items)))

    result = []
    for item in sampled:
        item = dict(item)
        item["test_cases"] = converted_map.get(item["id"], [])
        result.append(item)

    return result
