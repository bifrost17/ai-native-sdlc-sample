"""
Preprocessing — convert all WebGen-Bench items to structured test cases.

Runs Tool 1 in convert mode on each item in the benchmark, producing
structured test cases that serve as the fixed input for all experiment
conditions.

Usage
-----
    python -m experiment.preprocess [--bench data/test.jsonl] [--out data/converted_test_cases.jsonl]

Output format (one JSON object per line):
    {"id": "000001", "test_cases": [{test_id, feature, steps, expected}, ...]}
"""

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp_server.tools.test_generation import generate_test_cases


def preprocess(bench_path: str, out_path: str, ids: list[str] | None = None) -> None:
    """Convert WebGen-Bench items to structured test cases via convert mode.

    Parameters
    ----------
    ids : optional list of item IDs to process; if None, all items are processed.
          Already-converted IDs (present in out_path) are always skipped.
    """
    with open(bench_path, encoding="utf-8") as f:
        items = [json.loads(line) for line in f if line.strip()]

    print(f"Loaded {len(items)} items from {bench_path}")

    # Load already-converted IDs to support incremental / append runs
    existing: dict = {}
    if os.path.exists(out_path):
        with open(out_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    entry = json.loads(line)
                    existing[entry["id"]] = entry

    # Filter to requested IDs
    if ids is not None:
        id_set = set(ids)
        items = [item for item in items if item["id"] in id_set]
        print(f"Filtered to {len(items)} requested items")

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)

    # When specific IDs are requested, overwrite them; otherwise skip existing
    if ids is not None:
        # Remove requested IDs from existing so they get re-converted
        for item in items:
            existing.pop(item["id"], None)
        items_to_process = items
    else:
        items_to_process = [item for item in items if item["id"] not in existing]

    print(f"Skipping {len(items) - len(items_to_process)} already-converted items")

    # Re-write full file: existing (minus overwritten) + new
    with open(out_path, "w", encoding="utf-8") as out:
        # Write back existing entries
        for entry in existing.values():
            out.write(json.dumps(entry, ensure_ascii=False) + "\n")

        for i, item in enumerate(items_to_process):
            item_id = item["id"]
            instruction = item["instruction"]
            ui_instruct = item.get("ui_instruct", [])

            if not ui_instruct:
                print(f"  [{i+1}/{len(items_to_process)}] {item_id}: no ui_instruct, skipping")
                continue

            print(f"  [{i+1}/{len(items_to_process)}] {item_id}: converting {len(ui_instruct)} ui_instruct items...")
            try:
                test_cases = generate_test_cases(instruction, ui_instruct)
                entry = {"id": item_id, "test_cases": test_cases}
                out.write(json.dumps(entry, ensure_ascii=False) + "\n")
                out.flush()
                print(f"    -> {len(test_cases)} test cases generated")
            except Exception as exc:
                print(f"    FAILED: {exc}")
                entry = {"id": item_id, "test_cases": [], "error": str(exc)}
                out.write(json.dumps(entry, ensure_ascii=False) + "\n")
                out.flush()

    print(f"Done. Output saved to {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Preprocess WebGen-Bench items")
    parser.add_argument("--bench", default="data/test.jsonl", help="Path to WebGen-Bench JSONL")
    parser.add_argument("--out", default="data/converted_test_cases.jsonl", help="Output path")
    parser.add_argument("--ids", nargs="*", help="Optional list of IDs to process")
    args = parser.parse_args()
    preprocess(args.bench, args.out, ids=args.ids)
