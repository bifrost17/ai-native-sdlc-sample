"""
RQ1.1 — Test Generation Coverage.

Compares generate-mode output against convert-mode reference (ground truth)
using LLM-based semantic matching.

For each sampled WebGen-Bench item:
  1. Load the convert-mode reference test cases (ground truth).
  2. Run generate mode on the instruction alone.
  3. For each reference test case, ask the LLM whether any generated test
     case covers the same feature.
  4. Compute coverage = #matched / #total reference TCs.

Usage
-----
    python -m experiment.rq1_coverage [--bench data/test.jsonl]
                                      [--converted data/converted_test_cases.jsonl]
                                      [--n 10] [--seed 42]
                                      [--out results/rq1_coverage.jsonl]
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import anthropic

from experiment.api_key import make_anthropic_client
from mcp_server.tools.test_generation import generate_test_cases
from experiment.loader import sample_cases
from experiment import token_tracking

# ---------------------------------------------------------------------------
# LLM-based semantic matching
# ---------------------------------------------------------------------------

_MATCH_SYSTEM = """\
You are a test case comparison expert.
Given a REFERENCE test case and a list of GENERATED test cases, determine
whether any generated test case covers the same feature as the reference.

Two test cases cover the same feature if they test substantially the same
user-facing behaviour, even if the wording, step details, or expected
outcomes differ slightly.

Output a JSON object with exactly these keys:
  matched : true or false
  matched_test_id : the test_id of the best-matching generated TC (or null)
  reason : one sentence explaining your decision

Output ONLY the JSON — no prose, no markdown fences.\
"""


def _match_reference_tc(
    ref_tc: dict,
    generated_tcs: list[dict],
    model: str = "claude-sonnet-4-6",
) -> dict:
    """Ask LLM whether any generated TC covers the same feature as *ref_tc*."""
    gen_summary = json.dumps(
        [{"test_id": tc["test_id"], "feature": tc["feature"], "expected": tc["expected"]}
         for tc in generated_tcs],
        indent=2,
    )
    user_text = (
        f"REFERENCE test case:\n"
        f"  feature: {ref_tc['feature']}\n"
        f"  expected: {ref_tc['expected']}\n\n"
        f"GENERATED test cases:\n{gen_summary}\n\n"
        "Does any generated test case cover the same feature as the reference?"
    )

    client = make_anthropic_client()
    resp = client.messages.create(
        model=model,
        max_tokens=256,
        system=_MATCH_SYSTEM,
        messages=[{"role": "user", "content": user_text}],
    )

    # Record tokens
    try:
        token_tracking.record(
            "coverage_match",
            resp.usage.input_tokens,
            resp.usage.output_tokens,
            resp.model,
        )
    except Exception:
        pass

    raw = resp.content[0].text.strip()

    # Parse JSON from response
    import re
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"matched": False, "matched_test_id": None, "reason": f"Parse error: {raw[:100]}"}


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run_coverage(
    bench_path: str,
    converted_path: str,
    n: int = 10,
    seed: int = 42,
    out_path: str = "results/rq1_coverage.jsonl",
) -> dict:
    """Run RQ1.1 coverage experiment."""
    cases = sample_cases(bench_path, converted_path, n=n, seed=seed)
    print(f"Sampled {len(cases)} cases for RQ1.1")

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)

    results = []
    with open(out_path, "w", encoding="utf-8") as out:
        for i, case in enumerate(cases):
            case_id = case["id"]
            instruction = case["instruction"]
            ref_tcs = case.get("test_cases", [])

            if not ref_tcs:
                print(f"  [{i+1}/{len(cases)}] {case_id}: no reference TCs, skipping")
                continue

            print(f"  [{i+1}/{len(cases)}] {case_id}: {len(ref_tcs)} reference TCs")

            # Reset token tracking for this item
            token_tracking.reset()

            # Generate test cases from instruction alone
            try:
                gen_tcs = generate_test_cases(instruction)
                print(f"    Generated {len(gen_tcs)} test cases")
            except Exception as exc:
                print(f"    ✗ generation failed: {exc}")
                gen_tcs = []

            # Match each reference TC against generated TCs
            details = []
            matched_count = 0
            for ref_tc in ref_tcs:
                if not gen_tcs:
                    match_result = {"matched": False, "matched_test_id": None, "reason": "No generated TCs"}
                else:
                    match_result = _match_reference_tc(ref_tc, gen_tcs)

                is_matched = match_result.get("matched", False)
                if is_matched:
                    matched_count += 1

                details.append({
                    "ref_test_id": ref_tc.get("test_id", ""),
                    "ref_feature": ref_tc.get("feature", ""),
                    "matched": is_matched,
                    "matched_gen_id": match_result.get("matched_test_id"),
                    "reason": match_result.get("reason", ""),
                })

            coverage = matched_count / len(ref_tcs) if ref_tcs else 0.0
            tokens = token_tracking.get_totals()

            entry = {
                "case_id": case_id,
                "num_reference_tcs": len(ref_tcs),
                "num_generated_tcs": len(gen_tcs),
                "matched": matched_count,
                "coverage": round(coverage, 4),
                "input_tokens": tokens["input_tokens"],
                "output_tokens": tokens["output_tokens"],
                "details": details,
            }

            out.write(json.dumps(entry, ensure_ascii=False) + "\n")
            out.flush()
            results.append(entry)

            print(f"    Coverage: {matched_count}/{len(ref_tcs)} = {coverage:.1%}")

    # Summary
    if results:
        mean_coverage = sum(r["coverage"] for r in results) / len(results)
        total_inp = sum(r["input_tokens"] for r in results)
        total_out = sum(r["output_tokens"] for r in results)
    else:
        mean_coverage = 0.0
        total_inp = total_out = 0

    summary = {
        "num_cases": len(results),
        "mean_coverage": round(mean_coverage, 4),
        "total_input_tokens": total_inp,
        "total_output_tokens": total_out,
    }
    print(f"\nSummary: {len(results)} cases, mean coverage = {mean_coverage:.1%}")
    print(f"Tokens: {total_inp} input, {total_out} output")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="RQ1.1: Test generation coverage")
    parser.add_argument("--bench", default="data/test.jsonl")
    parser.add_argument("--converted", default="data/converted_test_cases.jsonl")
    parser.add_argument("--n", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    if args.out is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        args.out = f"results/rq1_coverage_{ts}.jsonl"

    run_coverage(args.bench, args.converted, args.n, args.seed, args.out)
