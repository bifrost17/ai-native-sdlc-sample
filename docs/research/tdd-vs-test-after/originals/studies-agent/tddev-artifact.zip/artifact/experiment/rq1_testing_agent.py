"""
RQ1.2 — Testing Agent Accuracy.

Runs the testing agent on 10 controlled fixture applications (each with a
correct and broken variant) and measures verdict agreement against ground
truth.

Each fixture directory contains:
    correct/index.html   — working app
    broken/index.html    — app with one known defect
    test_cases.json      — structured test cases with expected verdicts

Usage
-----
    python -m experiment.rq1_testing_agent [--fixtures tests/fixtures/rq1_apps]
                                           [--out results/rq1_testing_agent.jsonl]
"""

import argparse
import asyncio
import json
import os
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp_server.tools.deployment import start_app, stop_app
from mcp_server.testing_agent.agent import run_test_case
from experiment import token_tracking


async def _run_fixture(
    fixture_dir: str,
    variant: str,
    test_cases: list[dict],
) -> list[dict]:
    """Deploy a fixture variant and run all test cases against it."""
    app_dir = os.path.join(fixture_dir, variant)
    if not os.path.isdir(app_dir):
        print(f"    ✗ directory not found: {app_dir}")
        return []

    # Deploy
    try:
        info = start_app(app_dir)
        app_url = info["url"]
    except Exception as exc:
        print(f"    FAIL deployment failed: {exc}")
        return []

    results = []
    try:
        for tc in test_cases:
            try:
                outcome = await run_test_case(tc, app_url)
                results.append({
                    "test_id": tc["test_id"],
                    "agent_verdict": outcome["result"],
                    "failure_report": outcome.get("failure_report", ""),
                })
            except Exception as exc:
                results.append({
                    "test_id": tc["test_id"],
                    "agent_verdict": "error",
                    "failure_report": str(exc),
                })
    finally:
        try:
            stop_app(app_dir)
        except Exception:
            pass

    return results


async def run_testing_agent_eval(
    fixtures_dir: str = "tests/fixtures/rq1_apps",
    out_path: str = "results/rq1_testing_agent.jsonl",
) -> dict:
    """Run RQ1.2 testing agent accuracy experiment."""
    fixtures_path = Path(fixtures_dir)
    if not fixtures_path.is_dir():
        print(f"Fixtures directory not found: {fixtures_dir}")
        return {"error": "fixtures not found"}

    # Find all fixture directories
    fixture_dirs = sorted([
        d for d in fixtures_path.iterdir()
        if d.is_dir() and (d / "test_cases.json").exists()
    ])
    print(f"Found {len(fixture_dirs)} fixture apps")

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)

    all_entries = []
    with open(out_path, "w", encoding="utf-8") as out:
        for fix_dir in fixture_dirs:
            app_name = fix_dir.name

            # Load test cases
            with open(fix_dir / "test_cases.json", encoding="utf-8") as f:
                meta = json.loads(f.read())

            test_cases = meta["test_cases"]
            defect = meta.get("defect", "unknown")
            print(f"\n[{app_name}] {len(test_cases)} test cases, defect: {defect}")

            # Run on correct variant
            for variant in ["correct", "broken"]:
                print(f"  Running on {variant} variant...")
                token_tracking.reset()
                results = await _run_fixture(str(fix_dir), variant, test_cases)

                tokens = token_tracking.get_totals()

                for tc, result in zip(test_cases, results):
                    expected_key = f"expected_verdict_{variant}"
                    expected = tc.get(expected_key, "unknown")
                    agent_verdict = result["agent_verdict"]
                    correct = (agent_verdict == expected)

                    entry = {
                        "app": app_name,
                        "variant": variant,
                        "test_id": tc["test_id"],
                        "feature": tc.get("feature", ""),
                        "expected_verdict": expected,
                        "agent_verdict": agent_verdict,
                        "correct": correct,
                        "failure_report": result.get("failure_report", ""),
                        "input_tokens": tokens["input_tokens"],
                        "output_tokens": tokens["output_tokens"],
                    }
                    out.write(json.dumps(entry, ensure_ascii=False) + "\n")
                    all_entries.append(entry)

                    status = "PASS" if correct else "FAIL"
                    print(f"    {status} {tc['test_id']}: expected={expected}, got={agent_verdict}")

                out.flush()

    # Summary
    total = len(all_entries)
    correct_count = sum(1 for e in all_entries if e["correct"])
    accuracy = correct_count / total * 100 if total else 0.0

    correct_variant = [e for e in all_entries if e["variant"] == "correct"]
    broken_variant = [e for e in all_entries if e["variant"] == "broken"]

    correct_acc = sum(1 for e in correct_variant if e["correct"]) / len(correct_variant) * 100 if correct_variant else 0.0
    broken_acc = sum(1 for e in broken_variant if e["correct"]) / len(broken_variant) * 100 if broken_variant else 0.0

    # Per-app accuracy
    apps = sorted(set(e["app"] for e in all_entries))
    per_app = {}
    for app in apps:
        app_entries = [e for e in all_entries if e["app"] == app]
        per_app[app] = sum(1 for e in app_entries if e["correct"]) / len(app_entries) * 100

    summary = {
        "total_tests": total,
        "correct": correct_count,
        "overall_accuracy": round(accuracy, 1),
        "correct_variant_accuracy": round(correct_acc, 1),
        "broken_variant_accuracy": round(broken_acc, 1),
        "per_app_accuracy": {k: round(v, 1) for k, v in per_app.items()},
    }

    print(f"\n{'='*60}")
    print(f"RQ1.2 Summary")
    print(f"{'='*60}")
    print(f"Overall accuracy: {correct_count}/{total} = {accuracy:.1f}%")
    print(f"  Correct apps:   {correct_acc:.1f}%")
    print(f"  Broken apps:    {broken_acc:.1f}%")
    for app, acc in per_app.items():
        print(f"  {app}: {acc:.1f}%")

    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="RQ1.2: Testing agent accuracy")
    parser.add_argument("--fixtures", default="tests/fixtures/rq1_apps")
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    if args.out is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        args.out = f"results/rq1_testing_agent_{ts}.jsonl"

    asyncio.run(run_testing_agent_eval(args.fixtures, args.out))
