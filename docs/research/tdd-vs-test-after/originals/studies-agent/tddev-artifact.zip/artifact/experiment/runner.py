"""
Phase 5 — Experiment runner.

Wires together the development protocols (Phase 4) with the MCP tool
implementations (Phases 1–3) and writes per-run JSONL logs (Phase 5 metrics).

Conditions
----------
A — Whole-project (protocol-enforced, tools provided)
B — Incremental   (protocol-enforced, tools provided)
C — Agentic TDD   (tools provided, agent decides; receives TDD knowledge prompt)
D — Baseline      (no tools; dev_agent builds once, then one evaluation pass)

All four conditions share the same JSONL log format so that accuracy@k can be
computed uniformly across them.

Usage
-----
    from experiment.runner import run_case

    summary = run_case(
        case         = {"id": "000001", "instruction": "...", "test_cases": [...]},
        condition    = "A",
        dev_agent    = my_agent,          # .implement(tcs), .fix(report)
        start_app    = lambda: None,       # callable() → None
        run_tests    = lambda tcs: {...},  # returns {"results": [...]}
        log_path     = "results/000001_A.jsonl",
        max_attempts = 5,
    )
    # summary = {"case_id", "condition", "log_path", "final_pass"}

The dev_agent, start_app, and run_tests are injected so that the runner can be
fully exercised without a real browser, LLM, or subprocess in tests.
"""

import json
import os

from protocols.whole_project import run_whole_project
from protocols.incremental import run_incremental
from experiment.metrics import append_log_entry
from experiment import token_tracking


def _make_log_result_wp(case_id: str, condition: str, log_path: str):
    """Return a log_result callable for the whole-project protocol."""
    def log_result(attempt: int, results: dict) -> None:
        tokens = token_tracking.get_totals()
        for r in results["results"]:
            append_log_entry(log_path, {
                "case_id":        case_id,
                "condition":      condition,
                "tc_id":          r["test_id"],
                "attempt":        attempt,
                "result":         r["result"],
                "failure_report": r.get("failure_report", ""),
                "input_tokens":   tokens["input_tokens"],
                "output_tokens":  tokens["output_tokens"],
            })
    return log_result


def _make_log_result_inc(case_id: str, condition: str, log_path: str):
    """Return a log_result callable for the incremental protocol.

    Only logs the result for the current feature being worked on (tc), not
    the full regression suite, so that acc@k correctly reflects per-feature
    pass rate.
    """
    def log_result(tc: dict, attempt: int, results: dict) -> None:
        current_id = tc["test_id"]
        tokens = token_tracking.get_totals()
        for r in results["results"]:
            if r["test_id"] == current_id:
                append_log_entry(log_path, {
                    "case_id":        case_id,
                    "condition":      condition,
                    "tc_id":          r["test_id"],
                    "attempt":        attempt,
                    "result":         r["result"],
                    "failure_report": r.get("failure_report", ""),
                    "input_tokens":   tokens["input_tokens"],
                    "output_tokens":  tokens["output_tokens"],
                })
    return log_result


def run_case(
    case: dict,
    condition: str,
    dev_agent,
    start_app,
    run_tests,
    log_path: str,
    max_attempts: int = 5,
) -> dict:
    """
    Execute one experiment case under the specified condition.

    Parameters
    ----------
    case         : dict with keys: id, instruction, test_cases (list)
    condition    : "A" | "B" | "C" | "D"
    dev_agent    : object with .implement(test_cases) and .fix(report: str)
    start_app    : callable() → None   — deploys the application
    run_tests    : callable(test_cases) → {"results": list[dict]}
    log_path     : file path for the JSONL log (created/appended)
    max_attempts : maximum deploy-test-fix iterations (default 5)

    Returns
    -------
    dict:
        case_id       : str
        condition     : str
        log_path      : str
        final_pass    : bool
        input_tokens  : int  (cumulative tool-side tokens for this run)
        output_tokens : int
        total_tokens  : int
    """
    case_id    = case["id"]
    test_cases = case["test_cases"]

    # Reset token accumulator for this run
    token_tracking.reset()

    # Ensure log file starts fresh for this run
    if os.path.exists(log_path):
        os.remove(log_path)
    os.makedirs(os.path.dirname(os.path.abspath(log_path)), exist_ok=True)

    if condition == "A":
        proto_result = run_whole_project(
            test_cases   = test_cases,
            dev_agent    = dev_agent,
            start_app    = start_app,
            run_tests    = run_tests,
            log_result   = _make_log_result_wp(case_id, condition, log_path),
            max_attempts = max_attempts,
        )
        final_pass = proto_result["final_pass"]

    elif condition == "B":
        proto_result = run_incremental(
            test_cases   = test_cases,
            dev_agent    = dev_agent,
            start_app    = start_app,
            run_tests    = run_tests,
            log_result   = _make_log_result_inc(case_id, condition, log_path),
            max_attempts = max_attempts,
        )
        final_pass = len(proto_result["failed"]) == 0

    elif condition == "C":
        # Agentic TDD: the agent received TDD knowledge in its prompt and decides
        # its own internal workflow. We call implement once (the agent may loop
        # internally), then do a single external evaluation pass.
        dev_agent.implement(test_cases)
        start_app()
        results    = run_tests(test_cases)
        log_result = _make_log_result_wp(case_id, condition, log_path)
        log_result(1, results)
        final_pass = all(r["result"] == "pass" for r in results["results"])

    elif condition == "D":
        # Baseline: dev_agent builds once; no deployment or testing tools.
        # We still run one evaluation pass to measure accuracy for the log.
        dev_agent.implement(test_cases)
        start_app()
        results = run_tests(test_cases)
        log_result = _make_log_result_wp(case_id, condition, log_path)
        log_result(1, results)
        final_pass = all(r["result"] == "pass" for r in results["results"])

    else:
        raise ValueError(f"Unknown condition: {condition!r}. Expected A, B, C, or D.")

    tokens = token_tracking.get_totals()
    return {
        "case_id":       case_id,
        "condition":     condition,
        "log_path":      log_path,
        "final_pass":    final_pass,
        "input_tokens":  tokens["input_tokens"],
        "output_tokens": tokens["output_tokens"],
        "total_tokens":  tokens["total_tokens"],
    }
