"""
Token usage tracking for experiment cost analysis.

Provides a module-level accumulator that LLM call sites append to after each
API response.  The experiment runner resets it before each case × condition
and reads the totals afterwards.

Usage
-----
    from experiment.token_tracking import reset, record, get_totals

    reset()                         # before each run
    # ... LLM calls happen, each calling record() ...
    totals = get_totals()           # {"input_tokens": N, "output_tokens": N, "total_tokens": N}

The accumulator is intentionally global (not thread-local) because the
experiment runner is single-threaded and sequential.
"""


_usage_entries: list[dict] = []


def reset() -> None:
    """Clear the accumulator.  Call before each case × condition run."""
    _usage_entries.clear()


def record(phase: str, input_tokens: int, output_tokens: int, model: str = "") -> None:
    """
    Append one LLM call's token usage.

    Parameters
    ----------
    phase         : "grounding" | "verification" | "generation" | "judge"
    input_tokens  : prompt tokens from ``resp.usage.input_tokens``
    output_tokens : completion tokens from ``resp.usage.output_tokens``
    model         : model identifier (optional, for debugging)
    """
    _usage_entries.append({
        "phase": phase,
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
    })


def get_totals() -> dict:
    """Return aggregated input / output / total token counts."""
    inp = sum(e["input_tokens"] for e in _usage_entries)
    out = sum(e["output_tokens"] for e in _usage_entries)
    return {"input_tokens": inp, "output_tokens": out, "total_tokens": inp + out}


def get_entries() -> list[dict]:
    """Return a copy of all recorded entries (for debugging / fine-grained analysis)."""
    return list(_usage_entries)
