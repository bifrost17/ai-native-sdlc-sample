#!/usr/bin/env python3
"""
Full experiment: 3 benchmark cases × 4 conditions (A, B, C, D).

Dev agent: Claude Code CLI (claude-haiku-4-5-20251001) in isolated temp dirs.

Conditions
----------
A  Whole-project  standard prompt,  deploy→test→fix loop (max 5)
B  Incremental    standard prompt,  per-feature loop (max 5)
C  Whole-project  TDD-enhanced prompt, same loop as A
D  Baseline       standard prompt,  implement once → test once, no fix loop

Cases (first 3 from fixtures)
-------------------------------
000001  Todo list     — add task
000002  Calculator    — add two numbers
000003  Weather app   — city search

Output
------
results/experiment_<ts>/
    experiment.log          full DEBUG log
    case_<id>_<cond>.jsonl  per-run attempt log (12 files)
    summary.json            accuracy@k + final_pass per condition
    report.md               human-readable table + per-case detail

Usage
-----
    cd tdd-web-agent
    python full_experiment.py
"""

import asyncio
import json
import logging
import os
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

_SESSION_TOKEN_PATH = Path("/home/claude/.claude/remote/.session_ingress_token")

if not os.environ.get("ANTHROPIC_API_KEY") and not os.environ.get("ANTHROPIC_AUTH_TOKEN"):
    if _SESSION_TOKEN_PATH.exists():
        os.environ["ANTHROPIC_AUTH_TOKEN"] = _SESSION_TOKEN_PATH.read_text().strip()
    else:
        sys.exit(
            "ERROR: Set ANTHROPIC_API_KEY or ANTHROPIC_AUTH_TOKEN, "
            "or ensure the session token file exists."
        )

# ---------------------------------------------------------------------------
# Output directory + logging
# ---------------------------------------------------------------------------

_TS      = datetime.now().strftime("%Y%m%d_%H%M%S")
RESULTS  = Path(__file__).parent / "results" / f"experiment_{_TS}"
RESULTS.mkdir(parents=True, exist_ok=True)

LOG_FILE = RESULTS / "experiment.log"

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)-8s %(name)-28s %(message)s",
    handlers=[
        logging.FileHandler(str(LOG_FILE)),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("full_experiment")

# ---------------------------------------------------------------------------
# Project imports (after logging is configured)
# ---------------------------------------------------------------------------

from experiment.loader import load_jsonl
from experiment.runner import run_case
from experiment.metrics import load_log, summarize
from mcp_server.tools.deployment import start_app as _start_app, stop_app as _stop_app
from mcp_server.testing_agent.agent import run_test_case

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

_CLAUDE_MODEL  = "claude-haiku-4-5-20251001"
_MAX_ATTEMPTS  = 5
_N_CASES       = 3          # 000001 – 000003
_CONDITIONS    = ["A", "B", "C", "D"]

# ---------------------------------------------------------------------------
# Async helper (single event loop, used only from the main thread)
# ---------------------------------------------------------------------------

_LOOP = asyncio.new_event_loop()
asyncio.set_event_loop(_LOOP)


def _run(coro):
    return _LOOP.run_until_complete(coro)

# ---------------------------------------------------------------------------
# Implement / fix prompts
# ---------------------------------------------------------------------------

_IMPLEMENT_ALL = """\
You are building a web application. Create a complete, working Express.js app
that satisfies ALL of the following test cases.

Instruction: {instruction}

Test cases to satisfy:
{test_cases_json}

Requirements:
- Create package.json with express as a dependency and "start": "node server.js"
- Create server.js that listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / that has all UI elements the tests need
- Run `npm install` after creating the files
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)
"""

_IMPLEMENT_ALL_TDD = """\
You are building a web application using Test-Driven Development (TDD).

Approach: red → green → refactor.
1. Read each test case carefully to understand exactly what the browser will do.
2. Write the *minimal* Express.js code that makes that test pass.
3. Do not add features beyond what the tests require.

Instruction: {instruction}

Test cases to satisfy:
{test_cases_json}

Requirements:
- Create package.json with express as a dependency and "start": "node server.js"
- Create server.js that listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / with exactly the UI elements the tests need
- Run `npm install` after creating the files
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)
"""

_IMPLEMENT_FEATURE = """\
You are building a web application incrementally. Add the following feature to
the app in this directory. If no app exists yet, create the full Express.js
scaffold plus this feature.

Overall instruction: {instruction}

Feature to implement now:
{tc_json}

Requirements:
- package.json must have express as dependency and "start": "node server.js"
- server.js listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / containing the UI elements for this feature
- Run `npm install` if you create or update package.json
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)
- Do not break any previously passing features
"""

_FIX = """\
The automated browser tests failed. Fix the app in this directory so the
tests pass.

Failure report:
{report}

Instructions:
- Read the existing server.js (and any other files) to understand the current state
- Make the minimal changes needed to fix the failures
- Do not remove any existing passing functionality
- Run `npm install` if you change package.json
"""

# ---------------------------------------------------------------------------
# Dev agent
# ---------------------------------------------------------------------------

class ClaudeCodeDevAgent:
    """
    Dev agent backed by the Claude Code CLI.

    tdd=False  → standard prompts (conditions A, B, D)
    tdd=True   → TDD-enhanced implement prompt (condition C)
    """

    def __init__(self, project_dir: str, instruction: str, tdd: bool = False) -> None:
        self.project_dir = project_dir
        self.instruction = instruction
        self.tdd         = tdd

    def implement(self, test_cases) -> None:
        if isinstance(test_cases, dict):
            # Incremental: single feature
            prompt = _IMPLEMENT_FEATURE.format(
                instruction=self.instruction,
                tc_json=json.dumps(test_cases, indent=2),
            )
            label = f"feature {test_cases.get('test_id','?')}"
        else:
            # Whole-project: all features
            tmpl  = _IMPLEMENT_ALL_TDD if self.tdd else _IMPLEMENT_ALL
            prompt = tmpl.format(
                instruction=self.instruction,
                test_cases_json=json.dumps(test_cases, indent=2),
            )
            label = f"{len(test_cases)} TC(s) {'[TDD]' if self.tdd else ''}"
        log.info("agent.implement(%s)", label)
        self._call_claude(prompt, phase="implement")

    def fix(self, report: str) -> None:
        log.info("agent.fix()")
        log.debug("Failure report:\n%s", report)
        self._call_claude(_FIX.format(report=report), phase="fix")

    def _call_claude(self, prompt: str, phase: str) -> None:
        cmd = [
            "claude", "-p",
            "--model", _CLAUDE_MODEL,
            "--permission-mode", "acceptEdits",
            "--allowed-tools", "Edit,Write,Read,Glob,Grep,Bash",
            "--no-session-persistence",
            prompt,
        ]
        log.debug("claude %s: %s … <prompt>", phase, " ".join(cmd[2:6]))
        t0 = time.monotonic()
        result = subprocess.run(
            cmd,
            cwd=self.project_dir,
            capture_output=True,
            text=True,
            timeout=360,
            env={**os.environ},
        )
        elapsed = time.monotonic() - t0
        log.info(
            "claude exit=%d  phase=%-9s  %.1fs  stdout=%d chars  stderr=%d chars",
            result.returncode, phase, elapsed, len(result.stdout), len(result.stderr),
        )
        if result.stdout:
            log.debug("claude stdout [%s]:\n%s", phase, result.stdout)
        if result.stderr:
            log.debug("claude stderr [%s]:\n%s", phase, result.stderr)
        if result.returncode != 0:
            log.warning("claude exited %d during %s", result.returncode, phase)

# ---------------------------------------------------------------------------
# Adapters
# ---------------------------------------------------------------------------

def make_adapters(project_dir: str):
    url_box: list = [None, ""]   # [url_or_None, error_msg]

    def start_app_fn() -> None:
        log.info("stop→start  dir=%s", project_dir)
        _stop_app(project_dir)
        try:
            info = _start_app(project_dir)
            url_box[0] = info["url"]
            url_box[1] = ""
            log.info("App running  url=%s  port=%s", info["url"], info["port"])
        except Exception as exc:
            url_box[0] = None
            url_box[1] = str(exc)
            log.error("start_app FAILED: %s", exc)

    def run_tests_fn(test_cases) -> dict:
        if isinstance(test_cases, dict):
            test_cases = [test_cases]
        if url_box[0] is None:
            log.warning("Server not running — marking %d TC(s) as fail", len(test_cases))
            return {"results": [
                {
                    "test_id":        tc["test_id"],
                    "result":         "fail",
                    "failure_report": f"Server failed to start: {url_box[1]}",
                    "trajectory":     [],
                }
                for tc in test_cases
            ]}
        app_url = url_box[0]
        log.info("run_tests  url=%s  tcs=%d", app_url, len(test_cases))
        results = []
        for tc in test_cases:
            log.info("  TC %s — %s", tc["test_id"], tc["feature"])
            outcome = _run(run_test_case(tc, app_url))
            log.info("  TC %s → %s", tc["test_id"], outcome["result"])
            if outcome["failure_report"]:
                log.warning("  TC %s failure: %s", tc["test_id"], outcome["failure_report"])
            results.append({
                "test_id":        tc["test_id"],
                "result":         outcome["result"],
                "failure_report": outcome["failure_report"],
                "trajectory":     outcome["trajectory"],
            })
        return {"results": results}

    return start_app_fn, run_tests_fn

# ---------------------------------------------------------------------------
# Single-run helper
# ---------------------------------------------------------------------------

def run_one(case: dict, condition: str) -> dict:
    """
    Run one (case × condition) in a fresh temp dir.
    Returns {"case_id", "condition", "final_pass", "metrics", "log_path"}.
    """
    case_id    = case["id"]
    log_path   = str(RESULTS / f"case_{case_id}_{condition}.jsonl")
    tdd_flag   = (condition == "C")

    _banner(f"case {case_id}  condition {condition}  model {_CLAUDE_MODEL}")
    log.info("Instruction: %s", case["instruction"])
    log.info("Test cases:  %s", json.dumps(case["test_cases"]))

    with tempfile.TemporaryDirectory(prefix=f"exp_{case_id}_{condition}_") as tmpdir:
        agent                  = ClaudeCodeDevAgent(tmpdir, case["instruction"], tdd=tdd_flag)
        start_app_fn, run_tests_fn = make_adapters(tmpdir)

        try:
            summary = run_case(
                case         = case,
                condition    = condition,
                dev_agent    = agent,
                start_app    = start_app_fn,
                run_tests    = run_tests_fn,
                log_path     = log_path,
                max_attempts = _MAX_ATTEMPTS,
            )
        finally:
            _stop_app(tmpdir)

    entries = load_log(log_path)
    metrics = summarize(entries, max_k=_MAX_ATTEMPTS)
    log.info(
        "DONE  case=%s  cond=%s  final_pass=%s  acc@1=%.0f%%  acc@5=%.0f%%",
        case_id, condition, summary["final_pass"],
        metrics.get("accuracy@1", 0), metrics.get("accuracy@5", 0),
    )
    return {
        "case_id":    case_id,
        "condition":  condition,
        "final_pass": summary["final_pass"],
        "metrics":    metrics,
        "log_path":   log_path,
    }

# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

def _banner(msg: str) -> None:
    bar = "=" * 64
    log.info("\n%s\n  %s\n%s", bar, msg, bar)


def build_summary(all_results: list) -> dict:
    """
    Returns:
      {
        "per_condition": {
          "A": {
            "never_passed": int,
            "n_eventually_passed": int,
            "accuracy@1": float, ...,   # averaged over eventually-passed cases only
            "final_pass_rate": "2/3",
          },
          ...
        },
        "per_case_condition": {
          "000001": {"A": {...}, "B": {...}, ...},
          ...
        }
      }

    Cases that never pass are counted separately in "never_passed".
    acc@k is averaged only over cases that eventually pass (final_pass=True).
    """
    per_cond: dict = {c: [] for c in _CONDITIONS}
    for r in all_results:
        per_cond[r["condition"]].append(r)

    cond_summary = {}
    for cond, runs in per_cond.items():
        if not runs:
            continue
        eventually_passed = [r for r in runs if r["final_pass"]]
        n_never           = len(runs) - len(eventually_passed)
        n_eventually      = len(eventually_passed)

        # Average acc@k only over eventually-passed cases
        metrics: dict = {}
        for k in range(1, _MAX_ATTEMPTS + 1):
            key = f"accuracy@{k}"
            if n_eventually > 0:
                metrics[key] = (
                    sum(r["metrics"].get(key, 0.0) for r in eventually_passed)
                    / n_eventually
                )
            else:
                metrics[key] = 0.0

        metrics["never_passed"]       = n_never
        metrics["n_eventually_passed"] = n_eventually
        metrics["final_pass_rate"]     = f"{n_eventually}/{len(runs)}"
        cond_summary[cond] = metrics

    # Per-case breakdown
    per_case: dict = {}
    for r in all_results:
        per_case.setdefault(r["case_id"], {})[r["condition"]] = {
            "final_pass": r["final_pass"],
            **r["metrics"],
        }

    return {"per_condition": cond_summary, "per_case_condition": per_case}


_COND_LABELS = {
    "A": "fix loop",
    "B": "incremental",
    "C": "single-shot, agentic TDD",
    "D": "baseline, no loop",
}


def write_report(summary: dict, all_results: list) -> Path:
    """Write markdown report; return path."""
    report_path = RESULTS / "report.md"
    lines = []

    lines.append(f"# Experiment Results\n")
    lines.append(f"**Model:** `{_CLAUDE_MODEL}`  |  "
                 f"**Cases:** {_N_CASES}  |  "
                 f"**Conditions:** {', '.join(_CONDITIONS)}  |  "
                 f"**Max attempts:** {_MAX_ATTEMPTS}\n")
    lines.append(f"**Run:** `{_TS}`\n")

    bench = {e["id"]: e for e in load_jsonl("tests/fixtures/sample_bench.jsonl")}

    # -----------------------------------------------------------------------
    # Per-condition blocks
    # -----------------------------------------------------------------------
    for cond in _CONDITIONS:
        m            = summary["per_condition"].get(cond, {})
        never_passed = m.get("never_passed", 0)
        n_eventually = m.get("n_eventually_passed", 0)
        label        = _COND_LABELS.get(cond, cond)

        never_passed_ids = sorted(
            r["case_id"] for r in all_results
            if r["condition"] == cond and not r["final_pass"]
        )
        if never_passed == 0:
            np_note = f"never-passed: **{never_passed}**"
        elif never_passed == 1:
            np_note = f"never-passed: **{never_passed}** (case {never_passed_ids[0]})"
        else:
            np_note = (
                f"never-passed: **{never_passed}** "
                f"(cases {', '.join(never_passed_ids)})"
            )

        lines.append(f"**Condition {cond}** ({label}) — {np_note}\n")

        eventually_runs = sorted(
            (r for r in all_results if r["condition"] == cond and r["final_pass"]),
            key=lambda r: r["case_id"],
        )

        if cond in ("A", "B"):
            lines.append("| Case | pass at attempt | acc@1 | acc@2 | acc@3 | acc@4 | acc@5 |")
            lines.append("|------|----------------|-------|-------|-------|-------|-------|")
            for r in eventually_runs:
                pass_at = "—"
                for k in range(1, _MAX_ATTEMPTS + 1):
                    if r["metrics"].get(f"accuracy@{k}", 0) > 0:
                        pass_at = str(k)
                        break
                acc_vals = " | ".join(
                    f"{r['metrics'].get(f'accuracy@{k}', 0):.0f}%"
                    for k in range(1, _MAX_ATTEMPTS + 1)
                )
                lines.append(f"| {r['case_id']} | {pass_at} | {acc_vals} |")
            avg_vals = " | ".join(
                f"{m.get(f'accuracy@{k}', 0):.0f}%"
                for k in range(1, _MAX_ATTEMPTS + 1)
            )
            lines.append(f"| **avg (n={n_eventually})** | | {avg_vals} |")
        else:
            lines.append("| Case | accuracy |")
            lines.append("|------|----------|")
            if never_passed == 0:
                lines.append(f"| all {n_eventually} | {m.get('accuracy@1', 0):.0f}% |")
            else:
                for r in eventually_runs:
                    lines.append(f"| {r['case_id']} | {r['metrics'].get('accuracy@1', 0):.0f}% |")
            lines.append(f"| **avg (n={n_eventually})** | {m.get('accuracy@1', 0):.0f}% |")

        lines.append("")

    # -----------------------------------------------------------------------
    # Consolidated Summary
    # -----------------------------------------------------------------------
    lines.append("## Consolidated Summary\n")
    lines.append(
        "| Condition | never-passed | n (eventually passed) "
        "| acc@1 | acc@2 | acc@3 | acc@4 | acc@5 |"
    )
    lines.append(
        "|-----------|-------------|----------------------"
        "|-------|-------|-------|-------|-------|"
    )
    for cond in _CONDITIONS:
        m   = summary["per_condition"].get(cond, {})
        np_ = m.get("never_passed", 0)
        ne  = m.get("n_eventually_passed", 0)
        if cond in ("A", "B"):
            acc_cells = " | ".join(
                f"{m.get(f'accuracy@{k}', 0):.0f}%"
                for k in range(1, _MAX_ATTEMPTS + 1)
            )
        else:
            # Single-shot: acc@1 shown only when never_passed == 0 (unbiased)
            acc1 = f"{m.get('accuracy@1', 0):.0f}%" if np_ == 0 else "—"
            acc_cells = f"{acc1} | — | — | — | —"
        lines.append(f"| {cond} | {np_} | {ne} | {acc_cells} |")
    lines.append("")

    # -----------------------------------------------------------------------
    # Step-by-step log summary per run
    # -----------------------------------------------------------------------
    lines.append("## Step-by-Step Log (per run)\n")
    for r in sorted(all_results, key=lambda x: (x["case_id"], x["condition"])):
        case_id = r["case_id"]
        cond    = r["condition"]
        app     = bench.get(case_id, {}).get("application_type", "?")
        entries = load_log(r["log_path"])
        lines.append(f"### Case {case_id} ({app}) — Condition {cond}\n")
        if not entries:
            lines.append("_No log entries._\n")
            continue
        lines.append("| attempt | TC | result | failure_report |")
        lines.append("|---------|-----|--------|----------------|")
        for e in entries:
            fr = (e.get("failure_report") or "")[:100].replace("|", "\\|")
            lines.append(
                f"| {e['attempt']} | {e['tc_id']} | {e['result']} | {fr} |"
            )
        lines.append("")

    report_path.write_text("\n".join(lines))
    return report_path

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    _banner(f"FULL EXPERIMENT START  model={_CLAUDE_MODEL}")
    log.info("Results dir: %s", RESULTS)

    # Load cases
    bench     = {e["id"]: e for e in load_jsonl("tests/fixtures/sample_bench.jsonl")}
    converted = {e["id"]: e.get("test_cases", [])
                 for e in load_jsonl("tests/fixtures/sample_converted.jsonl")}

    # Pick first _N_CASES by sorted ID
    case_ids = sorted(bench.keys())[:_N_CASES]
    cases = []
    for cid in case_ids:
        c = dict(bench[cid])
        c["test_cases"] = converted.get(cid, [])
        cases.append(c)
        log.info("Case %s: %s  (%d TCs)", cid, c["instruction"], len(c["test_cases"]))

    # Run all (case × condition) combinations sequentially
    all_results = []
    total       = len(cases) * len(_CONDITIONS)
    done        = 0

    for case in cases:
        for condition in _CONDITIONS:
            done += 1
            log.info("▶ Run %d/%d  case=%s  cond=%s", done, total, case["id"], condition)
            result = run_one(case, condition)
            all_results.append(result)

    # Summarise + report
    _banner("EXPERIMENT COMPLETE")
    summary      = build_summary(all_results)
    summary_path = RESULTS / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2))

    report_path  = write_report(summary, all_results)

    # Print final table to stdout
    log.info("\n%s", Path(report_path).read_text())
    log.info("Summary JSON → %s", summary_path)
    log.info("Report MD    → %s", report_path)
    log.info("Full log     → %s", LOG_FILE)


if __name__ == "__main__":
    main()
