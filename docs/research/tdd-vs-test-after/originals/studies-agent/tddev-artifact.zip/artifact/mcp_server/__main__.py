import asyncio
from mcp_server.server import _main

asyncio.run(_main())
