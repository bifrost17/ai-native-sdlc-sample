"""
Phase 6 — MCP Server.

Registers three logical tools (five callable names) with the Python MCP SDK
and exposes them via stdio transport.

Entry point:
    python -m mcp_server.server

Tools
-----
[Tool 1] generate_test_cases
    generate_test_cases(requirements, ui_instruct?)
        requirements  : str  — natural language spec (WebGen-Bench instruction)
        ui_instruct   : list — optional WebGen-Bench ui_instruct entries
                               (omit for generate mode, provide for convert mode)
    Returns: JSON array of structured test cases

[Tool 2] deployment — three callables:
    start_app(project_dir, port?, timeout?)
        project_dir : str  — absolute path to the app directory
        port        : int  — optional override (default: framework default)
        timeout     : int  — seconds to wait for the port (default: 30)
    Returns: JSON {"url", "port", "framework"}

    stop_app(project_dir)
        project_dir : str
    Returns: JSON {"stopped": true}

    detect_framework(project_dir)
        project_dir : str
    Returns: JSON {"framework", "dev_command", "default_port"}

[Tool 3] run_tests
    run_tests(test_cases, app_url)
        test_cases : list — structured test case dicts
        app_url    : str  — base URL of the deployed app
    Returns: JSON {"results": [{test_id, result, failure_report, trajectory}]}
"""

import asyncio
import json
import sys

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

from mcp_server.tools.test_generation import generate_test_cases as _generate_test_cases
from mcp_server.tools.deployment import (
    start_app as _start_app,
    stop_app as _stop_app,
    detect_framework as _detect_framework,
)
from mcp_server.testing_agent.agent import run_test_case as _run_test_case

# ---------------------------------------------------------------------------
# Server instance
# ---------------------------------------------------------------------------

server = Server("tdd-web-agent")

# ---------------------------------------------------------------------------
# Tool schemas
# ---------------------------------------------------------------------------

_TOOLS = [
    types.Tool(
        name="generate_test_cases",
        description=(
            "Generate structured test cases from natural language requirements. "
            "In generate mode (no ui_instruct), uses chain-of-thought to identify "
            "features and produce one test case per feature. "
            "In convert mode (ui_instruct provided), converts each WebGen-Bench "
            "ui_instruct entry into a structured test case."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "requirements": {
                    "type": "string",
                    "description": "Natural language requirements for the web application.",
                },
                "ui_instruct": {
                    "type": "array",
                    "description": (
                        "Optional. WebGen-Bench ui_instruct entries "
                        "({'task': str, 'expected_result': str}). "
                        "Omit to run in generate mode."
                    ),
                    "items": {"type": "object"},
                },
            },
            "required": ["requirements"],
        },
    ),
    types.Tool(
        name="start_app",
        description=(
            "Start the development server for a web application. "
            "Detects the framework from package.json, spawns the dev server, "
            "and waits until the port is reachable. "
            "Returns {url, port, framework}."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_dir": {
                    "type": "string",
                    "description": "Absolute path to the project directory.",
                },
                "port": {
                    "type": "integer",
                    "description": "Optional port override. Defaults to framework default.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Seconds to wait for the port to open. Default: 30.",
                },
            },
            "required": ["project_dir"],
        },
    ),
    types.Tool(
        name="stop_app",
        description="Stop the development server previously started for a project directory.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_dir": {
                    "type": "string",
                    "description": "Absolute path to the project directory.",
                },
            },
            "required": ["project_dir"],
        },
    ),
    types.Tool(
        name="detect_framework",
        description=(
            "Read package.json in a project directory and identify the frontend framework. "
            "Returns {framework, dev_command, default_port}."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_dir": {
                    "type": "string",
                    "description": "Absolute path to the project directory.",
                },
            },
            "required": ["project_dir"],
        },
    ),
    types.Tool(
        name="run_tests",
        description=(
            "Deploy and test your app. For each test case: starts a fresh server, "
            "runs the browser test, stops the server. Returns pass/fail/partial per test. "
            "Pass all test cases or just the ones you are currently fixing."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_dir": {
                    "type": "string",
                    "description": "Absolute path to the project directory.",
                },
                "test_cases": {
                    "type": "array",
                    "description": (
                        "List of structured test case dicts "
                        "({test_id, feature, steps, expected}). "
                        "Can be the full list or a subset."
                    ),
                    "items": {"type": "object"},
                },
            },
            "required": ["project_dir", "test_cases"],
        },
    ),
]

# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return _TOOLS


@server.call_tool(validate_input=False)
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    """
    Dispatch a tool call and return a JSON text response.

    All errors are caught and returned as JSON {"error": str} so the server
    never crashes on a bad call.
    """
    try:
        result = await _dispatch(name, arguments)
        return [types.TextContent(type="text", text=json.dumps(result))]
    except Exception as exc:
        return [types.TextContent(
            type="text",
            text=json.dumps({"error": str(exc), "tool": name}),
        )]


async def _dispatch(name: str, arguments: dict):
    """Route a tool call to the appropriate implementation."""

    if name == "generate_test_cases":
        requirements = arguments.get("requirements")
        if requirements is None:
            raise ValueError("Missing required argument: 'requirements'")
        ui_instruct = arguments.get("ui_instruct")
        return _generate_test_cases(requirements, ui_instruct)

    elif name == "start_app":
        project_dir = arguments.get("project_dir")
        if project_dir is None:
            raise ValueError("Missing required argument: 'project_dir'")
        kwargs = {}
        if "port" in arguments:
            kwargs["port"] = arguments["port"]
        if "timeout" in arguments:
            kwargs["timeout"] = arguments["timeout"]
        return _start_app(project_dir, **kwargs)

    elif name == "stop_app":
        project_dir = arguments.get("project_dir")
        if project_dir is None:
            raise ValueError("Missing required argument: 'project_dir'")
        _stop_app(project_dir)
        return {"stopped": True}

    elif name == "detect_framework":
        project_dir = arguments.get("project_dir")
        if project_dir is None:
            raise ValueError("Missing required argument: 'project_dir'")
        return _detect_framework(project_dir)

    elif name == "run_tests":
        project_dir = arguments.get("project_dir")
        test_cases  = arguments.get("test_cases")
        if project_dir is None:
            raise ValueError("Missing required argument: 'project_dir'")
        if test_cases is None:
            raise ValueError("Missing required argument: 'test_cases'")
        results = []
        for tc in test_cases:
            # Per-TC restart: fresh server for each test case, independent evaluation
            _stop_app(project_dir)
            info = _start_app(project_dir)
            outcome = await _run_test_case(tc, info["url"])
            results.append({
                "test_id":        tc.get("test_id"),
                "result":         outcome["result"],
                "failure_report": outcome["failure_report"],
                "trajectory":     outcome["trajectory"],
            })
        _stop_app(project_dir)  # cleanup after last TC
        return {"results": results}

    else:
        raise ValueError(f"Unknown tool: {name!r}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


async def _main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


if __name__ == "__main__":
    asyncio.run(_main())
