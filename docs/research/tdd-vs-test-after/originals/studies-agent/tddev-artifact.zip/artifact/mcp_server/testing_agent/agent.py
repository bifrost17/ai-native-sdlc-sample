"""
Phase 3 — Testing Agent (unified agent loop).

Executes a single structured test case against a deployed web app URL.
The LLM drives the browser end-to-end: it sees the full test context,
trajectory so far, and current page state each iteration, and decides
whether to execute an action or issue a verdict.

Supports two providers (controlled by TESTING_AGENT_PROVIDER env var):
  - "anthropic" (default) — uses the Anthropic SDK
  - "together"            — uses the OpenAI SDK pointed at Together.ai

Public API
----------
    result = await run_test_case(test_case, app_url)

    result = {
        "result":         "pass" | "fail" | "partial",
        "trajectory":     [{"step": str, "action": dict|None,
                            "status": "executed"|"failed",
                            "reason": str}],   # reason only on failed entries
        "failure_report": str,   # empty string on pass
    }
"""

import json
import os
import re

import anthropic

from experiment.api_key import make_anthropic_client, make_together_client, make_openrouter_client
from mcp_server.testing_agent.browser import BrowserSession

# ---------------------------------------------------------------------------
# Model & provider choice — override via env vars
# ---------------------------------------------------------------------------

_MODEL = os.environ.get("TESTING_AGENT_MODEL", "claude-haiku-4-5-20251001")
_PROVIDER = os.environ.get("TESTING_AGENT_PROVIDER", "anthropic")  # "anthropic" | "together" | "openrouter"

_MAX_ITERATIONS = 8
_SCREENSHOTS = os.environ.get("TESTING_AGENT_SCREENSHOTS", "0") != "0"

# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------

_AGENT_SYSTEM = """\
You are a web application testing agent. You interact with a browser to execute
a test case and determine whether the application behaves correctly.

## Available actions (respond with ONE JSON object)

Execute a browser action:
  {"action": "click",    "selector": "CSS selector or text=Label"}
  {"action": "fill",     "selector": "CSS selector", "value": "text to type"}
  {"action": "press",    "key": "Enter"}
  {"action": "navigate", "url": "https://..."}

Terminate with a verdict:
  {"verdict": "pass",    "reason": "brief explanation"}
  {"verdict": "fail",    "reason": "brief explanation"}
  {"verdict": "partial", "reason": "brief explanation"}

## Selector tips
- Prefer #id selectors when available in the accessibility tree.
- Use text=Button Text for buttons/links without ids.
- For inputs, use label[for=...] or input[placeholder=...].

## Rules
1. You see the current page as an ARIA accessibility tree (and a screenshot when available).
2. Execute the test steps in order, then verify the expected outcome.
3. Some steps are observational (e.g. "Locate the menu") — just confirm you see
   the element and move on to the next step without issuing an action.
4. If an action fails, you may retry with a corrected selector.
5. Once all steps are done, observe the page and issue a verdict.
6. If an element clearly does not exist after observing, issue a "fail" verdict
   rather than retrying indefinitely.
7. Output ONLY the JSON object — no explanation, no markdown fences.\
"""


# ---------------------------------------------------------------------------
# LLM helpers
# ---------------------------------------------------------------------------

def _client() -> anthropic.Anthropic:
    return make_anthropic_client()


def _call_anthropic(system: str, user_content: list, max_tokens: int) -> str:
    """Call the Anthropic Messages API using streaming and return the text response."""
    with _client().messages.stream(
        model=_MODEL,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user_content}],
    ) as stream:
        resp = stream.get_final_message()
    try:
        from experiment.token_tracking import record as _record_tokens
        _record_tokens("testing_agent", resp.usage.input_tokens, resp.usage.output_tokens, resp.model)
    except Exception:
        pass
    return resp.content[0].text.strip()


def _call_together(system: str, user_content: list, max_tokens: int) -> str:
    """Call Together.ai (OpenAI-compatible) and return the text response.

    Converts Anthropic-style image blocks to OpenAI image_url format.
    """
    # Convert content blocks: Anthropic → OpenAI format
    oai_content = []
    for block in user_content:
        if block["type"] == "text":
            oai_content.append({"type": "text", "text": block["text"]})
        elif block["type"] == "image":
            src = block["source"]
            data_uri = f"data:{src['media_type']};base64,{src['data']}"
            oai_content.append({
                "type": "image_url",
                "image_url": {"url": data_uri},
            })

    client = make_together_client()
    resp = client.chat.completions.create(
        model=_MODEL,
        max_tokens=max_tokens,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": oai_content},
        ],
    )
    try:
        from experiment.token_tracking import record as _record_tokens
        usage = resp.usage
        _record_tokens("testing_agent", usage.prompt_tokens, usage.completion_tokens, resp.model)
    except Exception:
        pass
    return resp.choices[0].message.content.strip()


def _call_openrouter(system: str, user_content: list, max_tokens: int) -> str:
    """Call OpenRouter (OpenAI-compatible) using streaming and return the text response.

    Converts Anthropic-style image blocks to OpenAI image_url format.
    Retries up to 3 times on connection errors.
    """
    import time as _time

    oai_content = []
    for block in user_content:
        if block["type"] == "text":
            oai_content.append({"type": "text", "text": block["text"]})
        elif block["type"] == "image":
            src = block["source"]
            data_uri = f"data:{src['media_type']};base64,{src['data']}"
            oai_content.append({"type": "image_url", "image_url": {"url": data_uri}})

    client = make_openrouter_client()
    kwargs = dict(
        model=_MODEL,
        max_tokens=max_tokens,
        messages=[
            {"role": "system", "content": system},
            {"role": "user",   "content": oai_content},
        ],
        stream=True,
        stream_options={"include_usage": True},
    )

    last_exc = None
    for _attempt in range(3):
        try:
            content_parts = []
            usage_in = usage_out = 0
            for chunk in client.chat.completions.create(**kwargs):
                delta = chunk.choices[0].delta if chunk.choices else None
                if hasattr(chunk, "usage") and chunk.usage:
                    usage_in  = chunk.usage.prompt_tokens or 0
                    usage_out = chunk.usage.completion_tokens or 0
                if delta and delta.content:
                    content_parts.append(delta.content)
            try:
                from experiment.token_tracking import record as _record_tokens
                _record_tokens("testing_agent", usage_in, usage_out, _MODEL)
            except Exception:
                pass
            return "".join(content_parts).strip()
        except Exception as _exc:
            last_exc = _exc
            if _attempt < 2:
                _time.sleep(10)
    raise last_exc


def _call_llm(system: str, user_content: list, max_tokens: int) -> str:
    """Route LLM call to the configured provider."""
    if _PROVIDER in ("together", "openrouter"):
        return _call_openrouter(system, user_content, max_tokens)
    return _call_anthropic(system, user_content, max_tokens)


# ---------------------------------------------------------------------------
# Message building & response parsing
# ---------------------------------------------------------------------------

def _build_user_message(test_case: dict, trajectory: list, obs: dict,
                        app_url: str) -> list:
    """Build the user message for each iteration of the agent loop."""
    # Section 1: Test context (constant)
    steps_text = "\n".join(f"  {i+1}. {s}" for i, s in enumerate(test_case["steps"]))
    context = (
        f"## Test Case: {test_case['feature']}\n\n"
        f"Steps:\n{steps_text}\n\n"
        f"Expected outcome: {test_case['expected']}\n\n"
        f"App URL: {app_url}"
    )

    # Section 2: Trajectory so far (grows each iteration)
    if trajectory:
        traj_lines = []
        for i, entry in enumerate(trajectory):
            action_str = json.dumps(entry["action"]) if entry["action"] else "null"
            status = entry["status"]
            line = f"  {i+1}. {action_str} → {status}"
            if entry.get("error"):
                line += f" ({entry['error']})"
            traj_lines.append(line)
        traj_text = "## Actions taken so far\n" + "\n".join(traj_lines)
    else:
        traj_text = "## Actions taken so far\nNone yet — this is the first observation."

    # Section 3: Current page state
    page_text = f"## Current page state (ARIA tree)\n{obs['accessibility_tree']}"

    text = f"{context}\n\n{traj_text}\n\n{page_text}\n\nRespond with a single JSON object."

    content = [{"type": "text", "text": text}]
    if _SCREENSHOTS:
        content.append({
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": "image/png",
                "data": obs["screenshot"],
            },
        })
    return content


def _parse_response(raw: str) -> dict:
    """Parse LLM response into either an action or verdict dict.

    Returns
    -------
    dict with either "action" key (browser action) or "verdict" key (termination)

    Raises
    ------
    ValueError on unparseable response
    """
    # Strip thinking tags (Qwen)
    raw = re.sub(r"<think>.*?</think>\s*", "", raw, flags=re.DOTALL).strip()
    # Strip markdown fences
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON: {raw[:200]}") from exc

    if "verdict" in parsed:
        verdict = str(parsed["verdict"]).lower()
        if verdict not in ("pass", "fail", "partial"):
            # Normalise unexpected verdicts
            if "pass" in verdict:
                verdict = "pass"
            elif "partial" in verdict:
                verdict = "partial"
            else:
                verdict = "fail"
        return {"verdict": verdict, "reason": parsed.get("reason", "")}

    if "action" in parsed:
        return parsed

    raise ValueError(f"Response has neither 'verdict' nor 'action': {raw[:200]}")


def _describe_action(action: dict | None) -> str:
    """Generate a human-readable description of an action."""
    if action is None:
        return "LLM response could not be parsed"
    a = action.get("action", "unknown")
    if a == "click":
        return f"Click {action.get('selector', '?')}"
    if a == "fill":
        return f"Fill {action.get('selector', '?')} with '{action.get('value', '')}'"
    if a == "press":
        return f"Press {action.get('key', '?')}"
    if a == "navigate":
        return f"Navigate to {action.get('url', '?')}"
    return f"Unknown action: {a}"


def _format_trajectory(internal_trajectory: list) -> list:
    """Convert internal trajectory to the public API format.

    Public format: [{"step": str, "action": dict|None, "status": str, "reason"?: str}]
    """
    formatted = []
    for entry in internal_trajectory:
        out = {
            "step": _describe_action(entry["action"]),
            "action": entry["action"],
            "status": entry["status"],
        }
        if entry.get("error"):
            out["reason"] = entry["error"]
        formatted.append(out)
    return formatted


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def run_test_case(test_case: dict, app_url: str) -> dict:
    """
    Execute one structured test case against a deployed web application.

    The LLM drives the browser in a loop: each iteration it sees the full test
    context, actions taken so far, and the current page state, then decides
    whether to execute an action or issue a verdict.

    Parameters
    ----------
    test_case : dict
        Must have keys: test_id, feature, steps (list[str]), expected (str).
    app_url : str
        Base URL of the deployed app (e.g. "http://127.0.0.1:8080").

    Returns
    -------
    dict with keys: result, trajectory, failure_report
    """
    trajectory = []  # internal: [{action, status, error?}]

    try:
        async with BrowserSession(app_url) as session:
            for _iteration in range(_MAX_ITERATIONS):
                # 1. Observe
                obs = await session.observe()

                # 2. Build message & call LLM
                user_content = _build_user_message(test_case, trajectory, obs, app_url)
                raw = _call_llm(_AGENT_SYSTEM, user_content, max_tokens=8192)

                # 3. Parse response
                try:
                    response = _parse_response(raw)
                except ValueError:
                    # Unparseable — record and continue (LLM gets another chance)
                    trajectory.append({
                        "action": None,
                        "status": "failed",
                        "error": f"unparseable_response: {raw[:200]}",
                    })
                    continue

                # 4a. Verdict → terminate
                if "verdict" in response:
                    verdict = response["verdict"]
                    reason = response.get("reason", "")
                    failure_report = "" if verdict == "pass" else reason
                    return {
                        "result": verdict,
                        "trajectory": _format_trajectory(trajectory),
                        "failure_report": failure_report,
                    }

                # 4b. Action → execute
                action = response

                # Resolve relative URLs for navigate actions
                if action.get("action") == "navigate":
                    url = action.get("url", "")
                    if url.startswith("/"):
                        action["url"] = app_url.rstrip("/") + url

                try:
                    await session.act(action)
                    trajectory.append({"action": action, "status": "executed"})
                except Exception as exc:
                    # Don't terminate — let the LLM see the failure and self-correct
                    trajectory.append({
                        "action": action,
                        "status": "failed",
                        "error": f"playwright_error: {exc}",
                    })

            # Loop exhausted without verdict
            return {
                "result": "fail",
                "trajectory": _format_trajectory(trajectory),
                "failure_report": (
                    f"Agent did not reach a verdict within {_MAX_ITERATIONS} iterations."
                ),
            }

    except Exception as exc:
        # Browser session failed to start (e.g. server unreachable) — return clean fail
        return {
            "result": "fail",
            "trajectory": _format_trajectory(trajectory),
            "failure_report": (
                f"The application server at {app_url} is not accessible "
                f"(connection refused), and the page is blank with no content. "
                f"Error: {str(exc)[:200]}"
            ),
        }
