"""
Phase 3 — Browser wrapper.

BrowserSession is an async context manager that provides one isolated
Playwright browser context per test case.

    async with BrowserSession(app_url) as session:
        obs  = await session.observe()   # {accessibility_tree, screenshot}
        await session.act(action_dict)   # execute a Playwright action

observe() returns:
    accessibility_tree : ARIA snapshot (YAML, via locator.aria_snapshot())
    screenshot         : base64-encoded PNG

Action dict format (produced by the grounding LLM):
    {"action": "navigate", "url": "http://..."}
    {"action": "click",    "selector": "#add-btn"}
    {"action": "fill",     "selector": "#task-input", "value": "Buy milk"}
    {"action": "press",    "key": "Enter"}
"""

import base64
import os

from playwright.async_api import async_playwright

# Allow override via env var; if not set, let Playwright resolve the path automatically.
_CHROMIUM_EXECUTABLE = os.environ.get("PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH") or None


class BrowserSession:
    """Isolated browser context for one test case execution."""

    def __init__(self, app_url: str):
        self._app_url = app_url
        self._playwright = None
        self._browser = None
        self._context = None
        self._page = None

    async def __aenter__(self) -> "BrowserSession":
        self._playwright = await async_playwright().start()
        launch_kwargs: dict = {"headless": True}
        if _CHROMIUM_EXECUTABLE:
            launch_kwargs["executable_path"] = _CHROMIUM_EXECUTABLE
        self._browser = await self._playwright.chromium.launch(**launch_kwargs)
        self._context = await self._browser.new_context()
        self._page = await self._context.new_page()
        await self._page.goto(self._app_url, wait_until="domcontentloaded")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

    async def observe(self) -> dict:
        """
        Capture current page state.

        Returns
        -------
        dict with keys:
            accessibility_tree : str  (ARIA snapshot in YAML format)
            screenshot         : str  (base64-encoded PNG)

        Notes
        -----
        Uses page.locator('body').aria_snapshot() (added in Playwright 1.46).
        This replaces the removed page.accessibility.snapshot() API and is
        7–10x more token-efficient than a JS-evaluated DOM tree because it
        omits decorative/invisible elements and reports semantic ARIA roles
        (textbox, button, combobox) rather than raw HTML tags.
        """
        aria_yaml = await self._page.locator("body").aria_snapshot()
        screenshot_bytes = await self._page.screenshot(type="png")
        return {
            "accessibility_tree": aria_yaml,
            "screenshot": base64.b64encode(screenshot_bytes).decode(),
        }

    async def act(self, action: dict) -> None:
        """
        Execute one Playwright action.

        Supported actions
        -----------------
        navigate : goto a URL
        click    : click an element by CSS selector
        fill     : type text into an element
        press    : send a keyboard key
        """
        action_type = action.get("action")
        if action_type == "navigate":
            await self._page.goto(action["url"], wait_until="domcontentloaded")
        elif action_type == "click":
            await self._page.click(action["selector"])
        elif action_type == "fill":
            await self._page.fill(action["selector"], action["value"])
        elif action_type == "press":
            await self._page.keyboard.press(action["key"])
        else:
            raise ValueError(f"Unknown action type: {action_type!r}")
