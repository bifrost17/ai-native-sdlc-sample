"""
Screenshot-based VLM judge for self-contained web artifacts.

Used by the ArtifactsBench evaluation path, where the ground truth is a
checklist of atomic requirements rather than executable test cases.

Public API
----------
    result = await screenshot_and_judge(checklist_items, app_url)

    result = {
        "score":          float,       # 0–100, percentage of items that pass
        "results":        list[dict],  # one entry per checklist item
        "screenshot_b64": str,         # base64 PNG of the rendered page
    }

Each entry in ``results``:
    {
        "item":    str,             # original checklist item
        "verdict": "pass" | "fail", # VLM decision
        "reason":  str,             # one-sentence justification
    }

The VLM model defaults to claude-sonnet-4-6 (vision-capable) and can be
overridden with the JUDGE_MODEL environment variable.
"""

import json
import os
import re

import anthropic

from experiment.api_key import make_anthropic_client
from mcp_server.testing_agent.browser import BrowserSession

# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

_MODEL = os.environ.get("JUDGE_MODEL", "claude-sonnet-4-6")

# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------

_JUDGE_SYSTEM = """\
You are a visual quality judge for web artifacts.
Given a screenshot of a rendered web page and a numbered checklist of
requirements, evaluate every item and return a JSON array.

For each item output an object with exactly these keys:
  item    : the original checklist item text (copy verbatim)
  verdict : "pass" or "fail"
  reason  : one sentence explaining your decision

Rules:
- Base your verdict ONLY on what is visible in the screenshot.
- "pass" means the item is clearly satisfied in the screenshot.
- "fail" means the item is absent or clearly broken.
- Return ONLY the JSON array — no prose, no markdown fences.\
"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_judge_output(raw: str) -> list[dict]:
    """Extract JSON array from raw LLM output (strips fences if present)."""
    # Try bare array first
    m = re.search(r"\[[\s\S]*\]", raw)
    if m:
        return json.loads(m.group(0))
    raise ValueError(f"No JSON array found in judge output:\n{raw[:400]}")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def screenshot_and_judge(checklist_items: list[str], app_url: str) -> dict:
    """
    Navigate to *app_url*, take a full-page screenshot, and ask a VLM to
    evaluate each item in *checklist_items* against the screenshot.

    Parameters
    ----------
    checklist_items : list[str]
        Atomic requirement strings (e.g. from ArtifactsBench ``checklist``
        field or produced by Tool 1 generate mode).
    app_url : str
        URL of the running artifact (e.g. ``"http://127.0.0.1:8080"``).

    Returns
    -------
    dict
        ``score``          : float 0–100 (pass rate × 100)
        ``results``        : list of {item, verdict, reason}
        ``screenshot_b64`` : base64-encoded PNG
    """
    if not checklist_items:
        return {"score": 0.0, "results": [], "screenshot_b64": ""}

    # 1. Capture screenshot via Playwright
    async with BrowserSession(app_url) as session:
        obs = await session.observe()
    screenshot_b64 = obs["screenshot"]

    # 2. Build numbered checklist text
    checklist_text = "\n".join(
        f"{i + 1}. {item}" for i, item in enumerate(checklist_items)
    )

    # 3. Call Claude VLM
    user_content = [
        {
            "type": "text",
            "text": (
                "Here is a screenshot of a web artifact.\n\n"
                f"Checklist ({len(checklist_items)} items):\n{checklist_text}\n\n"
                "Return a JSON array evaluating each item."
            ),
        },
        {
            "type": "image",
            "source": {
                "type":       "base64",
                "media_type": "image/png",
                "data":       screenshot_b64,
            },
        },
    ]

    client = make_anthropic_client()
    resp = client.messages.create(
        model=_MODEL,
        max_tokens=2048,
        system=_JUDGE_SYSTEM,
        messages=[{"role": "user", "content": user_content}],
    )

    # Record token usage for cost analysis (silently skipped in tests with mocks)
    try:
        from experiment.token_tracking import record as _record_tokens
        _record_tokens("judge", resp.usage.input_tokens, resp.usage.output_tokens, resp.model)
    except Exception:
        pass

    raw = resp.content[0].text.strip()

    # 4. Parse and score
    results = _parse_judge_output(raw)

    # Normalise verdicts defensively
    for r in results:
        v = str(r.get("verdict", "")).strip().lower()
        r["verdict"] = "pass" if v == "pass" else "fail"

    passes = sum(1 for r in results if r["verdict"] == "pass")
    score = passes / len(results) * 100 if results else 0.0

    return {
        "score":          score,
        "results":        results,
        "screenshot_b64": screenshot_b64,
    }
