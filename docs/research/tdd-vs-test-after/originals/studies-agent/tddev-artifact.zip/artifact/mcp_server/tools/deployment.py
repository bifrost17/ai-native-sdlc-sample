"""
Tool 2: Deployment — detect_framework, start_app, stop_app.

No LLM calls. Manages dev-server subprocesses keyed by project_dir.
Includes auto-recovery: npm install + heuristic entry-point detection.
"""

import json
import logging
import os
import re
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

log = logging.getLogger(__name__)

# Registry: project_dir (str) -> subprocess.Popen
_process_registry: dict[str, subprocess.Popen] = {}

# Framework detection rules: ordered by specificity (Next before React/Vite)
_FRAMEWORK_RULES = [
    ("nextjs",  lambda deps: "next" in deps,                          "npm run dev"),
    ("react",   lambda deps: "react" in deps and "vite" in deps,      "npm run dev"),
    ("vue",     lambda deps: "vue" in deps,                           "npm run dev"),
    ("vite",    lambda deps: "vite" in deps,                          "npm run dev"),
    ("express", lambda deps: "express" in deps,                       "node server.js"),
]

_DEFAULT_PORTS = {
    "nextjs":      3000,
    "react":       5173,
    "vue":         5173,
    "vite":        5173,
    "express":     3000,
    "static_html": 8080,
    "unknown":     3000,
}

# Common entry-point filenames in priority order
_ENTRY_CANDIDATES = [
    "server.js", "index.js", "app.js", "main.js",
    "src/server.js", "src/index.js", "src/app.js",
]


def detect_framework(project_dir: str) -> dict:
    """
    Read package.json and return:
      {"framework": str, "dev_command": str, "default_port": int}

    If no package.json is found but an index.html exists, returns
    framework="static_html" so start_app can serve it with Python's
    built-in HTTP server (no npm required).
    """
    pkg_path = Path(project_dir) / "package.json"
    if not pkg_path.exists():
        # Static HTML artifact: single self-contained file, no Node.js needed
        if any(Path(project_dir).glob("*.html")):
            return {
                "framework":    "static_html",
                "dev_command":  f"{sys.executable} -m http.server",
                "default_port": 8080,
            }
        return {"framework": "unknown", "dev_command": "npm start", "default_port": 3000}

    with open(pkg_path) as f:
        pkg = json.load(f)

    all_deps: set[str] = set()
    for section in ("dependencies", "devDependencies"):
        all_deps.update(pkg.get(section, {}).keys())

    for framework, matcher, command in _FRAMEWORK_RULES:
        if matcher(all_deps):
            # Prefer the package.json scripts.dev / scripts.start if present
            scripts = pkg.get("scripts", {})
            if "dev" in scripts:
                command = "npm run dev"
            elif "start" in scripts:
                command = "npm start"
            return {
                "framework": framework,
                "dev_command": command,
                "default_port": _DEFAULT_PORTS.get(framework, 3000),
            }

    return {"framework": "unknown", "dev_command": "npm start", "default_port": 3000}


def _is_port_open(port: int, host: str = "127.0.0.1", timeout: float = 0.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _find_free_port() -> int:
    with socket.socket() as s:
        s.bind(("", 0))
        return s.getsockname()[1]


# ---------------------------------------------------------------------------
# Spawn helper (extracted for reuse in recovery)
# ---------------------------------------------------------------------------

def _spawn_and_wait(
    project_dir: str,
    command: str,
    port: int,
    framework: str,
    timeout: int = 30,
    env: dict | None = None,
) -> dict:
    """
    Spawn a dev server subprocess and wait for the port to open.

    Returns {"url": str, "port": int, "framework": str}.
    Raises RuntimeError on failure.
    """
    key = str(Path(project_dir).resolve())

    # Static HTML: bake port into command
    if framework == "static_html":
        command = f"{sys.executable} -m http.server {port}"

    proc_env = os.environ.copy()
    proc_env["PORT"] = str(port)
    if env:
        proc_env.update(env)

    use_shell = sys.platform == "win32" and command.split()[0] in ("npm", "npx")

    proc = subprocess.Popen(
        command if use_shell else command.split(),
        cwd=project_dir,
        env=proc_env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=use_shell,
        start_new_session=not use_shell,
    )

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            stderr = proc.stderr.read().decode(errors="replace") if proc.stderr else ""
            raise RuntimeError(
                f"Dev server process exited prematurely (rc={proc.returncode}): {stderr[:500]}"
            )
        if _is_port_open(port):
            break
        time.sleep(0.5)
    else:
        proc.kill()
        raise RuntimeError(
            f"Dev server did not open port {port} within {timeout}s "
            f"(framework={framework}, cmd={command!r})"
        )

    info = {"url": f"http://127.0.0.1:{port}", "port": port, "framework": framework}
    proc._start_info = info  # type: ignore[attr-defined]
    _process_registry[key] = proc
    return info


# ---------------------------------------------------------------------------
# Auto-recovery helpers
# ---------------------------------------------------------------------------

def _ensure_npm_install(project_dir: str) -> bool:
    """Run ``npm install`` if package.json exists but node_modules/ does not.

    Returns True if install was executed, False if skipped.
    """
    pkg = Path(project_dir) / "package.json"
    nm = Path(project_dir) / "node_modules"
    if not pkg.exists() or nm.exists():
        return False
    log.info("Auto-recovery: running npm install in %s", project_dir)
    try:
        subprocess.run(
            ["npm", "install"],
            cwd=project_dir,
            capture_output=True,
            timeout=60,
            check=True,
        )
        return True
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError) as exc:
        log.warning("npm install failed: %s", exc)
        return False


def _detect_entry_point(project_dir: str) -> tuple[str, int] | None:
    """Heuristic scan for a Node.js server entry point.

    Returns ``(command, port)`` or ``None``.
    """
    pdir = Path(project_dir)

    # 1. Check package.json main / scripts.start
    pkg_path = pdir / "package.json"
    candidates_from_pkg: list[str] = []
    if pkg_path.exists():
        try:
            pkg = json.loads(pkg_path.read_text())
            # main field
            main = pkg.get("main")
            if main and isinstance(main, str):
                candidates_from_pkg.append(main)
            # scripts.start → extract filename ("node app.js" → "app.js")
            start_script = pkg.get("scripts", {}).get("start", "")
            if start_script:
                parts = start_script.split()
                for p in parts:
                    if p.endswith(".js"):
                        candidates_from_pkg.append(p)
        except (json.JSONDecodeError, OSError):
            pass

    # 2. Build ordered candidate list
    all_candidates = candidates_from_pkg + _ENTRY_CANDIDATES

    # 3. Scan each candidate for .listen(
    for candidate in all_candidates:
        fpath = pdir / candidate
        if not fpath.is_file():
            continue
        try:
            src = fpath.read_text(errors="replace")[:5000]
        except OSError:
            continue
        if ".listen(" not in src:
            continue

        # Extract port from source
        port = _extract_port(src)
        cmd = f"node {candidate}"
        log.info("Auto-recovery: detected entry point %s (port %d)", candidate, port)
        return (cmd, port)

    # 4. Fall back to static HTML if .html files exist
    if any(pdir.glob("*.html")):
        log.info("Auto-recovery: falling back to static HTML serving")
        return (f"{sys.executable} -m http.server", 8080)

    return None


def _extract_port(source: str) -> int:
    """Extract port number from JS source code. Falls back to 3000."""
    # Match patterns like: listen(3000, listen(8080,  PORT || 3000
    for pattern in [
        r"\.listen\(\s*(\d{2,5})",               # .listen(3000
        r"PORT\s*\|\|\s*(\d{2,5})",              # PORT || 3000
        r"port\s*[:=]\s*(\d{2,5})",              # port = 3000 or port: 3000
    ]:
        m = re.search(pattern, source, re.IGNORECASE)
        if m:
            return int(m.group(1))
    return 3000


def _auto_recover(
    project_dir: str,
    port: int,
    timeout: int,
    env: dict | None,
) -> dict | None:
    """Try heuristic recovery after primary start_app fails.

    Returns start info dict on success, None if all recovery fails.
    """
    # Stage 1: npm install + retry with original detection
    if _ensure_npm_install(project_dir):
        try:
            fw = detect_framework(project_dir)
            return _spawn_and_wait(
                project_dir, fw["dev_command"], port, fw["framework"], timeout, env
            )
        except RuntimeError:
            log.debug("Retry after npm install still failed")

    # Stage 2: heuristic entry-point detection
    entry = _detect_entry_point(project_dir)
    if entry is not None:
        cmd, detected_port = entry
        use_port = port if port else detected_port
        framework = "static_html" if "http.server" in cmd else "express"
        try:
            return _spawn_and_wait(
                project_dir, cmd, use_port, framework, timeout, env
            )
        except RuntimeError:
            log.debug("Heuristic entry point %r also failed", cmd)

    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def start_app(
    project_dir: str,
    port: int | None = None,
    timeout: int = 30,
    env: dict | None = None,
) -> dict:
    """
    Spawn the dev server for project_dir.

    Returns {"url": str, "port": int, "framework": str}.
    Raises RuntimeError if the server does not become reachable within timeout.
    If a server is already running for this project_dir it is returned as-is.

    On failure, attempts auto-recovery:
      1. Run ``npm install`` if node_modules/ is missing
      2. Heuristic entry-point scan (.listen() in JS files)
    """
    key = str(Path(project_dir).resolve())

    # Return existing process if still alive
    if key in _process_registry:
        proc = _process_registry[key]
        if proc.poll() is None:
            info = proc._start_info  # type: ignore[attr-defined]
            return info

    framework_info = detect_framework(project_dir)
    framework = framework_info["framework"]
    dev_command = framework_info["dev_command"]

    if port is None:
        port = _DEFAULT_PORTS.get(framework, 3000)
        if _is_port_open(port):
            port = _find_free_port()

    # --- Primary path ---
    _primary_err = None
    try:
        return _spawn_and_wait(project_dir, dev_command, port, framework, timeout, env)
    except RuntimeError as exc:
        _primary_err = exc
        log.info("Primary start failed: %s — attempting recovery", exc)

    # --- Recovery path ---
    recovered = _auto_recover(project_dir, port, timeout, env)
    if recovered is not None:
        return recovered

    raise _primary_err


def stop_app(project_dir: str) -> None:
    """
    Terminate the dev server for project_dir (no-op if not running).
    """
    key = str(Path(project_dir).resolve())
    proc = _process_registry.pop(key, None)
    if proc is None:
        return
    if proc.poll() is None:
        try:
            if sys.platform == "win32":
                subprocess.call(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except (ProcessLookupError, OSError):
            pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
