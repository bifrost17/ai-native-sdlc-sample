"""
Phase 2 — Tool 1: Test Case Generation.

Two modes, one LLM call each.  No other logic.

Convert mode  (requirements + ui_instruct list)
    Expands each WebGen-Bench ui_instruct entry into a full structured test
    case: derives a feature name, expands the high-level task into concrete
    steps, maps expected_result → expected, assigns a sequential test_id.

Generate mode  (requirements only)
    Uses chain-of-thought to identify features from requirements, then emits
    one test case per feature.

Output format (one test case):
    {
        "test_id":  "TC-01",
        "feature":  "User can create a task",
        "steps":    ["Navigate to ...", "Enter ...", "Click ..."],
        "expected": "New task appears in the task list"
    }

Opinionated defaults injected in both modes:
    email: testuser@example.com   password: Test@1234
    name:  Test User              generic string: Test Item
"""

import json
import os
import re

import anthropic

from experiment.api_key import make_anthropic_client, make_together_client, make_openrouter_client

# ---------------------------------------------------------------------------
# Model & provider choice — configurable for cross-model experiments
# ---------------------------------------------------------------------------

_MODEL = os.environ.get("TEST_GENERATION_MODEL", "claude-sonnet-4-6")
_PROVIDER = os.environ.get("TESTING_AGENT_PROVIDER", "anthropic")  # "anthropic" | "together" | "openrouter"

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_DEFAULTS_BLOCK = """\
Use these fixed test data values whenever the test requires user credentials or
generic strings:
  email:    testuser@example.com
  password: Test@1234
  name:     Test User
  generic:  Test Item
"""

_NAV_RULE = """\
IMPORTANT: Do NOT include any "open the app / website / page" or "navigate to"
steps. The test runner already opens the app URL before testing begins, so steps
must start with the first meaningful user interaction (e.g. click, fill, scroll).
"""

_CONVERT_SYSTEM = (
    "You are a test case generator for web applications. "
    "Convert each ui_instruct item into a structured test case using the "
    "requirements as context to resolve any ambiguities.\n\n"
    + _DEFAULTS_BLOCK
    + _NAV_RULE
)

_GENERATE_SYSTEM = (
    "You are a test case generator for web applications. "
    "Generate one structured test case per feature, covering the happy path "
    "only.\n\n"
    + _DEFAULTS_BLOCK
    + _NAV_RULE
)

_SCHEMA_REMINDER = """\
Each test case must be a JSON object with exactly these keys:
  test_id  : string, e.g. "TC-01" (unique, sequential)
  feature  : short name of the feature under test
  steps    : non-empty list of strings, each a concrete action
  expected : string describing the expected outcome

Return ONLY a JSON array of test case objects — no prose before or after.
"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_test_cases(
    requirements: str,
    ui_instruct: list[dict] | None = None,
) -> list[dict]:
    """
    Generate structured test cases from *requirements*.

    Parameters
    ----------
    requirements : str
        Natural language requirements (e.g. WebGen-Bench ``instruction``).
    ui_instruct : list[dict] | None
        If provided, run in **convert mode**: each dict must have ``task`` and
        ``expected_result`` keys (WebGen-Bench ui_instruct format).
        If omitted / None, run in **generate mode**.

    Returns
    -------
    list[dict]
        Test cases validated to have all required keys.

    Raises
    ------
    ValueError
        If the LLM response cannot be parsed into a JSON array.
    """
    if ui_instruct is not None:
        return _convert_mode(requirements, ui_instruct)
    return _generate_mode(requirements)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _client() -> anthropic.Anthropic:
    """Return a fresh Anthropic client (patched in tests)."""
    return make_anthropic_client()


def _convert_mode(requirements: str, ui_instruct: list[dict]) -> list[dict]:
    prompt = (
        f"Requirements:\n{requirements}\n\n"
        "Convert each ui_instruct item below into a structured test case.\n\n"
        f"Items:\n{json.dumps(ui_instruct, indent=2)}\n\n"
        + _SCHEMA_REMINDER
    )
    text = _call_llm(_CONVERT_SYSTEM, prompt)
    return _parse_test_cases(text)


def _generate_mode(requirements: str) -> list[dict]:
    prompt = (
        f"Requirements:\n{requirements}\n\n"
        "Step 1 — list every distinct feature you can identify (chain-of-thought).\n"
        "Step 2 — write one test case per feature.\n\n"
        + _SCHEMA_REMINDER
    )
    text = _call_llm(_GENERATE_SYSTEM, prompt)
    return _parse_test_cases(text)


def _call_llm_openrouter(system: str, user: str) -> str:
    import time as _time
    client = make_openrouter_client()
    kwargs = dict(
        model=_MODEL,
        max_tokens=4096,
        messages=[
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
        stream=True,
        stream_options={"include_usage": True},
    )
    last_exc = None
    for _attempt in range(3):
        try:
            content_parts = []
            usage_in = usage_out = 0
            for chunk in client.chat.completions.create(**kwargs):
                delta = chunk.choices[0].delta if chunk.choices else None
                if hasattr(chunk, "usage") and chunk.usage:
                    usage_in  = chunk.usage.prompt_tokens or 0
                    usage_out = chunk.usage.completion_tokens or 0
                if delta and delta.content:
                    content_parts.append(delta.content)
            try:
                from experiment.token_tracking import record as _record_tokens
                _record_tokens("generation", usage_in, usage_out, _MODEL)
            except Exception:
                pass
            return "".join(content_parts).strip()
        except Exception as _exc:
            last_exc = _exc
            if _attempt < 2:
                _time.sleep(10)
    raise last_exc


def _call_llm(system: str, user: str) -> str:
    if _PROVIDER in ("together", "openrouter"):
        return _call_llm_openrouter(system, user)
    return _call_llm_anthropic(system, user)


def _call_llm_anthropic(system: str, user: str) -> str:
    with _client().messages.stream(
        model=_MODEL,
        max_tokens=4096,
        system=system,
        messages=[{"role": "user", "content": user}],
    ) as stream:
        message = stream.get_final_message()

    try:
        from experiment.token_tracking import record as _record_tokens
        _record_tokens("generation", message.usage.input_tokens, message.usage.output_tokens, message.model)
    except Exception:
        pass

    return message.content[0].text


def _call_llm_together(system: str, user: str) -> str:
    client = make_together_client()
    resp = client.chat.completions.create(
        model=_MODEL,
        max_tokens=4096,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    )

    try:
        from experiment.token_tracking import record as _record_tokens
        usage = resp.usage
        _record_tokens("generation", usage.prompt_tokens, usage.completion_tokens, resp.model)
    except Exception:
        pass

    return resp.choices[0].message.content


def _parse_test_cases(text: str) -> list[dict]:
    """
    Extract a JSON array from *text*.

    Tries (in order):
      1. Content between <json>…</json> tags
      2. Content between ```json … ``` fences
      3. First top-level JSON array in the raw text
    """
    # 1. <json> tags
    m = re.search(r"<json>(.*?)</json>", text, re.DOTALL)
    if m:
        return json.loads(m.group(1).strip())

    # 2. Markdown code fence
    m = re.search(r"```(?:json)?\s*(\[[\s\S]*?\])\s*```", text)
    if m:
        return json.loads(m.group(1))

    # 3. Bare JSON array
    m = re.search(r"\[[\s\S]*\]", text)
    if m:
        return json.loads(m.group(0))

    raise ValueError(f"No JSON array found in LLM output:\n{text[:300]}")
