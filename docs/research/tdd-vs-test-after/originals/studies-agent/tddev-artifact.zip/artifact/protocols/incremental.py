"""
Phase 4 — Incremental development protocol (Condition B).

Drives a feature-by-feature build loop. Each new feature is tested together
with all previously confirmed-passing features (regression suite). A feature
that exceeds MAX_ATTEMPTS without passing is marked failed and excluded from
the regression baseline — keeping passed_suite clean for subsequent features.

Usage
-----
    result = run_incremental(
        test_cases  = [...],
        dev_agent   = agent_obj,       # .implement(tc), .fix(report)
        start_app   = lambda: ...,     # deploy the app
        run_tests   = lambda tcs: ..., # returns {"results": [...]}
        log_result  = lambda tc, attempt, results: ...,
        max_attempts = 5,
    )
"""

MAX_ATTEMPTS = 5


def _all_pass(run_tests_output: dict) -> bool:
    """Return True when every result is 'pass' or 'partial'.

    'partial' is treated as acceptable for retry purposes — the agent should
    not keep retrying a TC that the testing agent cannot fully verify (e.g.
    color validation without screenshots). Accuracy credit for partial is
    still 0.5 in metrics.py.
    """
    return all(r["result"] in ("pass", "partial") for r in run_tests_output["results"])


def _classify(
    run_tests_output: dict,
    passed_suite: list,
    current_tc: dict,
) -> str:
    """
    Build a failure report separating regressions from new-feature failures.

    Regressions: tests in passed_suite that are now failing.
    New failures: the current feature test that is not yet passing.
    """
    results = run_tests_output["results"]
    passed_ids = {tc["test_id"] for tc in passed_suite}
    current_id = current_tc["test_id"]

    regressions = [r for r in results if r["result"] not in ("pass", "partial") and r["test_id"] in passed_ids]
    new_failures = [r for r in results if r["result"] not in ("pass", "partial") and r["test_id"] == current_id]

    lines = []
    if regressions:
        lines.append(
            f"Regressions ({len(regressions)}): "
            + ", ".join(r["test_id"] for r in regressions)
        )
    if new_failures:
        lines.append(
            f"New failures ({len(new_failures)}): "
            + ", ".join(r["test_id"] for r in new_failures)
        )
    for r in results:
        if r["result"] not in ("pass", "partial") and r.get("failure_report"):
            lines.append(f"  [{r['test_id']}] {r['failure_report']}")

    return "\n".join(lines) if lines else "All tests passed."


def run_incremental(
    test_cases: list,
    dev_agent,
    start_app,
    run_tests,
    log_result,
    max_attempts: int = MAX_ATTEMPTS,
) -> dict:
    """
    Condition B: implement features one at a time with regression testing.

    Parameters
    ----------
    test_cases   : list of structured test case dicts (processed in order)
    dev_agent    : object with .implement(tc) and .fix(report: str)
    start_app    : callable() → None   — deploys the application
    run_tests    : callable(test_cases) → {"results": list[dict]}
    log_result   : callable(tc: dict, attempt: int, results: dict) → None
    max_attempts : maximum deploy-test-fix iterations per feature (default MAX_ATTEMPTS)

    Returns
    -------
    dict:
        passed_suite : list of test cases confirmed passing
        failed       : list of test_ids that hit the attempt ceiling
        log          : list of {tc_id, attempt, results, all_pass} per iteration
    """
    passed_suite: list = []
    failed: list = []
    log: list = []

    for tc in test_cases:
        dev_agent.implement(tc)

        for attempt in range(1, max_attempts + 1):
            start_app()
            regression_window = passed_suite[-2:]  # cap to last 2 passing TCs
            outcome = run_tests(regression_window + [tc])
            passed = _all_pass(outcome)
            log_result(tc, attempt, outcome)
            log.append({
                "tc_id": tc["test_id"],
                "attempt": attempt,
                "results": outcome,
                "all_pass": passed,
            })

            if passed:
                passed_suite.append(tc)
                break

            dev_agent.fix(_classify(outcome, regression_window, tc))
        else:
            # For loop exhausted without break → feature hit the ceiling
            failed.append(tc["test_id"])

    return {"passed_suite": passed_suite, "failed": failed, "log": log}
