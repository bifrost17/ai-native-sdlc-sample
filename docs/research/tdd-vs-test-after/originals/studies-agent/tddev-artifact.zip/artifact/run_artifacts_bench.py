#!/usr/bin/env python3
"""
ArtifactsBench evaluation — conditions A, B, C, D.

Pipeline (per sample × condition)
----------------------------------
  GT checklist (from dataset)
    → HTMLAPIDevAgent builds index.html   (direct LLM API, streaming)
    → start_app (static_html) → python3 -m http.server
    → screenshot_and_judge(GT checklist) → score 0–100

Conditions
----------
A  Standard prompt  + fix loop            (max _MAX_ATTEMPTS)
B  Incremental: one checklist item at a time, fix loop per item (K=_K_B)
C  Agentic TDD: agent has start_app / screenshot_judge / stop_app tools,
               drives its own deploy→judge→fix loop
D  Standard prompt  + no fix loop         (single attempt)

Usage
-----
    cd code
    python run_artifacts_bench.py --provider openrouter
    python run_artifacts_bench.py --provider openrouter --n-cases 1 --conditions D
"""

import argparse
import asyncio
import json
import logging
import os
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

# ---------------------------------------------------------------------------
# CLI args
# ---------------------------------------------------------------------------

def _parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--provider", choices=["anthropic", "openrouter"],
                   default="openrouter")
    p.add_argument("--model", default=None,
                   help="Model override (default: claude-sonnet-4-6 / anthropic/claude-sonnet-4-6)")
    p.add_argument("--n-cases", type=int, default=5)
    p.add_argument("--conditions", nargs="+", default=["A","B","C","D"],
                   choices=["A","B","C","D"])
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--results-dir", default=None,
                   help="Fixed results directory (enables resume across restarts)")
    return p.parse_args()

_ARGS = _parse_args()

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

def _load_key(env_var: str) -> str:
    return os.environ.get(env_var, "").strip()

_ANTHROPIC_KEY  = _load_key("ANTHROPIC_API_KEY")
_OPENROUTER_KEY = _load_key("OPENROUTER_API_KEY")
_OPENROUTER_BASE = "https://openrouter.ai/api/v1"

if _ARGS.provider == "anthropic":
    if not _ANTHROPIC_KEY:
        sys.exit("ERROR: ANTHROPIC_API_KEY not set. Copy .env.example to .env and export the variables.")
    _MODEL = _ARGS.model or "claude-sonnet-4-6"
else:
    if not _OPENROUTER_KEY:
        sys.exit("ERROR: OPENROUTER_API_KEY not set. Copy .env.example to .env and export the variables.")
    _MODEL = _ARGS.model or "anthropic/claude-sonnet-4-6"

# Judge always uses Anthropic (screenshot_and_judge uses make_anthropic_client)
os.environ.setdefault("ANTHROPIC_API_KEY", _ANTHROPIC_KEY)
os.environ["JUDGE_MODEL"] = "claude-sonnet-4-6"

# ---------------------------------------------------------------------------
# Output directory + logging
# ---------------------------------------------------------------------------

_TS = datetime.now().strftime("%Y%m%d_%H%M%S")
if _ARGS.results_dir:
    RESULTS = Path(_ARGS.results_dir).resolve()
else:
    RESULTS = Path(__file__).parent / "results" / f"artifacts_{_TS}"
RESULTS.mkdir(parents=True, exist_ok=True)

LOG_FILE = RESULTS / "artifacts_bench.log"
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
    handlers=[
        logging.FileHandler(str(LOG_FILE), encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("artifacts_bench")

# ---------------------------------------------------------------------------
# Project imports
# ---------------------------------------------------------------------------

from experiment.artifacts_loader import fetch_artifacts_samples
from mcp_server.tools.deployment import start_app, stop_app
from mcp_server.testing_agent.screenshot_judge import screenshot_and_judge

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

_N_SAMPLES    = _ARGS.n_cases
_SEED         = _ARGS.seed
_MAX_ATTEMPTS = 5      # A, C external retry cap
_K_B          = 2      # B fix attempts per item
_MAX_ITERS    = 15     # C agentic loop max iterations
_CONDITIONS   = _ARGS.conditions
_TIMEOUT_APP  = 15

_COND_LABELS = {
    "A": "standard prompt + fix loop",
    "B": "incremental per item + fix loop",
    "C": "agentic TDD (agent drives deploy→judge→fix)",
    "D": "standard prompt, no fix (baseline)",
}

# ---------------------------------------------------------------------------
# Checklist normalisation
# ---------------------------------------------------------------------------

def _cl_str(item) -> str:
    """Convert a checklist item (str or dict with title/description) to a plain string."""
    if isinstance(item, str):
        return item
    title = item.get("title", "")
    desc  = item.get("description", "")
    return f"{title} — {desc}" if desc else title


def _normalise_checklist(checklist: list) -> list[str]:
    return [_cl_str(i) for i in checklist]

# ---------------------------------------------------------------------------
# Async helper
# ---------------------------------------------------------------------------

_thread_local = threading.local()

def _run(coro):
    """Run an async coroutine in the current thread's event loop (thread-safe)."""
    loop = getattr(_thread_local, "loop", None)
    if loop is None or loop.is_closed():
        loop = asyncio.new_event_loop()
        _thread_local.loop = loop
    return loop.run_until_complete(coro)

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_IMPLEMENT_HTML = """\
You are building a self-contained web artifact. Create a single file called
index.html that fully satisfies the requirement and every item in the checklist.

Requirement:
{question}

Checklist (every item must be satisfied):
{checklist_text}

Rules:
- Output ONE file: index.html
- All CSS and JavaScript must be inline (no external files)
- You MAY reference CDN libraries via <script src="..."> if needed
- The artifact must be functional and visually complete
- Do NOT create package.json or any Node.js files
"""

_IMPLEMENT_CHUNK = """\
You are building a self-contained web artifact. Create a single file called
index.html that satisfies the following requirement and checklist items.

Requirement:
{question}

Features to implement in this phase:
{items}

Rules:
- Output ONE file: index.html
- All CSS and JavaScript must be inline (no external files)
- You MAY reference CDN libraries via <script src="..."> if needed
- Implement all listed features completely
- Do NOT create package.json or any Node.js files
"""

_EXTEND_HTML = """\
You are extending a self-contained web artifact (index.html).

The artifact already implements these features:
{existing_items}

Add these new features to index.html:
{new_items}

Rules:
- Read the existing index.html first using read_file
- Make the MINIMAL changes needed to add the new features
- Do NOT break any existing functionality
- Keep everything in a single index.html file (all CSS/JS inline)
- Write the updated file with write_file
"""

_FIX_HTML = """\
The visual judge evaluated your index.html and found failures.
Fix the file so every item passes.

Failed checklist items:
{failures_text}

Instructions:
- Read the existing index.html to understand the current state
- Make the minimal changes needed to fix each failure
- Do not remove any currently passing features
"""

_IMPLEMENT_TDD = """\
You are building a self-contained web artifact using Test-Driven Development.
You have tools to write the file, deploy it, judge it against a checklist,
and iterate until all items pass.

Requirement:
{question}

Checklist (all items must pass the visual judge):
{checklist_text}

TDD workflow:
1. Write index.html using write_file
2. Call start_app → get {{url}}
3. Call screenshot_judge with the full checklist and url → see which items pass/fail
4. Fix index.html based on failures
5. Call stop_app, then repeat from step 2
6. Stop when all items pass (score=100) or you've reached the iteration limit

Rules:
- Output ONE file: index.html
- All CSS and JavaScript must be inline (no external files)
- You MAY reference CDN libraries via <script src="..."> if needed
- Do NOT create package.json or any Node.js files
"""

# ---------------------------------------------------------------------------
# Tool schemas (Anthropic input_schema format; converted for OpenRouter)
# ---------------------------------------------------------------------------

_TOOLS_BASIC = [
    {
        "name": "write_file",
        "description": "Write content to index.html (or any file) in the project directory.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path":    {"type": "string", "description": "Filename, e.g. 'index.html'"},
                "content": {"type": "string", "description": "Complete file content"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "read_file",
        "description": "Read an existing file from the project directory.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Filename to read"},
            },
            "required": ["path"],
        },
    },
]

_TOOLS_TDD = _TOOLS_BASIC + [
    {
        "name": "start_app",
        "description": "Deploy index.html as a static web server. Returns {url, port}.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "screenshot_judge",
        "description": (
            "Take a screenshot of the deployed app and evaluate checklist items. "
            "Returns {score (0-100), results: [{item, verdict, reason}]}."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "checklist": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of checklist items to evaluate",
                },
                "url": {
                    "type": "string",
                    "description": "URL of the running app (from start_app)",
                },
            },
            "required": ["checklist", "url"],
        },
    },
    {
        "name": "stop_app",
        "description": "Stop the running static web server.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
]


def _to_oai_tools(tools: list) -> list:
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t["description"],
                "parameters": t["input_schema"],
            },
        }
        for t in tools
    ]

# ---------------------------------------------------------------------------
# HTMLAPIDevAgent
# ---------------------------------------------------------------------------

class HTMLAPIDevAgent:
    """
    Dev agent for single-file HTML artifacts backed by direct LLM API calls.

    provider="anthropic"  → Anthropic SDK (streaming)
    provider="openrouter" → OpenAI-compatible client via OpenRouter (streaming)

    For Condition C (tdd=True), start_app_fn / judge_fn / stop_app_fn
    are injected and exposed as tools to the LLM.
    """

    def __init__(
        self,
        project_dir: str,
        question:    str,
        sample_idx:  int,
        tdd:         bool = False,
        start_app_fn = None,
        judge_fn     = None,
        stop_app_fn  = None,
    ):
        self.project_dir  = project_dir
        self.question     = question
        self.tdd          = tdd
        self._start_fn    = start_app_fn
        self._judge_fn    = judge_fn
        self._stop_fn     = stop_app_fn
        self._current_url: str = ""
        self._log = logging.getLogger(f"agent.sample{sample_idx}")

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def implement(self, checklist: list[str]) -> None:
        """Implement all checklist items (Conditions A, D, and C entry-point)."""
        cl_text = "\n".join(f"- {item}" for item in checklist)
        if self.tdd:
            prompt = _IMPLEMENT_TDD.format(question=self.question, checklist_text=cl_text)
            tools  = _TOOLS_TDD
        else:
            prompt = _IMPLEMENT_HTML.format(question=self.question, checklist_text=cl_text)
            tools  = _TOOLS_BASIC
        self._agent_loop(prompt, tools)

    def implement_chunk(self, items: list[str]) -> None:
        """Implement a chunk of checklist items from scratch (first chunk of Condition B)."""
        items_text = "\n".join(f"- {i}" for i in items)
        prompt = _IMPLEMENT_CHUNK.format(question=self.question, items=items_text)
        self._agent_loop(prompt, _TOOLS_BASIC)

    def extend(self, existing_items: list[str], new_items: list[str]) -> None:
        """Extend existing index.html with a new chunk of checklist items (Condition B)."""
        existing_text = "\n".join(f"- {i}" for i in existing_items)
        new_text      = "\n".join(f"- {i}" for i in new_items)
        prompt = _EXTEND_HTML.format(existing_items=existing_text, new_items=new_text)
        self._agent_loop(prompt, _TOOLS_BASIC)

    def fix(self, failed_items: list[dict]) -> None:
        """Fix based on judge failures (Conditions A, B, D)."""
        failures_text = "\n".join(
            f"- {r['item']}\n  Reason: {r['reason']}" for r in failed_items
        )
        prompt = _FIX_HTML.format(failures_text=failures_text)
        self._agent_loop(prompt, _TOOLS_BASIC)

    # ------------------------------------------------------------------
    # Tool dispatch
    # ------------------------------------------------------------------

    def _dispatch(self, name: str, inp: dict) -> str:
        try:
            if name == "write_file":
                path = Path(self.project_dir) / inp["path"]
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(inp["content"], encoding="utf-8")
                self._log.debug("write_file %s (%d bytes)", inp["path"], len(inp["content"]))
                return json.dumps({"ok": True})

            elif name == "read_file":
                path = Path(self.project_dir) / inp["path"]
                content = path.read_text(encoding="utf-8") if path.exists() else ""
                return json.dumps({"content": content})

            elif name == "start_app":
                result = self._start_fn(self.project_dir)
                self._current_url = result["url"]
                self._log.debug("start_app → %s", self._current_url)
                return json.dumps(result)

            elif name == "screenshot_judge":
                checklist = inp["checklist"]
                url = inp.get("url") or self._current_url
                judge_out = _run(self._judge_fn(checklist, url))
                self._log.debug(
                    "screenshot_judge score=%.1f%% pass=%d/%d",
                    judge_out["score"],
                    sum(1 for r in judge_out["results"] if r["verdict"] == "pass"),
                    len(judge_out["results"]),
                )
                # Don't send screenshot_b64 back to the agent (too many tokens)
                return json.dumps({
                    "score":   judge_out["score"],
                    "results": judge_out["results"],
                })

            elif name == "stop_app":
                self._stop_fn(self.project_dir)
                self._log.debug("stop_app")
                return json.dumps({"ok": True})

            else:
                return json.dumps({"error": f"unknown tool: {name}"})

        except Exception as exc:
            self._log.warning("tool %s error: %s", name, exc)
            return json.dumps({"error": str(exc)})

    # ------------------------------------------------------------------
    # Agent loops
    # ------------------------------------------------------------------

    def _agent_loop(self, prompt: str, tools: list) -> None:
        if _ARGS.provider == "anthropic":
            self._loop_anthropic(prompt, tools)
        else:
            self._loop_openrouter(prompt, tools)

    def _loop_anthropic(self, prompt: str, tools: list) -> None:
        import anthropic as _ant
        client   = _ant.Anthropic(api_key=_ANTHROPIC_KEY)
        messages = [{"role": "user", "content": prompt}]

        for iteration in range(_MAX_ITERS):
            with client.messages.stream(
                model=_MODEL, max_tokens=16000,
                tools=tools, messages=messages,
            ) as stream:
                response = stream.get_final_message()

            self._log.debug("iter %d  stop=%s", iteration, response.stop_reason)

            if response.stop_reason == "tool_use":
                tool_results = []
                for block in response.content:
                    if block.type == "tool_use":
                        result = self._dispatch(block.name, block.input)
                        tool_results.append({
                            "type":        "tool_result",
                            "tool_use_id": block.id,
                            "content":     result,
                        })
                messages.append({"role": "assistant", "content": response.content})
                messages.append({"role": "user",      "content": tool_results})
            else:
                break
        else:
            self._log.warning("agent_loop hit max iterations (%d)", _MAX_ITERS)

    def _loop_openrouter(self, prompt: str, tools: list) -> None:
        import httpx
        import urllib.request
        from openai import OpenAI

        proxies   = urllib.request.getproxies()
        proxy_url = proxies.get("https") or proxies.get("http")
        client    = OpenAI(
            api_key=_OPENROUTER_KEY,
            base_url=_OPENROUTER_BASE,
            http_client=httpx.Client(
                proxy=proxy_url,
                timeout=httpx.Timeout(300.0, connect=10.0),
            ),
            default_headers={
                "HTTP-Referer": "https://github.com/tdd-web-agent",
                "X-Title":      "tdd-web-agent",
            },
        )
        oai_tools = _to_oai_tools(tools) if tools else None
        messages  = [{"role": "user", "content": prompt}]

        for iteration in range(_MAX_ITERS):
            kwargs: dict = {"model": _MODEL, "max_tokens": 16000, "messages": messages}
            if oai_tools:
                kwargs["tools"]       = oai_tools
                kwargs["tool_choice"] = "auto"

            result = self._call_streaming(client, kwargs)
            self._log.debug("iter %d  finish=%s", iteration, result.finish_reason)

            if not result.tool_calls:
                break

            messages.append(result.msg_dict)
            for tc in result.tool_calls:
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {}
                tool_out = self._dispatch(tc.function.name, args)
                self._log.debug("  tool %s → %s", tc.function.name, str(tool_out)[:120])
                messages.append({
                    "role":         "tool",
                    "tool_call_id": tc.id,
                    "content":      tool_out,
                })
        else:
            self._log.warning("agent_loop hit max iterations (%d)", _MAX_ITERS)

    def _call_streaming(self, client, kwargs: dict):
        """Streaming call with 3-retry; accumulates tool_calls from SSE chunks."""
        import time as _time

        last_exc = None
        for _attempt in range(3):
            try:
                stream = client.chat.completions.create(**kwargs, stream=True,
                                                        stream_options={"include_usage": True})
                content_parts:  list = []
                tool_calls_map: dict = {}
                finish_reason        = None
                usage_in = usage_out = 0

                for chunk in stream:
                    delta = chunk.choices[0].delta if chunk.choices else None
                    if chunk.choices:
                        finish_reason = chunk.choices[0].finish_reason or finish_reason
                    if hasattr(chunk, "usage") and chunk.usage:
                        usage_in  = chunk.usage.prompt_tokens or 0
                        usage_out = chunk.usage.completion_tokens or 0
                    if delta is None:
                        continue
                    if delta.content:
                        content_parts.append(delta.content)
                    if delta.tool_calls:
                        for tc_delta in delta.tool_calls:
                            idx = tc_delta.index
                            if idx not in tool_calls_map:
                                tool_calls_map[idx] = {
                                    "id":              tc_delta.id or "",
                                    "name":            (tc_delta.function.name or "") if tc_delta.function else "",
                                    "arguments_parts": [],
                                }
                            if tc_delta.id:
                                tool_calls_map[idx]["id"] = tc_delta.id
                            if tc_delta.function:
                                if tc_delta.function.name:
                                    tool_calls_map[idx]["name"] = tc_delta.function.name
                                if tc_delta.function.arguments:
                                    tool_calls_map[idx]["arguments_parts"].append(tc_delta.function.arguments)

                content    = "".join(content_parts)
                tool_calls = []
                for idx in sorted(tool_calls_map):
                    tc = tool_calls_map[idx]
                    tool_calls.append(SimpleNamespace(
                        id       = tc["id"],
                        type     = "function",
                        function = SimpleNamespace(
                            name      = tc["name"],
                            arguments = "".join(tc["arguments_parts"]),
                        ),
                    ))
                msg_dict = {
                    "role":       "assistant",
                    "content":    content,
                    "tool_calls": [
                        {
                            "id":       tc.id,
                            "type":     "function",
                            "function": {
                                "name":      tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in tool_calls
                    ] if tool_calls else [],
                }
                return SimpleNamespace(
                    content       = content,
                    tool_calls    = tool_calls if tool_calls else None,
                    finish_reason = finish_reason,
                    msg_dict      = msg_dict,
                    usage         = SimpleNamespace(
                        prompt_tokens=usage_in, completion_tokens=usage_out
                    ),
                )

            except Exception as _exc:
                last_exc = _exc
                self._log.warning("streaming call failed (attempt %d/3): %s — retrying in 10s",
                                  _attempt + 1, _exc)
                if _attempt < 2:
                    _time.sleep(10)

        raise last_exc


# ---------------------------------------------------------------------------
# Single (sample × condition) runner
# ---------------------------------------------------------------------------

def _deploy(tmpdir: str) -> str:
    """stop → start → return url. Raises RuntimeError on failure."""
    stop_app(tmpdir)
    app_info = start_app(tmpdir, timeout=_TIMEOUT_APP)
    return app_info["url"]


def run_one(sample: dict, condition: str, sample_idx: int) -> dict:
    """
    Run one sample × condition combination.
    Returns {condition, attempts, final_score, best_score}.
    """
    question     = sample["question"]
    gt_checklist = _normalise_checklist(sample["checklist"])
    max_attempts = 1 if condition == "D" else _MAX_ATTEMPTS

    _banner(f"Sample {sample_idx + 1}  Cond {condition}  ({_COND_LABELS[condition]})")
    log.info("Checklist (%d items): %s", len(gt_checklist), gt_checklist[:2])

    attempt_log = []

    with tempfile.TemporaryDirectory(prefix=f"ab_{sample_idx}_{condition}_") as tmpdir:

        def _start_fn(d):  return start_app(d, timeout=_TIMEOUT_APP)
        def _judge_fn(cl, url): return screenshot_and_judge(cl, url)
        def _stop_fn(d):   stop_app(d)

        agent = HTMLAPIDevAgent(
            project_dir  = tmpdir,
            question     = question,
            sample_idx   = sample_idx,
            tdd          = (condition == "C"),
            start_app_fn = _start_fn,
            judge_fn     = _judge_fn,
            stop_app_fn  = _stop_fn,
        )

        # ------------------------------------------------------------------
        # Condition B — incremental, 5 items per chunk
        # ------------------------------------------------------------------
        _B_CHUNK = 5
        if condition == "B":
            chunk_size   = _B_CHUNK
            n_chunks     = (len(gt_checklist) + chunk_size - 1) // chunk_size
            chunks       = [gt_checklist[i*chunk_size:(i+1)*chunk_size]
                            for i in range(n_chunks)]

            for ci, chunk in enumerate(chunks):
                items_so_far = gt_checklist[: (ci + 1) * chunk_size]
                log.info("── Chunk %d/%d (%d items) ──", ci+1, n_chunks, len(chunk))

                # Implement or extend
                if ci == 0:
                    agent.implement_chunk(chunk)
                else:
                    agent.extend(gt_checklist[:ci*chunk_size], chunk)

                html_path = Path(tmpdir) / "index.html"
                if not html_path.exists():
                    log.error("index.html missing after chunk %d", ci + 1)
                    attempt_log.append({
                        "attempt": ci + 1, "phase": f"chunk_{ci+1}",
                        "score": 0.0, "results": [],
                        "error": "index.html not created",
                    })
                    continue

                # Deploy + judge items so far
                try:
                    url = _deploy(tmpdir)
                except RuntimeError as exc:
                    log.error("start_app failed: %s", exc)
                    attempt_log.append({
                        "attempt": ci + 1, "phase": f"chunk_{ci+1}",
                        "score": 0.0, "results": [], "error": str(exc),
                    })
                    continue

                try:
                    judge_out = _run(screenshot_and_judge(items_so_far, url))
                finally:
                    stop_app(tmpdir)

                attempt_log.append({
                    "attempt": ci + 1, "phase": f"chunk_{ci+1}",
                    "score":   judge_out["score"],
                    "results": judge_out["results"],
                })
                log.info("Chunk %d  score=%.1f%%", ci + 1, judge_out["score"])

                # Fix loop for this chunk
                for fix_num in range(_K_B):
                    failed = [r for r in judge_out["results"] if r["verdict"] == "fail"]
                    if not failed:
                        break
                    log.info("Fix %d/%d chunk %d  (%d failures)", fix_num+1, _K_B, ci+1, len(failed))
                    agent.fix(failed)
                    try:
                        url = _deploy(tmpdir)
                    except RuntimeError as exc:
                        log.error("start_app failed during fix: %s", exc)
                        break
                    try:
                        judge_out = _run(screenshot_and_judge(items_so_far, url))
                    finally:
                        stop_app(tmpdir)
                    attempt_log.append({
                        "attempt": ci + 1, "phase": f"chunk_{ci+1}_fix{fix_num+1}",
                        "score":   judge_out["score"],
                        "results": judge_out["results"],
                    })
                    log.info("Fix %d chunk %d  score=%.1f%%", fix_num+1, ci+1, judge_out["score"])

            # Final full-checklist judge
            if (Path(tmpdir) / "index.html").exists():
                try:
                    url = _deploy(tmpdir)
                    final_judge = _run(screenshot_and_judge(gt_checklist, url))
                    stop_app(tmpdir)
                    attempt_log.append({
                        "attempt": len(gt_checklist) + 1, "phase": "final",
                        "score":   final_judge["score"],
                        "results": final_judge["results"],
                    })
                    log.info("B final score=%.1f%%", final_judge["score"])
                except Exception as exc:
                    log.error("B final judge failed: %s", exc)

        # ------------------------------------------------------------------
        # Conditions A, C, D — implement-once outer loop
        # ------------------------------------------------------------------
        else:
            last_results = []

            for attempt in range(1, max_attempts + 1):
                log.info("── Attempt %d/%d ──", attempt, max_attempts)

                if attempt == 1:
                    agent.implement(gt_checklist)
                else:
                    failed = [r for r in last_results if r["verdict"] == "fail"]
                    if not failed:
                        break
                    agent.fix(failed)

                html_path = Path(tmpdir) / "index.html"
                if not html_path.exists():
                    log.error("index.html missing after attempt %d", attempt)
                    attempt_log.append({
                        "attempt": attempt, "score": 0.0, "results": [],
                        "error": "index.html not created",
                    })
                    if condition == "C":
                        break   # C drives its own loop; if no file, agent failed
                    continue

                # For C: agent may have already called start_app internally.
                # Do a final external judge for consistent scoring.
                stop_app(tmpdir)
                try:
                    url = _deploy(tmpdir)
                except RuntimeError as exc:
                    log.error("start_app failed: %s", exc)
                    attempt_log.append({
                        "attempt": attempt, "score": 0.0, "results": [],
                        "error": str(exc),
                    })
                    break

                try:
                    judge_out = _run(screenshot_and_judge(gt_checklist, url))
                finally:
                    stop_app(tmpdir)

                score        = judge_out["score"]
                last_results = judge_out["results"]
                log.info(
                    "Attempt %d  score=%.1f%%  pass=%d/%d",
                    attempt, score,
                    sum(1 for r in last_results if r["verdict"] == "pass"),
                    len(last_results),
                )

                attempt_log.append({
                    "attempt": attempt,
                    "score":   score,
                    "results": last_results,
                })

                if score == 100.0:
                    log.info("All items passed — stopping early")
                    break

                # C is a single-invocation agentic loop — no external retry
                if condition == "C":
                    break

    # Score from the last "phase=final" entry for B, or last entry for A/C/D
    final_entries = [e for e in attempt_log if e.get("phase") == "final"] or attempt_log
    final_score = final_entries[-1]["score"] if final_entries else 0.0
    best_score  = max((e["score"] for e in attempt_log), default=0.0)

    return {
        "condition":   condition,
        "attempts":    attempt_log,
        "final_score": final_score,
        "best_score":  best_score,
    }


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

def _banner(msg: str) -> None:
    bar = "=" * 64
    log.info("\n%s\n  %s\n%s", bar, msg, bar)


def _verdict_icon(verdict: str) -> str:
    return "✓" if verdict == "pass" else "✗"


def print_sample_report(sample: dict, cond_results: dict) -> None:
    print(f"\n{'═' * 64}")
    print(f"  [{sample['difficulty']}] {sample['class']}")
    print(f"  {sample['question'][:100]}")
    print(f"{'═' * 64}")
    for cond in _CONDITIONS:
        r = cond_results.get(cond)
        if r is None:
            continue
        print(f"\n  Condition {cond} ({_COND_LABELS[cond]})")
        print(f"  final={r['final_score']:.1f}%  best={r['best_score']:.1f}%  "
              f"attempts={len(r['attempts'])}")
        # show last full-checklist results
        last = next(
            (e for e in reversed(r["attempts"]) if e.get("phase") in (None, "final")),
            r["attempts"][-1] if r["attempts"] else {},
        )
        for item in last.get("results", []):
            icon = _verdict_icon(item["verdict"])
            print(f"    {icon} {item['item'][:75]}")


def write_report(samples: list, all_cond_results: list) -> Path:
    report_path = RESULTS / "report.md"
    lines = [
        "# ArtifactsBench Evaluation Report\n",
        f"**Model:** `{_MODEL}`  |  "
        f"**Provider:** `{_ARGS.provider}`  |  "
        f"**Judge:** `claude-sonnet-4-6`  |  "
        f"**Samples:** {_N_SAMPLES}  |  "
        f"**Conditions:** {', '.join(_CONDITIONS)}  |  "
        f"**Max attempts (A):** {_MAX_ATTEMPTS}  |  "
        f"**K_B:** {_K_B}\n",
        f"**Run:** `{_TS}`\n",
        "## Condition Descriptions\n",
        "| Condition | Description |",
        "|-----------|-------------|",
    ]
    for c in _CONDITIONS:
        lines.append(f"| {c} | {_COND_LABELS[c]} |")
    lines.append("")

    # Summary table
    lines.append("## Results Summary\n")
    header = "| Sample | Class | Difficulty |" + "".join(
        f" {c} final% | {c} best% |" for c in _CONDITIONS
    )
    sep = "|--------|-------|------------|" + "----------|---------|" * len(_CONDITIONS)
    lines.append(header)
    lines.append(sep)

    for si, sample in enumerate(samples):
        row_results = {
            r["condition"]: r
            for r in all_cond_results if r["sample_idx"] == si
        }
        cells = ""
        for cond in _CONDITIONS:
            r = row_results.get(cond, {})
            final = f"{r.get('final_score', 0):.1f}"
            best  = f"{r.get('best_score',  0):.1f}"
            cells += f" {final} | {best} |"
        lines.append(f"| {si+1} | {sample['class']} | {sample['difficulty']} |{cells}")

    # Averages
    avg_cells = ""
    for cond in _CONDITIONS:
        runs = [r for r in all_cond_results if r["condition"] == cond]
        avg_f = sum(r["final_score"] for r in runs) / len(runs) if runs else 0
        avg_b = sum(r["best_score"]  for r in runs) / len(runs) if runs else 0
        avg_cells += f" **{avg_f:.1f}** | **{avg_b:.1f}** |"
    lines.append(f"| **avg** | | |{avg_cells}")
    lines.append("")

    # Per-sample detail
    lines.append("## Per-Sample Detail\n")
    for si, sample in enumerate(samples):
        lines.append(f"### Sample {si+1}: {sample['class']} / {sample['difficulty']}\n")
        lines.append(f"**Question:** {sample['question'][:300]}\n")
        cl = _normalise_checklist(sample["checklist"])
        lines.append(f"**GT checklist ({len(cl)} items):**\n")
        for item in cl:
            lines.append(f"- {item}")
        lines.append("")

        for cond in _CONDITIONS:
            runs = [r for r in all_cond_results
                    if r["sample_idx"] == si and r["condition"] == cond]
            if not runs:
                continue
            r = runs[0]
            lines.append(
                f"**Condition {cond}** — final={r['final_score']:.1f}%  "
                f"best={r['best_score']:.1f}%\n"
            )
            for entry in r["attempts"]:
                phase   = entry.get("phase", "")
                passes  = sum(1 for x in entry["results"] if x["verdict"] == "pass")
                total   = len(entry["results"])
                phase_s = f" ({phase})" if phase else ""
                lines.append(
                    f"*Attempt {entry['attempt']}{phase_s}:* "
                    f"score={entry['score']:.1f}%  ({passes}/{total} items pass)"
                )
                if entry.get("error"):
                    lines.append(f"  ERROR: {entry['error']}")
                for item in entry.get("results", []):
                    icon = "✓" if item["verdict"] == "pass" else "✗"
                    lines.append(f"  - {icon} {item['item']} — {item['reason']}")
                lines.append("")

    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    _banner(
        f"ARTIFACTSBENCH  provider={_ARGS.provider}  model={_MODEL}  "
        f"n={_N_SAMPLES}  conds={_CONDITIONS}  "
        f"max_A={_MAX_ATTEMPTS}  K_B={_K_B}  max_iters_C={_MAX_ITERS}"
    )
    log.info("Results dir: %s", RESULTS)

    samples = fetch_artifacts_samples(n=_N_SAMPLES, seed=_SEED)
    log.info("Samples: %s", [(s["class"], s["difficulty"]) for s in samples])

    all_cond_results = []
    total   = len(samples) * len(_CONDITIONS)
    workers = min(10, total)

    log.info("Parallelism: %d workers  (%d total runs)", workers, total)

    def _pair_path(si, cond):
        return RESULTS / f"sample_{si+1:02d}_{cond}.json"

    def _task(si_cond):
        si, condition = si_cond
        # Resume: skip if already saved
        p = _pair_path(si, condition)
        if p.exists():
            r = json.loads(p.read_text())
            log.info("▶ RESUME sample=%d  cond=%s  final=%.1f%%",
                     si + 1, condition, r["final_score"])
            return r
        sample = samples[si]
        log.info("▶ START  sample=%d  cond=%s  [%s/%d items]",
                 si + 1, condition, sample["class"], len(sample["checklist"]))
        r = run_one(sample, condition, si)
        r["sample_idx"] = si
        p.write_text(json.dumps(r))   # save immediately
        log.info("▶ DONE   sample=%d  cond=%s  final=%.1f%%",
                 si + 1, condition, r["final_score"])
        return r

    pairs = [(si, cond) for si in range(len(samples)) for cond in _CONDITIONS]

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(_task, p): p for p in pairs}
        for f in as_completed(futures):
            try:
                all_cond_results.append(f.result())
            except Exception as exc:
                si, cond = futures[f]
                log.error("sample=%d cond=%s FAILED: %s", si + 1, cond, exc)

    # Summary to stdout
    _banner("SUMMARY")
    col = "".join(f"  {c} fin%  {c} best" for c in _CONDITIONS)
    print(f"\n{'─'*70}")
    print(f"  {'Class':<22} {'Diff':<8}{col}")
    print(f"{'─'*70}")

    for si, sample in enumerate(samples):
        row = {r["condition"]: r for r in all_cond_results if r["sample_idx"] == si}
        cells = "".join(
            f"  {row[c]['final_score']:>5.1f}%  {row[c]['best_score']:>5.1f}%"
            if c in row else "   —      —  "
            for c in _CONDITIONS
        )
        print(f"  {sample['class']:<22} {sample['difficulty']:<8}{cells}")

    print(f"{'─'*70}")
    avg_cells = "".join(
        f"  {sum(r['final_score'] for r in all_cond_results if r['condition']==c)/len(samples):>5.1f}%"
        f"  {sum(r['best_score']  for r in all_cond_results if r['condition']==c)/len(samples):>5.1f}%"
        for c in _CONDITIONS
    )
    print(f"  {'AVERAGE':<22} {'':8}{avg_cells}")
    print(f"{'─'*70}\n")

    for si, sample in enumerate(samples):
        cond_results = {r["condition"]: r for r in all_cond_results if r["sample_idx"] == si}
        print_sample_report(sample, cond_results)

    # Save
    json_path   = RESULTS / "results.json"
    json_path.write_text(json.dumps(all_cond_results, indent=2))
    report_path = write_report(samples, all_cond_results)

    log.info("JSON    → %s", json_path)
    log.info("Report  → %s", report_path)
    log.info("Log     → %s", LOG_FILE)
    print(f"\nResults saved to: {RESULTS}")


if __name__ == "__main__":
    main()
