"""
RQ1 — Top-level orchestrator.

Runs both RQ1.1 (test generation coverage) and RQ1.2 (testing agent accuracy)
and generates a summary report.

Usage
-----
    cd code/
    python run_rq1.py [--skip-rq11] [--skip-rq12] [--n 10] [--seed 42]

Outputs
-------
    results/rq1_<timestamp>/
        rq1_coverage.jsonl          — per-item coverage results
        rq1_testing_agent.jsonl     — per-test verdict results
        report.md                   — human-readable summary
"""

import argparse
import asyncio
import json
import os
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))


def main():
    parser = argparse.ArgumentParser(description="RQ1: Module reliability experiments")
    parser.add_argument("--skip-rq11", action="store_true", help="Skip RQ1.1 coverage")
    parser.add_argument("--skip-rq12", action="store_true", help="Skip RQ1.2 testing agent")
    parser.add_argument("--bench", default="data/test.jsonl")
    parser.add_argument("--converted", default="data/converted_test_cases.jsonl")
    parser.add_argument("--fixtures", default="tests/fixtures/rq1_apps")
    parser.add_argument("--n", type=int, default=10, help="Number of WebGen-Bench cases for RQ1.1")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = f"results/rq1_{ts}"
    os.makedirs(out_dir, exist_ok=True)

    report_lines = [
        f"# RQ1 Experiment Report",
        f"",
        f"**Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"",
    ]

    # ------------------------------------------------------------------
    # RQ1.1: Test Generation Coverage
    # ------------------------------------------------------------------
    rq11_summary = None
    if not args.skip_rq11:
        print("=" * 60)
        print("RQ1.1: Test Generation Coverage")
        print("=" * 60)

        from experiment.rq1_coverage import run_coverage
        rq11_out = os.path.join(out_dir, "rq1_coverage.jsonl")
        rq11_summary = run_coverage(
            bench_path=args.bench,
            converted_path=args.converted,
            n=args.n,
            seed=args.seed,
            out_path=rq11_out,
        )

        report_lines.extend([
            "## RQ1.1: Test Generation Coverage",
            "",
            f"- Cases evaluated: {rq11_summary['num_cases']}",
            f"- **Mean coverage: {rq11_summary['mean_coverage']:.1%}**",
            f"- Total tokens: {rq11_summary['total_input_tokens']} input, {rq11_summary['total_output_tokens']} output",
            "",
            f"Detailed results: `{rq11_out}`",
            "",
        ])
    else:
        report_lines.extend(["## RQ1.1: Skipped", ""])

    # ------------------------------------------------------------------
    # RQ1.2: Testing Agent Accuracy
    # ------------------------------------------------------------------
    rq12_summary = None
    if not args.skip_rq12:
        print("\n" + "=" * 60)
        print("RQ1.2: Testing Agent Accuracy")
        print("=" * 60)

        from experiment.rq1_testing_agent import run_testing_agent_eval
        rq12_out = os.path.join(out_dir, "rq1_testing_agent.jsonl")
        rq12_summary = asyncio.run(run_testing_agent_eval(
            fixtures_dir=args.fixtures,
            out_path=rq12_out,
        ))

        if "error" not in rq12_summary:
            report_lines.extend([
                "## RQ1.2: Testing Agent Accuracy",
                "",
                f"- Total test evaluations: {rq12_summary['total_tests']}",
                f"- **Overall accuracy: {rq12_summary['overall_accuracy']}%**",
                f"- Correct variant accuracy: {rq12_summary['correct_variant_accuracy']}%",
                f"- Broken variant accuracy: {rq12_summary['broken_variant_accuracy']}%",
                "",
                "### Per-app accuracy",
                "",
                "| App | Accuracy |",
                "|-----|----------|",
            ])
            for app, acc in rq12_summary.get("per_app_accuracy", {}).items():
                report_lines.append(f"| {app} | {acc}% |")
            report_lines.extend([
                "",
                f"Detailed results: `{rq12_out}`",
                "",
            ])
        else:
            report_lines.extend([
                "## RQ1.2: Error",
                f"Error: {rq12_summary['error']}",
                "",
            ])
    else:
        report_lines.extend(["## RQ1.2: Skipped", ""])

    # ------------------------------------------------------------------
    # Write report
    # ------------------------------------------------------------------
    report_path = os.path.join(out_dir, "report.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))

    print(f"\n{'=' * 60}")
    print(f"Report written to: {report_path}")
    print(f"Results directory: {out_dir}")


if __name__ == "__main__":
    main()
