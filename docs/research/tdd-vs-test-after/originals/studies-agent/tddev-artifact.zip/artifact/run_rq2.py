#!/usr/bin/env python3
"""
RQ2 Experiment — WebGen-Bench cases × 4 conditions (A, B, C, D).

Dev agent  : APIDevAgent — direct LLM agentic loop, no CLI dependency.
             --provider anthropic  → Primary experiment    (Claude Sonnet 4.6)
             --provider together   → Cross-model experiment (Qwen via Together AI)
Parallelism: 2 cases run simultaneously; within each case A→B→C→D sequentially.

Conditions
----------
A  Whole-project  standard prompt,  deploy→test→fix loop (max 5)
B  Incremental    standard prompt,  per-feature loop (max 5)
C  Agentic TDD    TDD prompt + deploy/test tools exposed to agent, single invocation
D  Baseline       standard prompt,  implement once → test once, no loop

Cases (10 sampled with seed=42 from WebGen-Bench)
--------------------------------------------------
000082  food distribution website
000015  clinical office website
000004  sports analytics website
000095  ringtones/wallpapers download
000036  price comparison website
000032  whistleblower secrets/awareness website
000029  forum webpage
000018  house cleaning service website
000014  credit repair company website
000087  entertainment directory website

Usage
-----
    cd code
    # Primary (Claude Sonnet 4.6):
    python run_rq2.py --provider anthropic

    # Cross-model (Qwen via Together AI):
    python run_rq2.py --provider together

    # Quick 1-case test:
    python run_rq2.py --provider together --n-cases 1 --conditions D

    # Resume a previous run:
    python run_rq2.py --provider anthropic --n-cases 5 --resume results/rq2_anthropic_20260326_120000
"""

import argparse
import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# CLI args
# ---------------------------------------------------------------------------

def _parse_args():
    parser = argparse.ArgumentParser(description="RQ2 experiment")
    parser.add_argument(
        "--provider", choices=["anthropic", "together", "openrouter"], required=True,
        help=(
            "'anthropic' = primary (Claude Sonnet 4.6 via Anthropic); "
            "'together' = cross-model (Qwen via Together AI); "
            "'openrouter' = primary (Claude via OpenRouter, cheaper)"
        ),
    )
    parser.add_argument(
        "--model", default=None,
        help=(
            "Model override. "
            "openrouter: e.g. 'anthropic/claude-haiku-4-5' (smoke tests) or "
            "'anthropic/claude-sonnet-4-6' (full run). "
            "together: e.g. 'Qwen/Qwen3.5-397B-A17B'. "
            "Omit for provider default."
        ),
    )
    parser.add_argument(
        "--n-cases", type=int, default=5,
        help="Number of cases to run (default: 5)",
    )
    parser.add_argument(
        "--conditions", nargs="+", default=["A", "B", "C", "D"],
        choices=["A", "B", "C", "D"],
        help="Conditions to run (default: A B C D)",
    )
    parser.add_argument(
        "--resume", metavar="DIR",
        help="Resume from a previous results directory (skip completed pairs).",
    )
    parser.add_argument(
        "--replace", action="store_true",
        help="Write results back into --resume dir instead of creating new one.",
    )
    return parser.parse_args()

_ARGS = _parse_args()

if _ARGS.replace and not _ARGS.resume:
    sys.exit("ERROR: --replace requires --resume <DIR>.")

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

def _load_key(env_var: str) -> str:
    return os.environ.get(env_var, "").strip()

_ANTHROPIC_KEY   = _load_key("ANTHROPIC_API_KEY")
_TOGETHER_KEY    = _load_key("TOGETHER_API_KEY")
_OPENROUTER_KEY  = _load_key("OPENROUTER_API_KEY")

if _ARGS.provider == "anthropic" and not _ANTHROPIC_KEY:
    sys.exit("ERROR: ANTHROPIC_API_KEY not set. Copy .env.example to .env and export the variables.")

if _ARGS.provider in ("openrouter", "together") and not _OPENROUTER_KEY:
    sys.exit("ERROR: OPENROUTER_API_KEY not set. Copy .env.example to .env and export the variables.")

# ---------------------------------------------------------------------------
# Output directory + logging
# ---------------------------------------------------------------------------

_TS    = datetime.now().strftime("%Y%m%d_%H%M%S")
_LABEL = _ARGS.provider  # "anthropic" or "together"

if _ARGS.replace:
    RESULTS = Path(_ARGS.resume).resolve()
else:
    RESULTS = Path(__file__).parent / "results" / f"rq2_{_LABEL}_{_TS}"
RESULTS.mkdir(parents=True, exist_ok=True)

LOG_FILE = RESULTS / "rq2.log"

_stream_handler = logging.StreamHandler(sys.stdout)
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
    handlers=[
        logging.FileHandler(str(LOG_FILE), encoding="utf-8"),
        _stream_handler,
    ],
)
log = logging.getLogger("rq2")

# ---------------------------------------------------------------------------
# Model config
# ---------------------------------------------------------------------------

_ANTHROPIC_MODEL   = "claude-sonnet-4-6"
_TOGETHER_MODEL    = "qwen/qwen3.5-397b-a17b"        # Qwen via OpenRouter
_OPENROUTER_MODEL  = "anthropic/claude-sonnet-4-6"   # default for full runs
_OPENROUTER_BASE   = "https://openrouter.ai/api/v1"

if _ARGS.provider == "anthropic":
    _MODEL       = _ARGS.model or _ANTHROPIC_MODEL
    _AGENT_LABEL = f"APIDevAgent (Anthropic / {_MODEL})"
    os.environ["TESTING_AGENT_MODEL"]    = _MODEL
    os.environ["TESTING_AGENT_PROVIDER"] = "anthropic"
    os.environ["TEST_GENERATION_MODEL"]  = _MODEL
elif _ARGS.provider == "openrouter":
    _MODEL       = _ARGS.model or _OPENROUTER_MODEL
    _AGENT_LABEL = f"APIDevAgent (OpenRouter / {_MODEL})"
    os.environ["TESTING_AGENT_MODEL"]    = _MODEL
    os.environ["TESTING_AGENT_PROVIDER"] = "openrouter"
    os.environ["TEST_GENERATION_MODEL"]  = _MODEL
else:
    # together — Qwen via OpenRouter (paper design: cross-model experiment)
    _MODEL       = _ARGS.model or _TOGETHER_MODEL
    _AGENT_LABEL = f"APIDevAgent (OpenRouter / {_MODEL})"
    os.environ["TESTING_AGENT_MODEL"]    = _MODEL
    os.environ["TESTING_AGENT_PROVIDER"] = "openrouter"
    os.environ["TEST_GENERATION_MODEL"]  = _MODEL

# ---------------------------------------------------------------------------
# Project imports  (after env vars)
# ---------------------------------------------------------------------------

from experiment.loader import sample_cases
from experiment.runner import run_case
from experiment.metrics import load_log, summarize
from experiment import token_tracking
from mcp_server.tools.deployment import start_app as _start_app, stop_app as _stop_app
from mcp_server.testing_agent.agent import run_test_case

_MAX_ATTEMPTS   = 5
_MAX_ATTEMPTS_B = 2   # Condition B: cap at K=2 to limit token cost
_N_SAMPLE     = 10
_N_CASES      = _ARGS.n_cases
_CONDITIONS   = _ARGS.conditions
_PARALLEL     = 5
_SEED         = 42

_BENCH_PATH     = Path(__file__).parent / "data" / "test.jsonl"
_CONVERTED_PATH = Path(__file__).parent / "data" / "converted_test_cases.jsonl"

# ---------------------------------------------------------------------------
# Progress tracking
# ---------------------------------------------------------------------------

_progress_lock = threading.Lock()
_progress: dict = {}


def _progress_update(case_id, condition, step, attempt=0):
    with _progress_lock:
        _progress[case_id] = {"condition": condition, "step": step, "attempt": attempt}
        _print_progress()


def _print_progress():
    lines = []
    for cid in sorted(_progress):
        p = _progress[cid]
        if p["attempt"]:
            k = _MAX_ATTEMPTS_B if p["condition"] == "B" else _MAX_ATTEMPTS
            lines.append(f"  [{cid}] Cond {p['condition']} | {p['step']} | attempt {p['attempt']}/{k}")
        else:
            lines.append(f"  [{cid}] Cond {p['condition']} | {p['step']}")
    now = datetime.now().strftime("%H:%M:%S")
    print(f"\n--- Progress @ {now} ---")
    for l in lines:
        print(l)
    print("---", flush=True)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_CRITICAL_BLOCK = """
CRITICAL — the app MUST satisfy ALL of the following or deployment will fail:
1. File structure: package.json + server.js at the project root (no subdirectories)
2. package.json MUST contain: {{"dependencies": {{"express": "^4"}}, "scripts": {{"start": "node server.js"}}}}
3. server.js MUST call: app.listen(process.env.PORT || 3000, '127.0.0.1')
4. You MUST run `npm install` as the FINAL step — verify node_modules/ exists before finishing
5. Use backtick template literals (``) for any string containing ${{...}} — NOT regular quotes
6. Do NOT use JSX, TypeScript, or any syntax requiring a build/transpile step
"""

_IMPLEMENT_ALL = """\
You are building a web application. Create a complete, working Express.js app
that satisfies ALL of the following test cases.

Instruction: {instruction}

Test cases to satisfy:
{test_cases_json}

Requirements:
- Create package.json with express as a dependency and "start": "node server.js"
- Create server.js that listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / that has all UI elements the tests need
- Run `npm install` after creating the files
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)
""" + _CRITICAL_BLOCK

_IMPLEMENT_ALL_TDD = """\
You are building a web application using Test-Driven Development (TDD).
You have tools to write files, run shell commands, and run automated browser tests.

Instruction: {instruction}

Test cases to satisfy:
{test_cases_json}

Requirements:
- Create package.json with express as a dependency and "start": "node server.js"
- Create server.js that listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / with exactly the UI elements the tests need
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)

TDD Workflow:
1. Write server.js + package.json at the project root
2. Run `npm install` via bash
3. Call run_tests with project_dir="{project_dir}" and the test cases you want to check
   — starts a fresh server per test case, runs browser tests, returns pass/fail per test
4. Fix any failures in server.js
5. Repeat from step 3 until all tests pass
STOP after at most 5 calls to run_tests — do not loop forever.

You can pass all test cases or just the ones you are currently fixing.
""" + _CRITICAL_BLOCK

_IMPLEMENT_FEATURE = """\
You are building a web application incrementally. Add the following feature to
the app in this directory. If no app exists yet, create the full Express.js
scaffold plus this feature.

Overall instruction: {instruction}

Feature to implement now:
{tc_json}

Requirements:
- package.json must have express as dependency and "start": "node server.js"
- server.js listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / containing the UI elements for this feature
- Run `npm install` if you create or update package.json
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)
- Do not break any previously passing features
""" + _CRITICAL_BLOCK

_FIX = """\
The automated browser tests failed. Fix the app so the tests pass.

Failure report:
{report}

Instructions:
- Read server.js to understand the current state
- Make the minimal changes needed to fix the failures
- Do not remove any existing passing functionality
- Ensure server.js exists at project root with app.listen(process.env.PORT || 3000, '127.0.0.1')
- Ensure package.json has express dependency and "start": "node server.js"
- Run `npm install` if node_modules/ is missing or package.json was changed
- Use backtick template literals (``) for strings with ${{...}}
"""

# ---------------------------------------------------------------------------
# Tool schemas (Anthropic format; converted to OAI format for Together)
# ---------------------------------------------------------------------------

_TOOLS_BASE = [
    {
        "name": "write_file",
        "description": (
            "Write content to a file (path relative to project root). "
            "Creates parent directories automatically."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path":    {"type": "string", "description": "File path relative to project root, e.g. 'server.js'"},
                "content": {"type": "string", "description": "Complete file content"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "read_file",
        "description": "Read a file (path relative to project root).",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to project root"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "bash",
        "description": (
            "Run a shell command in the project directory. "
            "Use for: npm install, listing files, checking syntax. "
            "Returns stdout + stderr (truncated to 3000 chars)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Shell command to run"},
            },
            "required": ["command"],
        },
    },
]

_TOOLS_DEPLOY = [
    {
        "name": "run_tests",
        "description": (
            "Deploy and test your app. Starts a fresh server for each test case, "
            "runs browser tests, stops it. Returns pass/fail/partial per test. "
            "Pass all test cases or just the ones you are currently fixing."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "project_dir": {
                    "type": "string",
                    "description": "Project directory path (the directory you are working in).",
                },
                "test_cases": {
                    "type": "array",
                    "description": "Test case dicts to evaluate — full list or a subset.",
                    "items": {"type": "object"},
                },
            },
            "required": ["test_cases"],
        },
    },
]


def _to_oai_tools(anthropic_tools: list) -> list:
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t["description"],
                "parameters": t["input_schema"],
            },
        }
        for t in anthropic_tools
    ]


# ---------------------------------------------------------------------------
# APIDevAgent
# ---------------------------------------------------------------------------

_MAX_AGENT_ITERS = 15


class APIDevAgent:
    """
    Dev agent backed by a direct LLM agentic loop.

    provider="anthropic" -> Claude Sonnet 4.6 via Anthropic SDK
    provider="together"  -> Qwen via Together AI (OpenAI-compatible)

    For Condition C (tdd=True), run_tests_fn is wired in at construction
    and exposed as a tool to the LLM.
    """

    def __init__(
        self,
        project_dir: str,
        instruction: str,
        case_id: str,
        tdd: bool = False,
        run_tests_fn=None,
    ):
        self.project_dir   = project_dir
        self.instruction   = instruction
        self.case_id       = case_id
        self.tdd           = tdd
        self._run_tests_fn = run_tests_fn
        self._log = logging.getLogger(f"agent.{case_id}")

    def implement(self, test_cases) -> None:
        if isinstance(test_cases, dict):
            prompt = _IMPLEMENT_FEATURE.format(
                instruction=self.instruction,
                tc_json=json.dumps(test_cases, indent=2),
            )
            label = f"feature {test_cases.get('test_id', '?')}"
        elif self.tdd:
            prompt = _IMPLEMENT_ALL_TDD.format(
                instruction=self.instruction,
                test_cases_json=json.dumps(test_cases, indent=2),
                project_dir=self.project_dir,
            )
            label = f"{len(test_cases)} TC(s) [TDD+tools]"
        else:
            prompt = _IMPLEMENT_ALL.format(
                instruction=self.instruction,
                test_cases_json=json.dumps(test_cases, indent=2),
            )
            label = f"{len(test_cases)} TC(s)"

        tools = _TOOLS_BASE + (_TOOLS_DEPLOY if self.tdd else [])
        self._log.info("implement(%s)  provider=%s", label, _ARGS.provider)
        self._agent_loop(prompt, tools)

    def fix(self, report: str) -> None:
        self._log.info("fix()  provider=%s", _ARGS.provider)
        self._agent_loop(_FIX.format(report=report), _TOOLS_BASE)

    def _agent_loop(self, prompt: str, tools: list) -> None:
        t0 = time.monotonic()
        if _ARGS.provider == "anthropic":
            self._loop_anthropic(prompt, tools)
        else:
            self._loop_openrouter(prompt, tools)
        self._log.info("agent_loop done  %.1fs", time.monotonic() - t0)

    # ------------------------------------------------------------------
    # Anthropic backend
    # ------------------------------------------------------------------

    def _loop_anthropic(self, prompt: str, tools: list) -> None:
        import anthropic
        client   = anthropic.Anthropic(api_key=_ANTHROPIC_KEY)
        messages = [{"role": "user", "content": prompt}]

        for iteration in range(_MAX_AGENT_ITERS):
            with client.messages.stream(
                model=_MODEL,
                max_tokens=16000,
                tools=tools,
                messages=messages,
            ) as stream:
                response = stream.get_final_message()
            token_tracking.record(
                "dev_agent",
                response.usage.input_tokens,
                response.usage.output_tokens,
            )
            self._log.debug(
                "iter %d  stop=%s  in=%d out=%d",
                iteration, response.stop_reason,
                response.usage.input_tokens, response.usage.output_tokens,
            )

            if response.stop_reason == "end_turn":
                break

            if response.stop_reason == "tool_use":
                tool_results = []
                for block in response.content:
                    if block.type == "tool_use":
                        result = self._dispatch(block.name, block.input)
                        self._log.debug("  tool %s -> %s", block.name, str(result)[:120])
                        tool_results.append({
                            "type":        "tool_result",
                            "tool_use_id": block.id,
                            "content":     str(result),
                        })
                messages.append({"role": "assistant", "content": response.content})
                messages.append({"role": "user",      "content": tool_results})
            else:
                self._log.warning("Unexpected stop_reason: %s", response.stop_reason)
                break
        else:
            self._log.warning("agent_loop hit max iterations (%d)", _MAX_AGENT_ITERS)

    # ------------------------------------------------------------------
    # Together AI (OpenAI-compatible) backend
    # ------------------------------------------------------------------

    def _call_together_streaming(self, client, kwargs: dict):
        """Call OpenAI-compatible API using streaming to avoid proxy idle-connection timeout.

        Accumulates streamed chunks into a synthetic response-like object.
        Retries up to 3 times on any API or stream error (handles mid-stream drops).
        """
        import time as _time
        from types import SimpleNamespace

        last_exc = None
        for _attempt in range(3):
            try:
                stream = client.chat.completions.create(**kwargs, stream=True)

                content_parts:  list = []
                tool_calls_map: dict = {}
                finish_reason        = None
                usage_in = usage_out = 0

                for chunk in stream:
                    delta = chunk.choices[0].delta if chunk.choices else None
                    if chunk.choices:
                        finish_reason = chunk.choices[0].finish_reason or finish_reason
                    if hasattr(chunk, "usage") and chunk.usage:
                        usage_in  = chunk.usage.prompt_tokens or 0
                        usage_out = chunk.usage.completion_tokens or 0
                    if delta is None:
                        continue
                    if delta.content:
                        content_parts.append(delta.content)
                    if delta.tool_calls:
                        for tc_delta in delta.tool_calls:
                            idx = tc_delta.index
                            if idx not in tool_calls_map:
                                tool_calls_map[idx] = {
                                    "id":              tc_delta.id or "",
                                    "name":            (tc_delta.function.name or "") if tc_delta.function else "",
                                    "arguments_parts": [],
                                }
                            if tc_delta.id:
                                tool_calls_map[idx]["id"] = tc_delta.id
                            if tc_delta.function:
                                if tc_delta.function.name:
                                    tool_calls_map[idx]["name"] = tc_delta.function.name
                                if tc_delta.function.arguments:
                                    tool_calls_map[idx]["arguments_parts"].append(tc_delta.function.arguments)

                # Stream completed successfully — build result and return
                content    = "".join(content_parts)
                tool_calls = []
                for idx in sorted(tool_calls_map):
                    tc = tool_calls_map[idx]
                    tool_calls.append(SimpleNamespace(
                        id       = tc["id"],
                        type     = "function",
                        function = SimpleNamespace(
                            name      = tc["name"],
                            arguments = "".join(tc["arguments_parts"]),
                        ),
                    ))

                msg_dict = {
                    "role":       "assistant",
                    "content":    content,
                    "tool_calls": [
                        {
                            "id":       tc.id,
                            "type":     "function",
                            "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                        }
                        for tc in tool_calls
                    ] if tool_calls else [],
                }
                usage = SimpleNamespace(prompt_tokens=usage_in, completion_tokens=usage_out)
                return SimpleNamespace(
                    content       = content,
                    tool_calls    = tool_calls if tool_calls else None,
                    finish_reason = finish_reason,
                    msg_dict      = msg_dict,
                    usage         = usage,
                )

            except Exception as _exc:
                last_exc = _exc
                if _attempt < 2:
                    self._log.warning(
                        "Streaming call failed (attempt %d/3): %s — retrying in 10s",
                        _attempt + 1, _exc,
                    )
                    _time.sleep(10)

        raise last_exc

    def _loop_together(self, prompt: str, tools: list) -> None:
        import httpx
        from openai import OpenAI
        import urllib.request
        proxies   = urllib.request.getproxies()
        proxy_url = proxies.get("https") or proxies.get("http")
        client    = OpenAI(
            api_key=_TOGETHER_KEY,
            base_url=_TOGETHER_BASE,
            http_client=httpx.Client(
                proxy=proxy_url,
                timeout=httpx.Timeout(300.0, connect=10.0),
            ),
        )
        oai_tools = _to_oai_tools(tools) if tools else None
        messages  = [{"role": "user", "content": prompt}]

        for iteration in range(_MAX_AGENT_ITERS):
            kwargs: dict = {"model": _MODEL, "max_tokens": 16000, "messages": messages}
            if oai_tools:
                kwargs["tools"]       = oai_tools
                kwargs["tool_choice"] = "auto"

            result = self._call_together_streaming(client, kwargs)

            if result.usage:
                token_tracking.record(
                    "dev_agent",
                    result.usage.prompt_tokens or 0,
                    result.usage.completion_tokens or 0,
                )
            self._log.debug("iter %d  finish=%s", iteration, result.finish_reason)

            if not result.tool_calls:
                break

            messages.append(result.msg_dict)
            for tc in result.tool_calls:
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {}
                tool_out = self._dispatch(tc.function.name, args)
                self._log.debug("  tool %s -> %s", tc.function.name, str(tool_out)[:120])
                messages.append({
                    "role":         "tool",
                    "tool_call_id": tc.id,
                    "content":      str(tool_out),
                })
        else:
            self._log.warning("agent_loop hit max iterations (%d)", _MAX_AGENT_ITERS)

    # ------------------------------------------------------------------
    # OpenRouter backend (OpenAI-compatible, streaming)
    # ------------------------------------------------------------------

    def _loop_openrouter(self, prompt: str, tools: list) -> None:
        """OpenRouter backend — identical streaming approach to Together."""
        import httpx
        from openai import OpenAI
        import urllib.request
        proxies   = urllib.request.getproxies()
        proxy_url = proxies.get("https") or proxies.get("http")
        client    = OpenAI(
            api_key=_OPENROUTER_KEY,
            base_url=_OPENROUTER_BASE,
            http_client=httpx.Client(
                proxy=proxy_url,
                timeout=httpx.Timeout(300.0, connect=10.0),
            ),
            default_headers={
                "HTTP-Referer": "https://github.com/tdd-web-agent",
                "X-Title": "tdd-web-agent",
            },
        )
        oai_tools = _to_oai_tools(tools) if tools else None
        messages  = [{"role": "user", "content": prompt}]

        for iteration in range(_MAX_AGENT_ITERS):
            kwargs: dict = {"model": _MODEL, "max_tokens": 16000, "messages": messages}
            if oai_tools:
                kwargs["tools"]       = oai_tools
                kwargs["tool_choice"] = "auto"

            result = self._call_together_streaming(client, kwargs)

            if result.usage:
                token_tracking.record(
                    "dev_agent",
                    result.usage.prompt_tokens or 0,
                    result.usage.completion_tokens or 0,
                )
            self._log.debug("iter %d  finish=%s", iteration, result.finish_reason)

            if not result.tool_calls:
                break

            messages.append(result.msg_dict)
            for tc in result.tool_calls:
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {}
                tool_out = self._dispatch(tc.function.name, args)
                self._log.debug("  tool %s -> %s", tc.function.name, str(tool_out)[:120])
                messages.append({
                    "role":         "tool",
                    "tool_call_id": tc.id,
                    "content":      str(tool_out),
                })
        else:
            self._log.warning("agent_loop hit max iterations (%d)", _MAX_AGENT_ITERS)

    # ------------------------------------------------------------------
    # Tool dispatch
    # ------------------------------------------------------------------

    def _dispatch(self, name: str, inp: dict) -> str:
        try:
            if name == "write_file":
                path = Path(self.project_dir) / inp["path"]
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(inp["content"], encoding="utf-8")
                return f"wrote {len(inp['content'])} bytes to {inp['path']}"

            elif name == "read_file":
                path = Path(self.project_dir) / inp["path"]
                if not path.exists():
                    return f"Error: {inp['path']} not found"
                return path.read_text(encoding="utf-8")[:4000]

            elif name == "bash":
                result = subprocess.run(
                    inp["command"], shell=True,
                    cwd=self.project_dir,
                    capture_output=True, text=True, timeout=60,
                )
                out = result.stdout
                if result.stderr:
                    out += "\nSTDERR:\n" + result.stderr
                if result.returncode != 0:
                    out += f"\n[exit code: {result.returncode}]"
                return out[:3000]

            elif name == "run_tests":
                if self._run_tests_fn is None:
                    return json.dumps({"error": "run_tests not available in this condition"})
                # project_dir is fixed per agent instance — ignore any passed value
                return json.dumps(self._run_tests_fn(inp.get("test_cases", [])))

            else:
                return f"Unknown tool: {name}"

        except Exception as exc:
            self._log.error("tool %s error: %s", name, exc)
            return f"Error: {exc}"


# ---------------------------------------------------------------------------
# Adapters
# ---------------------------------------------------------------------------

def make_adapters(project_dir: str, case_id: str):
    url_box: list = [None, ""]
    alog = logging.getLogger(f"adapter.{case_id}")

    def start_app_fn() -> dict:
        """Stop then start; update url_box. Returns info dict (used by Condition C agent)."""
        alog.info("stop -> start  dir=%s", project_dir)
        _stop_app(project_dir)
        try:
            info = _start_app(project_dir)
            url_box[0] = info["url"]
            url_box[1] = ""
            alog.info("App running  url=%s  port=%s", info["url"], info["port"])
            return {"url": info["url"], "port": info["port"]}
        except Exception as exc:
            url_box[0] = None
            url_box[1] = str(exc)
            alog.error("start_app FAILED: %s", exc)
            return {"error": str(exc)}

    def stop_app_fn() -> None:
        _stop_app(project_dir)
        url_box[0] = None
        url_box[1] = ""

    def run_tests_fn(test_cases) -> dict:
        if isinstance(test_cases, dict):
            test_cases = [test_cases]
        alog.info("run_tests  tcs=%d", len(test_cases))
        results = []
        for tc in test_cases:
            # Per-TC restart: fresh server for each test case, independent evaluation
            start_app_fn()
            if url_box[0] is None:
                alog.warning("  TC %s — server failed to start: %s", tc["test_id"], url_box[1])
                results.append({
                    "test_id":        tc["test_id"],
                    "result":         "fail",
                    "failure_report": f"Server failed to start: {url_box[1]}",
                    "trajectory":     [],
                })
                continue
            app_url = url_box[0]
            alog.info("  TC %s -- %s  url=%s", tc["test_id"], tc["feature"], app_url)
            loop = asyncio.new_event_loop()
            outcome = loop.run_until_complete(run_test_case(tc, app_url))
            loop.close()
            verdict = outcome["result"]
            alog.info("  TC %s -> %s", tc["test_id"], verdict)
            if outcome["failure_report"]:
                alog.warning("  TC %s failure: %s", tc["test_id"], outcome["failure_report"])
            results.append({
                "test_id":        tc["test_id"],
                "result":         verdict,
                "failure_report": outcome["failure_report"],
                "trajectory":     outcome["trajectory"],
            })
        verdict_str = "  ".join(f"{r['test_id']}:{r['result'].upper()[0]}" for r in results)
        alog.info("Test results: %s", verdict_str)
        return {"results": results}

    # No-op — run_tests_fn manages server lifecycle per TC
    def start_app_void() -> None:
        pass

    return start_app_void, run_tests_fn, start_app_fn, stop_app_fn, url_box


# ---------------------------------------------------------------------------
# run_one_condition
# ---------------------------------------------------------------------------

def run_one_condition(case: dict, condition: str) -> dict:
    case_id  = case["id"]
    log_path = str(RESULTS / f"case_{case_id}_{condition}.jsonl")
    tdd_flag = (condition == "C")
    clog     = logging.getLogger(f"run.{case_id}")

    clog.info("=" * 70)
    clog.info("  START  CASE %s | COND %s | %s", case_id, condition, _AGENT_LABEL)
    clog.info("  Instruction: %s", case["instruction"][:100])
    clog.info("  Test cases:  %d", len(case["test_cases"]))
    clog.info("=" * 70)

    _progress_update(case_id, condition, "starting")
    token_tracking.reset()

    with tempfile.TemporaryDirectory(prefix=f"rq2_{case_id}_{condition}_") as tmpdir:
        start_app_void, run_tests_fn, start_app_fn, stop_app_fn, url_box = \
            make_adapters(tmpdir, case_id)

        agent = APIDevAgent(
            project_dir  = tmpdir,
            instruction  = case["instruction"],
            case_id      = case_id,
            tdd          = tdd_flag,
            run_tests_fn = run_tests_fn if tdd_flag else None,
        )

        attempt_counter = [0]

        def start_app_verbose():
            _progress_update(case_id, condition, "deploying", attempt_counter[0])
            start_app_void()

        def run_tests_verbose(tcs):
            _progress_update(case_id, condition, "testing", attempt_counter[0])
            return run_tests_fn(tcs)

        orig_implement = agent.implement
        def implement_verbose(tcs):
            attempt_counter[0] += 1
            _progress_update(case_id, condition, "implementing", attempt_counter[0])
            orig_implement(tcs)
        agent.implement = implement_verbose

        orig_fix = agent.fix
        def fix_verbose(report):
            attempt_counter[0] += 1
            _progress_update(case_id, condition, "fixing", attempt_counter[0])
            orig_fix(report)
        agent.fix = fix_verbose

        try:
            summary = run_case(
                case         = case,
                condition    = condition,
                dev_agent    = agent,
                start_app    = start_app_verbose,
                run_tests    = run_tests_verbose,
                log_path     = log_path,
                max_attempts = _MAX_ATTEMPTS_B if condition == "B" else _MAX_ATTEMPTS,
            )
        finally:
            _stop_app(tmpdir)
            with _progress_lock:
                _progress.pop(case_id, None)

    totals  = token_tracking.get_totals()
    entries = load_log(log_path)
    max_k   = _MAX_ATTEMPTS_B if condition == "B" else _MAX_ATTEMPTS
    metrics = summarize(entries, max_k=max_k)

    clog.info(
        "DONE  case=%s  cond=%s  final_pass=%s  acc@1=%.0f%%  acc@%d=%.0f%%  tokens=%d",
        case_id, condition, summary["final_pass"],
        metrics.get("accuracy@1", 0),
        max_k, metrics.get(f"accuracy@{max_k}", 0),
        totals["total_tokens"],
    )

    return {
        "case_id":       case_id,
        "condition":     condition,
        "final_pass":    summary["final_pass"],
        "metrics":       metrics,
        "log_path":      log_path,
        "input_tokens":  totals["input_tokens"],
        "output_tokens": totals["output_tokens"],
        "total_tokens":  totals["total_tokens"],
    }


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

_COND_LABELS = {
    "A": "Whole-project (hard enforcement, K=5)",
    "B": "Incremental   (hard enforcement, K=5)",
    "C": "Agentic TDD   (soft enforcement, K=1)",
    "D": "Baseline      (no tools, K=1)",
}


def build_summary(all_results: list) -> dict:
    per_cond: dict = {c: [] for c in _CONDITIONS}
    for r in all_results:
        if r["condition"] in per_cond:
            per_cond[r["condition"]].append(r)

    cond_summary = {}
    for cond, runs in per_cond.items():
        if not runs:
            continue
        n_total      = len(runs)
        n_eventually = sum(1 for r in runs if r["final_pass"])
        metrics: dict = {}
        for k in range(1, _MAX_ATTEMPTS + 1):
            key = f"accuracy@{k}"
            metrics[key] = sum(r["metrics"].get(key, 0.0) for r in runs) / n_total if n_total else 0.0
        metrics["never_passed"]        = n_total - n_eventually
        metrics["n_eventually_passed"] = n_eventually
        metrics["n_total"]             = n_total
        metrics["final_pass_rate"]     = f"{n_eventually}/{n_total}"
        metrics["total_input_tokens"]  = sum(r.get("input_tokens",  0) for r in runs)
        metrics["total_output_tokens"] = sum(r.get("output_tokens", 0) for r in runs)
        metrics["total_tokens"]        = sum(r.get("total_tokens",  0) for r in runs)
        cond_summary[cond] = metrics

    per_case: dict = {}
    for r in all_results:
        per_case.setdefault(r["case_id"], {})[r["condition"]] = {
            "final_pass":   r["final_pass"],
            "total_tokens": r.get("total_tokens", 0),
            **r["metrics"],
        }
    return {"per_condition": cond_summary, "per_case_condition": per_case}


def write_report(summary: dict, all_results: list, cases: list) -> Path:
    report_path = RESULTS / "report.md"
    case_map    = {c["id"]: c for c in cases}
    lines       = []

    lines.append(f"# RQ2 Experiment Results ({_LABEL})\n")
    lines.append(
        f"**Agent:** `{_AGENT_LABEL}`  |  "
        f"**Model:** `{_MODEL}`  |  "
        f"**Cases:** {_N_CASES}  |  "
        f"**Conditions:** {', '.join(_CONDITIONS)}  |  "
        f"**Max attempts (A/B):** {_MAX_ATTEMPTS}\n"
    )
    lines.append(f"**Run:** `{_TS}`\n")
    lines.append("**Cases:**\n")
    for case in cases:
        lines.append(f"- `{case['id']}`: {case['instruction'][:80]}")
    lines.append("")

    lines.append("## Accuracy Summary\n")
    lines.append("| Condition | pass-rate | acc@1 | acc@2 | acc@3 | acc@4 | acc@5 | tokens (total) |")
    lines.append("|-----------|-----------|-------|-------|-------|-------|-------|----------------|")
    for cond in _CONDITIONS:
        m    = summary["per_condition"].get(cond, {})
        rate = m.get("final_pass_rate", "?")
        toks = m.get("total_tokens", 0)
        if cond in ("A", "B"):
            acc_cells = " | ".join(f"{m.get(f'accuracy@{k}', 0):.1f}%" for k in range(1, _MAX_ATTEMPTS + 1))
        else:
            acc_cells = f"{m.get('accuracy@1', 0):.1f}% | -- | -- | -- | --"
        lines.append(f"| {cond} ({_COND_LABELS[cond]}) | {rate} | {acc_cells} | {toks:,} |")
    lines.append("")

    for cond in _CONDITIONS:
        m     = summary["per_condition"].get(cond, {})
        label = _COND_LABELS[cond]
        lines.append(f"## Condition {cond} -- {label}\n")
        lines.append(
            f"Pass rate: **{m.get('final_pass_rate', '?')}**  |  "
            f"Tokens: **{m.get('total_tokens', 0):,}** "
            f"(in={m.get('total_input_tokens', 0):,} / out={m.get('total_output_tokens', 0):,})\n"
        )
        if cond in ("A", "B"):
            lines.append("| Case | instruction | pass? | acc@1 | acc@2 | acc@3 | acc@4 | acc@5 |")
            lines.append("|------|-------------|-------|-------|-------|-------|-------|-------|")
        else:
            lines.append("| Case | instruction | pass? | accuracy |")
            lines.append("|------|-------------|-------|----------|")

        for r in sorted([x for x in all_results if x["condition"] == cond], key=lambda x: x["case_id"]):
            short  = case_map.get(r["case_id"], {}).get("instruction", "")[:50]
            passed = "YES" if r["final_pass"] else "no"
            if cond in ("A", "B"):
                vals = " | ".join(f"{r['metrics'].get(f'accuracy@{k}', 0):.1f}%" for k in range(1, _MAX_ATTEMPTS + 1))
                lines.append(f"| {r['case_id']} | {short} | {passed} | {vals} |")
            else:
                lines.append(f"| {r['case_id']} | {short} | {passed} | {r['metrics'].get('accuracy@1', 0):.1f}% |")

        if cond in ("A", "B"):
            avg_vals = " | ".join(f"{m.get(f'accuracy@{k}', 0):.1f}%" for k in range(1, _MAX_ATTEMPTS + 1))
            lines.append(f"| **avg** | | | {avg_vals} |")
        else:
            lines.append(f"| **avg** | | | {m.get('accuracy@1', 0):.1f}% |")
        lines.append("")

    lines.append("## Attempt Log\n")
    for r in sorted(all_results, key=lambda x: (x["case_id"], x["condition"])):
        cid     = r["case_id"]
        cond    = r["condition"]
        instr   = case_map.get(cid, {}).get("instruction", "")[:60]
        entries = load_log(r["log_path"])
        lines.append(f"### [{cid}] Cond {cond} -- {instr}\n")
        if not entries:
            lines.append("_No log entries._\n")
            continue
        lines.append("| attempt | TC | result | failure (truncated) |")
        lines.append("|---------|-----|--------|---------------------|")
        for e in entries:
            fr = (e.get("failure_report") or "")[:120].replace("|", "\\|")
            lines.append(f"| {e['attempt']} | {e['tc_id']} | {e['result']} | {fr} |")
        lines.append("")

    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path


# ---------------------------------------------------------------------------
# Resume
# ---------------------------------------------------------------------------

def _load_resumed_results(resume_dir: str, cases: list) -> list:
    rdir     = Path(resume_dir).resolve()
    resumed  = []
    case_map = {c["id"]: c for c in cases}

    for jsonl in sorted(rdir.glob("case_*_*.jsonl")):
        m = re.match(r"case_(.+)_([ABCD])\.jsonl$", jsonl.name)
        if not m or jsonl.stat().st_size == 0:
            continue
        case_id, condition = m.group(1), m.group(2)
        entries = load_log(str(jsonl))
        if not entries:
            continue

        metrics    = summarize(entries, max_k=_MAX_ATTEMPTS)
        case_tcs   = case_map.get(case_id, {}).get("test_cases", [])
        n_tcs      = len(case_tcs) if case_tcs else 1
        final_pass = False
        for att in sorted(set(e["attempt"] for e in entries)):
            att_e = [e for e in entries if e["attempt"] == att]
            if all(e["result"] == "pass" for e in att_e) and len(att_e) >= n_tcs:
                final_pass = True
                break

        if _ARGS.replace:
            log_path = str(jsonl)
        else:
            dest = RESULTS / jsonl.name
            if not dest.exists():
                shutil.copy2(jsonl, dest)
            log_path = str(dest)

        resumed.append({
            "case_id": case_id, "condition": condition,
            "final_pass": final_pass, "metrics": metrics, "log_path": log_path,
            "input_tokens": 0, "output_tokens": 0, "total_tokens": 0,
        })
        log.info("  RESUMED  case=%s  cond=%s  final_pass=%s", case_id, condition, final_pass)
    return resumed


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    log.info("=" * 70)
    log.info("  RQ2 EXPERIMENT START")
    log.info("  Agent:       %s", _AGENT_LABEL)
    log.info("  Model:       %s", _MODEL)
    log.info("  Cases:       first %d of %d (seed=%d)", _N_CASES, _N_SAMPLE, _SEED)
    log.info("  Conditions:  %s", ", ".join(_CONDITIONS))
    log.info("  Results dir: %s", RESULTS)
    log.info("=" * 70)

    all_sampled = sample_cases(
        bench_path     = str(_BENCH_PATH),
        converted_path = str(_CONVERTED_PATH),
        n              = _N_SAMPLE,
        seed           = _SEED,
    )
    cases = all_sampled[:_N_CASES]

    log.info("Cases to run:")
    for i, c in enumerate(cases, 1):
        log.info("  %d. %s  (%d TCs)  %s", i, c["id"], len(c.get("test_cases", [])), c["instruction"][:70])

    missing = [c["id"] for c in cases if not c.get("test_cases")]
    if missing:
        log.error("Cases with no converted test cases: %s", missing)
        sys.exit(1)

    all_results: list = []
    skip_pairs:  set  = set()

    if _ARGS.resume:
        resumed = _load_resumed_results(_ARGS.resume, cases)
        all_results.extend(resumed)
        skip_pairs = {(r["case_id"], r["condition"]) for r in resumed}
        log.info("Resumed %d completed pairs", len(skip_pairs))

    cases_to_run = [
        (case, [c for c in _CONDITIONS if (case["id"], c) not in skip_pairs])
        for case in cases
        if any((case["id"], c) not in skip_pairs for c in _CONDITIONS)
    ]

    if not cases_to_run:
        log.info("All pairs already completed.")
    else:
        log.info("Starting parallel execution (%d workers)...", _PARALLEL)

        def _run_remaining(case_and_conds):
            case, remaining = case_and_conds
            results = []
            for condition in _CONDITIONS:
                if condition in remaining:
                    try:
                        results.append(run_one_condition(case, condition))
                    except Exception as exc:
                        log.error(
                            "Case %s Cond %s CRASHED (skipping): %s",
                            case["id"], condition, exc, exc_info=True,
                        )
            return results

        with ThreadPoolExecutor(max_workers=_PARALLEL) as pool:
            futures = {pool.submit(_run_remaining, cc): cc[0]["id"] for cc in cases_to_run}
            done    = 0
            for future in as_completed(futures):
                case_id = futures[future]
                done   += 1
                try:
                    all_results.extend(future.result())
                    log.info("Case %s complete (%d/%d done)", case_id, done, len(cases_to_run))
                except Exception as exc:
                    log.error("Case %s FAILED: %s", case_id, exc, exc_info=True)

    summary      = build_summary(all_results)
    summary_path = RESULTS / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    report_path  = write_report(summary, all_results, cases)

    log.info("")
    log.info("FINAL ACCURACY TABLE")
    log.info("%-6s  %-12s  %-7s  %-7s  %-7s  %-7s  %-7s  %s",
             "Cond", "pass-rate", "acc@1", "acc@2", "acc@3", "acc@4", "acc@5", "tokens")
    log.info("-" * 72)
    for cond in _CONDITIONS:
        m    = summary["per_condition"].get(cond, {})
        rate = m.get("final_pass_rate", "?")
        toks = m.get("total_tokens", 0)
        accs = [f"{m.get(f'accuracy@{k}', 0):5.1f}%" for k in range(1, _MAX_ATTEMPTS + 1)]
        if cond not in ("A", "B"):
            accs = [accs[0]] + ["     --"] * 4
        log.info("%-6s  %-12s  %s  %d", cond, rate, "  ".join(accs), toks)

    log.info("")
    log.info("Summary -> %s", summary_path)
    log.info("Report  -> %s", report_path)
    log.info("Log     -> %s", LOG_FILE)


if __name__ == "__main__":
    main()
