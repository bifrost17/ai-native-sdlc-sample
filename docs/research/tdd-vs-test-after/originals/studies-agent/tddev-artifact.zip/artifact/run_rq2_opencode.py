#!/usr/bin/env python3
"""
RQ2 Cross-Agent Experiment — OpenCode + Claude Sonnet 4.6, 4 conditions (A, B, C, D).

Same WebGen-Bench cases and same protocol as run_rq2.py (primary).

Output
------
results/rq2_opencode_<ts>/
    rq2_opencode.log            full DEBUG log
    case_<id>_<cond>.jsonl      per-run attempt log (20 files)
    summary.json                accuracy@k + token cost per condition
    report.md                   human-readable tables

Usage
-----
    cd code
    python run_rq2_opencode.py
    python run_rq2_opencode.py --n-cases 1 --conditions D
    python run_rq2_opencode.py --n-cases 10 --resume results/rq2_opencode_20260326_120000
    python run_rq2_opencode.py --n-cases 10 --resume results/rq2_opencode_20260326_120000 --replace
"""

import argparse
import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# CLI args
# ---------------------------------------------------------------------------

def _parse_args():
    parser = argparse.ArgumentParser(description="RQ2 OpenCode cross-agent experiment")
    parser.add_argument(
        "--provider", choices=["anthropic", "openrouter"], default="anthropic",
        help="'anthropic' = cross-agent (OpenCode + Sonnet 4.6); "
             "'openrouter' = cross-model (OpenCode + Qwen via OpenRouter)",
    )
    parser.add_argument(
        "--n-cases", type=int, default=5,
        help="Number of cases to run (default: 5, first N of 10 sampled)",
    )
    parser.add_argument(
        "--conditions", nargs="+", default=["A", "B", "C", "D"],
        help="Conditions to run (default: A B C D)",
    )
    parser.add_argument(
        "--resume", metavar="DIR",
        help="Path to a previous results directory. Completed (case, condition) "
             "pairs whose JSONL log files exist there will be skipped.",
    )
    parser.add_argument(
        "--replace", action="store_true",
        help="Write new results back into the --resume directory instead of "
             "creating a fresh timestamped directory. Requires --resume.",
    )
    return parser.parse_args()

_ARGS = _parse_args()

if _ARGS.replace and not _ARGS.resume:
    sys.exit("ERROR: --replace requires --resume <DIR>.")

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

_ANTHROPIC_KEY  = os.environ.get("ANTHROPIC_API_KEY", "").strip()
_OPENROUTER_KEY = os.environ.get("OPENROUTER_API_KEY", "").strip()

if not _ANTHROPIC_KEY:
    sys.exit("ERROR: ANTHROPIC_API_KEY not set. Copy .env.example to .env and export the variables.")
if _ARGS.provider == "openrouter" and not _OPENROUTER_KEY:
    sys.exit("ERROR: OPENROUTER_API_KEY not set. Copy .env.example to .env and export the variables.")
os.environ["ANTHROPIC_API_KEY"] = _ANTHROPIC_KEY

# ---------------------------------------------------------------------------
# Output directory + logging
# ---------------------------------------------------------------------------

_TS        = datetime.now().strftime("%Y%m%d_%H%M%S")
_DIR_LABEL = f"rq2_opencode_{_ARGS.provider}_{_TS}"

if _ARGS.replace:
    RESULTS = Path(_ARGS.resume).resolve()
else:
    RESULTS = Path(__file__).parent / "results" / _DIR_LABEL
RESULTS.mkdir(parents=True, exist_ok=True)

LOG_FILE = RESULTS / "rq2_opencode.log"

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
    handlers=[
        logging.FileHandler(str(LOG_FILE), encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("rq2_oc")

# ---------------------------------------------------------------------------
# Config (env vars MUST be set before importing testing_agent/token_tracking)
# ---------------------------------------------------------------------------

_MAX_ATTEMPTS   = 5
_MAX_ATTEMPTS_B = 2
_N_SAMPLE       = 10
_N_CASES        = _ARGS.n_cases
_CONDITIONS     = _ARGS.conditions
_PARALLEL       = 3   # OpenCode + node processes are heavier than pure API calls
_SEED           = 42

_BENCH_PATH     = Path(__file__).parent / "data" / "test.jsonl"
_CONVERTED_PATH = Path(__file__).parent / "data" / "converted_test_cases.jsonl"
_CODE_DIR       = str(Path(__file__).parent)

# OpenCode binary
_OPENCODE_BIN = str(Path.home() / ".npm-global" / "bin" / "opencode")
if not Path(_OPENCODE_BIN).exists():
    import shutil as _sh
    _OPENCODE_BIN = _sh.which("opencode") or _OPENCODE_BIN

# Model
_SONNET_MODEL       = "claude-sonnet-4-6"
_QWEN_MODEL         = "qwen/qwen3.5-397b-a17b"

if _ARGS.provider == "openrouter":
    _OC_MODEL       = f"openrouter/{_QWEN_MODEL}"
    _BACKBONE_MODEL = _QWEN_MODEL
    _AGENT_LABEL    = f"OpenCode + Qwen3.5-397B (cross-model/cross-agent)"
    os.environ["TESTING_AGENT_MODEL"]    = _QWEN_MODEL
    os.environ["TEST_GENERATION_MODEL"]  = _QWEN_MODEL
    os.environ["TESTING_AGENT_PROVIDER"] = "openrouter"
else:
    _OC_MODEL       = f"anthropic/{_SONNET_MODEL}"
    _BACKBONE_MODEL = _SONNET_MODEL
    _AGENT_LABEL    = f"OpenCode + {_SONNET_MODEL} (cross-agent)"
    os.environ["TESTING_AGENT_MODEL"]    = f"anthropic/{_SONNET_MODEL}"
    os.environ["TEST_GENERATION_MODEL"]  = f"anthropic/{_SONNET_MODEL}"
    os.environ["TESTING_AGENT_PROVIDER"] = "openrouter"

# ---------------------------------------------------------------------------
# Project imports (after env vars are configured)
# ---------------------------------------------------------------------------

from experiment.loader import sample_cases
from experiment.runner import run_case
from experiment.metrics import load_log, summarize
from mcp_server.tools.deployment import start_app as _start_app, stop_app as _stop_app
from mcp_server.testing_agent.agent import run_test_case

# ---------------------------------------------------------------------------
# OpenCode config
# ---------------------------------------------------------------------------

def _opencode_config(mcp_project_dir: str = None) -> dict:
    """
    Return opencode config dict.

    If mcp_project_dir is provided (Condition C), include MCP server config
    so the model can call start_app / stop_app / run_tests via MCP.
    """
    if _ARGS.provider == "openrouter":
        provider_cfg = {
            "openrouter": {
                "options": {
                    "apiKey": _OPENROUTER_KEY,
                    "baseURL": "https://openrouter.ai/api/v1",
                    "timeout": 1200000,
                    "chunkTimeout": 300000,
                }
            }
        }
    else:
        provider_cfg = {
            "anthropic": {
                "options": {
                    "apiKey": _ANTHROPIC_KEY,
                    "baseURL": "https://api.anthropic.com/v1",
                    "timeout": 1200000,      # 20 min total request timeout
                    "chunkTimeout": 300000,  # 5 min between stream chunks
                }
            }
        }

    cfg: dict = {
        "model": _OC_MODEL,
        "permission": "allow",
        "provider": provider_cfg,
    }
    if mcp_project_dir:
        # OpenCode v1.3.x local MCP format: type=local, command as array, environment dict
        cfg["mcp"] = {
            "tdd-tools": {
                "type": "local",
                "command": [sys.executable, "-m", "mcp_server"],
                "environment": {
                    "PYTHONPATH": _CODE_DIR,
                    "ANTHROPIC_API_KEY": _ANTHROPIC_KEY,
                },
            }
        }
    return cfg


# ---------------------------------------------------------------------------
# Progress tracking (thread-safe)
# ---------------------------------------------------------------------------

_progress_lock = threading.Lock()
_progress: dict = {}


def _progress_update(case_id: str, condition: str, step: str, attempt: int = 0) -> None:
    with _progress_lock:
        _progress[case_id] = {"condition": condition, "step": step, "attempt": attempt}
        _print_progress()


def _print_progress() -> None:
    lines = []
    for cid in sorted(_progress):
        p = _progress[cid]
        cond, step, attempt = p["condition"], p["step"], p["attempt"]
        if attempt:
            lines.append(f"  [{cid}] Cond {cond} | {step} | attempt {attempt}/{_MAX_ATTEMPTS}")
        else:
            lines.append(f"  [{cid}] Cond {cond} | {step}")
    now = datetime.now().strftime("%H:%M:%S")
    print(f"\n--- Progress @ {now} ---")
    for l in lines:
        print(l)
    print("---", flush=True)

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_CRITICAL_BLOCK = """
CRITICAL — the app MUST satisfy ALL of the following or deployment will fail:
1. File structure: package.json + server.js at the project root (no subdirectories)
2. package.json MUST contain: {{"dependencies": {{"express": "^4"}}, "scripts": {{"start": "node server.js"}}}}
3. server.js MUST call: app.listen(process.env.PORT || 3000, '127.0.0.1')
4. You MUST run `npm install` as the FINAL step — verify node_modules/ exists before finishing
5. Use backtick template literals (``) for any string containing ${{...}} — NOT regular quotes
6. Do NOT use JSX, TypeScript, or any syntax requiring a build/transpile step
"""

_IMPLEMENT_ALL = """\
You are building a web application. Create a complete, working Express.js app
that satisfies ALL of the following test cases.

Instruction: {instruction}

Test cases to satisfy:
{test_cases_json}

Requirements:
- Create package.json with express as a dependency and "start": "node server.js"
- Create server.js that listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / that has all UI elements the tests need
- Run `npm install` after creating the files
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)
""" + _CRITICAL_BLOCK

_IMPLEMENT_ALL_TDD = """\
You are building a web application using Test-Driven Development (TDD).
You have tools to write files, run shell commands, and run automated browser tests.

Instruction: {instruction}

Test cases to satisfy:
{test_cases_json}

Requirements:
- Create package.json with express as a dependency and "start": "node server.js"
- Create server.js that listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / with exactly the UI elements the tests need
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)

TDD Workflow:
1. Write server.js + package.json at the project root
2. Run `npm install` via bash
3. Call run_tests with project_dir="{project_dir}" and the test cases you want to check
   — starts a fresh server per test case, runs browser tests, returns pass/fail per test
4. Fix any failures in server.js
5. Repeat from step 3 until all tests pass
STOP after at most 5 calls to run_tests — do not loop forever.

You can pass all test cases or just the ones you are currently fixing.
""" + _CRITICAL_BLOCK

_IMPLEMENT_FEATURE = """\
You are building a web application incrementally. Add the following feature to
the app in this directory. If no app exists yet, create the full Express.js
scaffold plus this feature.

Overall instruction: {instruction}

Feature to implement now:
{tc_json}

Requirements:
- package.json must have express as dependency and "start": "node server.js"
- server.js listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / containing the UI elements for this feature
- Run `npm install` if you create or update package.json
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)
- Do not break any previously passing features
""" + _CRITICAL_BLOCK

_FIX = """\
The automated browser tests failed. Fix the app in this directory so the
tests pass.

Failure report:
{report}

Instructions:
- Read the existing server.js (and any other files) to understand the current state
- Make the minimal changes needed to fix the failures
- Do not remove any existing passing functionality
- Ensure server.js exists at project root with app.listen(process.env.PORT || 3000, '127.0.0.1')
- Ensure package.json has express dependency and "start": "node server.js"
- Run `npm install` if node_modules/ is missing or package.json was changed
- Use backtick template literals (``) for strings with ${{...}}
"""

# ---------------------------------------------------------------------------
# Per-thread asyncio loop
# ---------------------------------------------------------------------------

_thread_local = threading.local()


def _run(coro):
    if not hasattr(_thread_local, "loop") or _thread_local.loop.is_closed():
        _thread_local.loop = asyncio.new_event_loop()
    return _thread_local.loop.run_until_complete(coro)


# ---------------------------------------------------------------------------
# OpenCodeDevAgent
# ---------------------------------------------------------------------------

class OpenCodeDevAgent:
    """
    Dev agent backed by the opencode CLI (v1.3.0+).

    Uses `opencode run "<prompt>" --dir <dir> -m <model>` in non-interactive mode.
    Config is passed via OPENCODE_CONFIG_CONTENT env var (highest priority).

    For Condition C (tdd=True), the MCP server config is injected so the model
    can call start_app / run_tests / stop_app via MCP tools.
    """

    def __init__(
        self,
        project_dir: str,
        instruction: str,
        case_id: str,
        tdd: bool = False,
    ) -> None:
        self.project_dir = project_dir
        self.instruction = instruction
        self.case_id     = case_id
        self.tdd         = tdd
        self._git_initialized = False
        self._log = logging.getLogger(f"agent.{case_id}")

    def _ensure_git(self) -> None:
        """opencode v1.3.0 requires a git repo to track file changes."""
        if self._git_initialized:
            return
        git_dir = Path(self.project_dir) / ".git"
        if not git_dir.exists():
            subprocess.run(
                ["git", "init", "."],
                cwd=self.project_dir,
                capture_output=True,
                timeout=10,
            )
            self._log.debug("Initialized git repo in %s", self.project_dir)
        self._git_initialized = True

    def implement(self, test_cases) -> None:
        if isinstance(test_cases, dict):
            prompt = _IMPLEMENT_FEATURE.format(
                instruction=self.instruction,
                tc_json=json.dumps(test_cases, indent=2),
            )
            label = f"feature {test_cases.get('test_id', '?')}"
        elif self.tdd:
            prompt = _IMPLEMENT_ALL_TDD.format(
                instruction=self.instruction,
                test_cases_json=json.dumps(test_cases, indent=2),
                project_dir=self.project_dir,
            )
            label = f"{len(test_cases)} TC(s) [TDD+MCP]"
        else:
            prompt = _IMPLEMENT_ALL.format(
                instruction=self.instruction,
                test_cases_json=json.dumps(test_cases, indent=2),
            )
            label = f"{len(test_cases)} TC(s)"
        self._log.info("implement(%s)", label)
        mcp_dir = self.project_dir if self.tdd else None
        self._call_opencode(prompt, phase="implement", mcp_project_dir=mcp_dir)

    def fix(self, report: str) -> None:
        self._log.info("fix()")
        self._call_opencode(_FIX.format(report=report), phase="fix")

    def _call_opencode(self, prompt: str, phase: str, mcp_project_dir: str = None) -> None:
        self._ensure_git()
        cmd = [
            _OPENCODE_BIN,
            "run", prompt,
            "--dir", self.project_dir,
            "-m", _OC_MODEL,
        ]
        self._log.info(
            "opencode  phase=%-9s  model=%s  dir=%s",
            phase, _OC_MODEL, self.project_dir,
        )

        config = _opencode_config(mcp_project_dir=mcp_project_dir)
        config_json = json.dumps(config)

        # Always write config to a physical file in the project dir.
        # OPENCODE_CONFIG_CONTENT rejects MCP sections in v1.3.x; a file-based
        # opencode.jsonc in the project root works for all conditions incl. C.
        config_file = Path(self.project_dir) / "opencode.jsonc"
        config_file.write_text(config_json, encoding="utf-8")

        env = {
            **os.environ,
            "ANTHROPIC_API_KEY": _ANTHROPIC_KEY,
            # Keep env var as fallback for non-MCP config; file takes precedence
            # if OpenCode merges them, harmless duplication.
            "OPENCODE_CONFIG_CONTENT": json.dumps({
                k: v for k, v in config.items() if k != "mcp"
            }),
        }

        t0 = time.monotonic()
        result = subprocess.run(
            cmd,
            cwd=self.project_dir,
            capture_output=True,
            text=True,
            timeout=600,
            env=env,
            stdin=subprocess.DEVNULL,   # prevent hanging when run from subprocess
        )
        elapsed = time.monotonic() - t0
        self._log.info(
            "opencode done  phase=%-9s  exit=%d  %.1fs  stdout=%d chars",
            phase, result.returncode, elapsed, len(result.stdout),
        )
        if result.stdout:
            self._log.debug("stdout [%s]:\n%s", phase, result.stdout[:3000])
        if result.stderr:
            self._log.debug("stderr [%s]:\n%s", phase, result.stderr[:1000])
        if result.returncode != 0:
            self._log.warning("opencode exited %d during %s", result.returncode, phase)


# ---------------------------------------------------------------------------
# Adapters
# ---------------------------------------------------------------------------

def make_adapters(project_dir: str, case_id: str):
    url_box: list = [None, ""]
    alog = logging.getLogger(f"adapter.{case_id}")

    def start_app_fn() -> None:
        alog.info("stop -> start  dir=%s", project_dir)
        _stop_app(project_dir)
        try:
            loop = asyncio.new_event_loop()
            info = loop.run_until_complete(_start_app(project_dir)) if asyncio.iscoroutinefunction(_start_app) else _start_app(project_dir)
            loop.close()
            url_box[0] = info["url"]
            url_box[1] = ""
            alog.info("App running  url=%s  port=%s", info["url"], info["port"])
        except Exception as exc:
            url_box[0] = None
            url_box[1] = str(exc)
            alog.error("start_app FAILED: %s", exc)

    def run_tests_fn(test_cases) -> dict:
        if isinstance(test_cases, dict):
            test_cases = [test_cases]
        alog.info("run_tests  tcs=%d", len(test_cases))
        results = []
        for tc in test_cases:
            # Per-TC restart: fresh server for each test case, independent evaluation
            start_app_fn()
            if url_box[0] is None:
                alog.warning("  TC %s — server failed to start: %s", tc["test_id"], url_box[1])
                results.append({
                    "test_id":        tc["test_id"],
                    "result":         "fail",
                    "failure_report": f"Server failed to start: {url_box[1]}",
                    "trajectory":     [],
                })
                continue
            app_url = url_box[0]
            alog.info("  TC %s — %s  url=%s", tc["test_id"], tc["feature"], app_url)
            outcome = _run(run_test_case(tc, app_url))
            verdict = outcome["result"]
            alog.info("  TC %s -> %s", tc["test_id"], verdict)
            if outcome["failure_report"]:
                alog.warning("  TC %s failure: %s", tc["test_id"], outcome["failure_report"])
            results.append({
                "test_id":        tc["test_id"],
                "result":         verdict,
                "failure_report": outcome["failure_report"],
                "trajectory":     outcome["trajectory"],
            })
        verdict_str = "  ".join(
            f"{r['test_id']}:{r['result'].upper()[0]}" for r in results
        )
        alog.info("Test results: %s", verdict_str)
        return {"results": results}

    # No-op — run_tests_fn manages server lifecycle per TC
    def start_app_void() -> None:
        pass

    return start_app_void, run_tests_fn


# ---------------------------------------------------------------------------
# run_one_condition / run_one_case
# ---------------------------------------------------------------------------

def run_one_condition(case: dict, condition: str) -> dict:
    case_id  = case["id"]
    log_path = str(RESULTS / f"case_{case_id}_{condition}.jsonl")
    tdd_flag = (condition == "C")
    clog     = logging.getLogger(f"run.{case_id}")

    clog.info("=" * 70)
    clog.info("  START  CASE %s | CONDITION %s | %s", case_id, condition, _AGENT_LABEL)
    clog.info("  Instruction: %s", case["instruction"][:100])
    clog.info("  Test cases: %d", len(case["test_cases"]))
    clog.info("=" * 70)

    _progress_update(case_id, condition, "starting")

    with tempfile.TemporaryDirectory(prefix=f"rq2oc_{case_id}_{condition}_", ignore_cleanup_errors=True) as tmpdir:
        agent = OpenCodeDevAgent(
            project_dir=tmpdir,
            instruction=case["instruction"],
            case_id=case_id,
            tdd=tdd_flag,
        )
        start_app_void, run_tests_fn = make_adapters(tmpdir, case_id)

        # Progress wrappers
        attempt_counter = [0]

        def start_app_verbose():
            pass  # server lifecycle managed per-TC inside run_tests_fn

        orig_tests = run_tests_fn
        def run_tests_verbose(tcs):
            _progress_update(case_id, condition, "testing", attempt_counter[0])
            return orig_tests(tcs)

        orig_implement = agent.implement
        def implement_verbose(tcs):
            attempt_counter[0] += 1
            _progress_update(case_id, condition, "implementing", attempt_counter[0])
            orig_implement(tcs)
        agent.implement = implement_verbose

        orig_fix = agent.fix
        def fix_verbose(report):
            attempt_counter[0] += 1
            _progress_update(case_id, condition, "fixing", attempt_counter[0])
            orig_fix(report)
        agent.fix = fix_verbose

        try:
            summary = run_case(
                case         = case,
                condition    = condition,
                dev_agent    = agent,
                start_app    = start_app_verbose,
                run_tests    = run_tests_verbose,
                log_path     = log_path,
                max_attempts = _MAX_ATTEMPTS_B if condition == "B" else _MAX_ATTEMPTS,
            )
        finally:
            _stop_app(tmpdir)
            with _progress_lock:
                _progress.pop(case_id, None)

    entries = load_log(log_path)
    metrics = summarize(entries, max_k=_MAX_ATTEMPTS)

    tokens = summary.get("total_tokens", 0)
    clog.info(
        "DONE  case=%s  cond=%s  final_pass=%s  acc@1=%.0f%%  tokens=%d",
        case_id, condition, summary["final_pass"],
        metrics.get("accuracy@1", 0), tokens,
    )

    return {
        "case_id":       case_id,
        "condition":     condition,
        "final_pass":    summary["final_pass"],
        "metrics":       metrics,
        "log_path":      log_path,
        "input_tokens":  summary.get("input_tokens", 0),
        "output_tokens": summary.get("output_tokens", 0),
        "total_tokens":  summary.get("total_tokens", 0),
    }


def run_one_case(case: dict) -> list:
    case_id = case["id"]
    clog    = logging.getLogger(f"case.{case_id}")
    clog.info(">>> Starting case %s: %s", case_id, case["instruction"][:80])
    results = []
    for condition in _CONDITIONS:
        result = run_one_condition(case, condition)
        results.append(result)
    clog.info("<<< Finished case %s  pass_rate=%s",
              case_id,
              "/".join(str(int(r["final_pass"])) for r in results))
    return results


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

_COND_LABELS = {
    "A": "Whole-project (hard enforcement, K=5)",
    "B": "Incremental   (hard enforcement, K=5)",
    "C": "Agentic TDD   (soft enforcement, K=1)",
    "D": "Baseline      (no tools, K=1)",
}


def build_summary(all_results: list) -> dict:
    per_cond: dict = {c: [] for c in _CONDITIONS}
    for r in all_results:
        per_cond[r["condition"]].append(r)

    cond_summary = {}
    for cond, runs in per_cond.items():
        if not runs:
            continue
        eventually_passed = [r for r in runs if r["final_pass"]]
        n_total      = len(runs)
        n_eventually = len(eventually_passed)

        metrics: dict = {}
        for k in range(1, _MAX_ATTEMPTS + 1):
            key = f"accuracy@{k}"
            metrics[key] = sum(r["metrics"].get(key, 0.0) for r in runs) / n_total if n_total else 0.0

        metrics["never_passed"]        = n_total - n_eventually
        metrics["n_eventually_passed"] = n_eventually
        metrics["n_total"]             = n_total
        metrics["final_pass_rate"]     = f"{n_eventually}/{n_total}"
        metrics["total_input_tokens"]  = sum(r.get("input_tokens", 0)  for r in runs)
        metrics["total_output_tokens"] = sum(r.get("output_tokens", 0) for r in runs)
        metrics["total_tokens"]        = sum(r.get("total_tokens", 0)  for r in runs)
        cond_summary[cond] = metrics

    per_case: dict = {}
    for r in all_results:
        per_case.setdefault(r["case_id"], {})[r["condition"]] = {
            "final_pass":   r["final_pass"],
            "total_tokens": r.get("total_tokens", 0),
            **r["metrics"],
        }

    return {"per_condition": cond_summary, "per_case_condition": per_case}


def write_report(summary: dict, all_results: list, cases: list) -> Path:
    report_path = RESULTS / "report.md"
    case_map    = {c["id"]: c for c in cases}
    lines       = []

    lines.append("# RQ2 OpenCode Cross-Agent Experiment Results\n")
    lines.append(
        f"**Agent:** `OpenCode`  |  "
        f"**Backbone:** `{_BACKBONE_MODEL}`  |  "
        f"**Provider:** `anthropic`  |  "
        f"**Cases:** {_N_CASES}  |  "
        f"**Conditions:** {', '.join(_CONDITIONS)}  |  "
        f"**Max attempts (A/B):** {_MAX_ATTEMPTS}\n"
    )
    lines.append(f"**Run:** `{_TS}`\n")
    lines.append("**Cases:**\n")
    for case in cases:
        lines.append(f"- `{case['id']}`: {case['instruction'][:80]}")
    lines.append("")

    # Accuracy summary table
    lines.append("## Accuracy Summary (all cases)\n")
    lines.append(
        "| Condition | pass-rate | acc@1 | acc@2 | acc@3 | acc@4 | acc@5 "
        "| tokens (total) |"
    )
    lines.append(
        "|-----------|-----------|-------|-------|-------|-------|-------|"
        "----------------|"
    )
    for cond in _CONDITIONS:
        m    = summary["per_condition"].get(cond, {})
        rate = m.get("final_pass_rate", "?")
        toks = m.get("total_tokens", 0)
        if cond in ("A", "B"):
            acc_cells = " | ".join(
                f"{m.get(f'accuracy@{k}', 0):.1f}%"
                for k in range(1, _MAX_ATTEMPTS + 1)
            )
        else:
            acc1 = f"{m.get('accuracy@1', 0):.1f}%"
            acc_cells = f"{acc1} | — | — | — | —"
        lines.append(f"| {cond} ({_COND_LABELS[cond]}) | {rate} | {acc_cells} | {toks:,} |")
    lines.append("")

    # Per-condition detail
    for cond in _CONDITIONS:
        m     = summary["per_condition"].get(cond, {})
        label = _COND_LABELS[cond]
        lines.append(f"## Condition {cond} — {label}\n")
        lines.append(f"Pass rate: **{m.get('final_pass_rate', '?')}**  |  "
                     f"Tokens: **{m.get('total_tokens', 0):,}** "
                     f"(in={m.get('total_input_tokens', 0):,} / "
                     f"out={m.get('total_output_tokens', 0):,})\n")

        if cond in ("A", "B"):
            lines.append("| Case | instruction (short) | pass? | acc@1 | acc@2 | acc@3 | acc@4 | acc@5 |")
            lines.append("|------|---------------------|-------|-------|-------|-------|-------|-------|")
        else:
            lines.append("| Case | instruction (short) | pass? | accuracy |")
            lines.append("|------|---------------------|-------|----------|")

        case_runs = sorted(
            [r for r in all_results if r["condition"] == cond],
            key=lambda r: r["case_id"],
        )
        for r in case_runs:
            short_instr = case_map.get(r["case_id"], {}).get("instruction", "")[:50]
            passed      = "YES" if r["final_pass"] else "no"
            if cond in ("A", "B"):
                acc_vals = " | ".join(
                    f"{r['metrics'].get(f'accuracy@{k}', 0):.1f}%"
                    for k in range(1, _MAX_ATTEMPTS + 1)
                )
                lines.append(f"| {r['case_id']} | {short_instr} | {passed} | {acc_vals} |")
            else:
                acc1 = f"{r['metrics'].get('accuracy@1', 0):.1f}%"
                lines.append(f"| {r['case_id']} | {short_instr} | {passed} | {acc1} |")

        if cond in ("A", "B"):
            avg_vals = " | ".join(
                f"{m.get(f'accuracy@{k}', 0):.1f}%"
                for k in range(1, _MAX_ATTEMPTS + 1)
            )
            lines.append(f"| **avg** | | | {avg_vals} |")
        else:
            avg1 = f"{m.get('accuracy@1', 0):.1f}%"
            lines.append(f"| **avg** | | | {avg1} |")
        lines.append("")

    # Attempt log
    lines.append("## Attempt Log (per run)\n")
    for r in sorted(all_results, key=lambda x: (x["case_id"], x["condition"])):
        cid     = r["case_id"]
        cond    = r["condition"]
        instr   = case_map.get(cid, {}).get("instruction", "")[:60]
        entries = load_log(r["log_path"])
        lines.append(f"### [{cid}] Cond {cond} — {instr}\n")
        if not entries:
            lines.append("_No log entries._\n")
            continue
        lines.append("| attempt | TC | result | failure (truncated) |")
        lines.append("|---------|-----|--------|---------------------|")
        for e in entries:
            fr = (e.get("failure_report") or "")[:120].replace("|", "\\|")
            lines.append(
                f"| {e['attempt']} | {e['tc_id']} | {e['result']} | {fr} |"
            )
        lines.append("")

    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path


# ---------------------------------------------------------------------------
# Resume: load completed results from a previous run
# ---------------------------------------------------------------------------

def _load_resumed_results(resume_dir: str, cases: list) -> list:
    rdir     = Path(resume_dir).resolve()
    resumed  = []
    case_map = {c["id"]: c for c in cases}

    for jsonl in sorted(rdir.glob("case_*_*.jsonl")):
        m = re.match(r"case_(.+)_([ABCD])\.jsonl$", jsonl.name)
        if not m:
            continue
        case_id, condition = m.group(1), m.group(2)
        if jsonl.stat().st_size == 0:
            continue

        entries = load_log(str(jsonl))
        if not entries:
            continue

        metrics = summarize(entries, max_k=_MAX_ATTEMPTS)

        case_tcs = case_map.get(case_id, {}).get("test_cases", [])
        n_tcs    = len(case_tcs) if case_tcs else 1
        final_pass = False
        attempts = sorted(set(e["attempt"] for e in entries))
        for att in attempts:
            att_entries = [e for e in entries if e["attempt"] == att]
            if all(e["result"] == "pass" for e in att_entries) and len(att_entries) >= n_tcs:
                final_pass = True
                break

        if _ARGS.replace:
            log_path = str(jsonl)
        else:
            dest = RESULTS / jsonl.name
            if not dest.exists():
                shutil.copy2(jsonl, dest)
            log_path = str(dest)

        resumed.append({
            "case_id":       case_id,
            "condition":     condition,
            "final_pass":    final_pass,
            "metrics":       metrics,
            "log_path":      log_path,
            "input_tokens":  0,
            "output_tokens": 0,
            "total_tokens":  0,
        })
        log.info("  RESUMED  case=%s  cond=%s  final_pass=%s  (from %s)",
                 case_id, condition, final_pass, jsonl.name)
    return resumed


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    log.info("=" * 70)
    log.info("  RQ2 OPENCODE CROSS-AGENT EXPERIMENT START")
    log.info("  Agent:       OpenCode v1.3.x")
    log.info("  Provider:    anthropic")
    log.info("  Backbone:    %s", _BACKBONE_MODEL)
    log.info("  Cases:       first %d of %d (seed=%d)", _N_CASES, _N_SAMPLE, _SEED)
    log.info("  Conditions:  %s", ", ".join(_CONDITIONS))
    log.info("  Parallelism: %d cases simultaneously", _PARALLEL)
    log.info("  Results dir: %s", RESULTS)
    log.info("  TESTING_AGENT_MODEL: %s", os.environ.get("TESTING_AGENT_MODEL", "?"))
    log.info("  TEST_GENERATION_MODEL: %s", os.environ.get("TEST_GENERATION_MODEL", "?"))
    if _ARGS.resume:
        log.info("  Resume from: %s", _ARGS.resume)
    if _ARGS.replace:
        log.info("  Replace mode: writing into resumed directory")
    log.info("=" * 70)

    # Verify opencode binary exists
    if not Path(_OPENCODE_BIN).exists():
        log.error("opencode binary not found at %s. Install: npm install -g opencode-ai --prefix ~/.npm-global", _OPENCODE_BIN)
        sys.exit(1)
    log.info("  OpenCode bin: %s", _OPENCODE_BIN)

    # Load cases
    all_sampled = sample_cases(
        bench_path     = str(_BENCH_PATH),
        converted_path = str(_CONVERTED_PATH),
        n              = _N_SAMPLE,
        seed           = _SEED,
    )
    cases = all_sampled[:_N_CASES]

    log.info("Cases to run:")
    for i, c in enumerate(cases, 1):
        tcs = len(c.get("test_cases", []))
        log.info("  %d. %s  (%d TCs)  %s", i, c["id"], tcs, c["instruction"][:70])

    missing = [c["id"] for c in cases if not c.get("test_cases")]
    if missing:
        log.error("Cases with no converted test cases: %s", missing)
        sys.exit(1)

    # -----------------------------------------------------------------------
    # Resume: load prior results and figure out what still needs to run
    # -----------------------------------------------------------------------
    all_results: list = []
    skip_pairs: set   = set()

    if _ARGS.resume:
        resumed = _load_resumed_results(_ARGS.resume, cases)
        all_results.extend(resumed)
        skip_pairs = {(r["case_id"], r["condition"]) for r in resumed}
        log.info("Resumed %d completed (case, condition) pairs", len(skip_pairs))

    cases_to_run = []
    for case in cases:
        remaining = [c for c in _CONDITIONS if (case["id"], c) not in skip_pairs]
        if remaining:
            cases_to_run.append((case, remaining))
        else:
            log.info("  Case %s — all conditions already completed, skipping", case["id"])

    if not cases_to_run:
        log.info("All (case, condition) pairs already completed — nothing to run.")
    else:
        total_cases = len(cases_to_run)
        log.info("")
        log.info("Starting parallel execution (%d workers, %d cases to run)...",
                 _PARALLEL, total_cases)

        def _run_remaining(case_and_conds):
            case, remaining_conds = case_and_conds
            case_id = case["id"]
            clog    = logging.getLogger(f"case.{case_id}")
            clog.info(">>> Starting case %s (conditions %s): %s",
                      case_id, ",".join(remaining_conds), case["instruction"][:80])
            results = []
            for condition in _CONDITIONS:  # preserve A→B→C→D order
                if condition not in remaining_conds:
                    continue
                result = run_one_condition(case, condition)
                results.append(result)
            clog.info("<<< Finished case %s  pass_rate=%s",
                      case_id,
                      "/".join(str(int(r["final_pass"])) for r in results))
            return results

        with ThreadPoolExecutor(max_workers=_PARALLEL) as pool:
            futures = {
                pool.submit(_run_remaining, cc): cc[0]["id"]
                for cc in cases_to_run
            }
            done_count = 0
            for future in as_completed(futures):
                case_id = futures[future]
                done_count += 1
                try:
                    case_results = future.result()
                    all_results.extend(case_results)
                    log.info("Case %s complete (%d/%d)", case_id, done_count, total_cases)
                except Exception as exc:
                    log.error("Case %s FAILED: %s", case_id, exc, exc_info=True)

    log.info("")
    log.info("=" * 70)
    log.info("  ALL CASES COMPLETE")
    log.info("=" * 70)

    summary      = build_summary(all_results)
    summary_path = RESULTS / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    report_path = write_report(summary, all_results, cases)

    log.info("")
    log.info("FINAL ACCURACY TABLE (%s)", _AGENT_LABEL)
    log.info("%-6s  %-12s  %-7s  %-7s  %-7s  %-7s  %-7s  %s",
             "Cond", "pass-rate", "acc@1", "acc@2", "acc@3", "acc@4", "acc@5", "tokens")
    log.info("-" * 72)
    for cond in _CONDITIONS:
        m    = summary["per_condition"].get(cond, {})
        rate = m.get("final_pass_rate", "?")
        toks = m.get("total_tokens", 0)
        accs = [f"{m.get(f'accuracy@{k}', 0):5.1f}%" for k in range(1, _MAX_ATTEMPTS + 1)]
        if cond not in ("A", "B"):
            accs = [accs[0]] + ["     —"] * 4
        log.info("%-6s  %-12s  %s  %d", cond, rate, "  ".join(accs), toks)

    log.info("")
    log.info("Summary JSON -> %s", summary_path)
    log.info("Report MD    -> %s", report_path)
    log.info("Full log     -> %s", LOG_FILE)


if __name__ == "__main__":
    main()
