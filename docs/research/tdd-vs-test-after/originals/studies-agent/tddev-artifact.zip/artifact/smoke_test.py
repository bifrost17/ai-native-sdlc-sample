#!/usr/bin/env python3
"""
Smoke test: end-to-end experiment pipeline with Claude Code (haiku backbone).

Runs both:
  Condition A — whole-project: implement all features at once, then
                iterate deploy → test → fix until all pass or max_attempts
  Condition B — incremental: implement one feature at a time, regression-
                guarded; each feature gets its own attempt budget

Dev agent: Claude Code CLI (`claude -p --model claude-haiku-4-5-20251001`)
  running in an isolated temp directory (not a git repo → stop hook exits 0)

Test agent: testing_agent.run_test_case() with haiku grounding + Playwright

Case: 000001 — "Build a todo list app where users can add and delete tasks."

Usage
-----
    cd tdd-web-agent
    python smoke_test.py

Requirements
------------
  ANTHROPIC_API_KEY or ANTHROPIC_AUTH_TOKEN  — or a session token at
      /home/claude/.claude/remote/.session_ingress_token (auto-detected)
  playwright  —  playwright install chromium
  npm / node  —  for the generated Express app
"""

import argparse
import asyncio
import http.server
import json
import logging
import os
import re
import socket
import subprocess
import sys
import tempfile
import threading
import urllib.request
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# Auth: auto-detect session token before any Anthropic SDK import
# ---------------------------------------------------------------------------

_SESSION_TOKEN_PATH = Path("/home/claude/.claude/remote/.session_ingress_token")

if not os.environ.get("ANTHROPIC_API_KEY") and not os.environ.get("ANTHROPIC_AUTH_TOKEN"):
    if _SESSION_TOKEN_PATH.exists():
        os.environ["ANTHROPIC_AUTH_TOKEN"] = _SESSION_TOKEN_PATH.read_text().strip()
    else:
        sys.exit(
            "ERROR: Set ANTHROPIC_API_KEY or ANTHROPIC_AUTH_TOKEN, "
            "or ensure the session token file exists."
        )

# ---------------------------------------------------------------------------
# Logging: timestamped file + console
# ---------------------------------------------------------------------------

LOGS_DIR = Path(__file__).parent / "logs"
LOGS_DIR.mkdir(exist_ok=True)

_TS = datetime.now().strftime("%Y%m%d_%H%M%S")
LOG_FILE      = LOGS_DIR / f"smoke_{_TS}.log"
RESULT_FILE_A = LOGS_DIR / f"smoke_{_TS}_A_results.jsonl"
RESULT_FILE_B = LOGS_DIR / f"smoke_{_TS}_B_results.jsonl"

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)-8s %(name)-28s %(message)s",
    handlers=[
        logging.FileHandler(str(LOG_FILE)),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("smoke_test")

# ---------------------------------------------------------------------------
# Project imports
# ---------------------------------------------------------------------------

from experiment.loader import load_jsonl
from experiment.runner import run_case
from experiment.metrics import load_log, summarize
from mcp_server.tools.deployment import start_app as _start_app, stop_app as _stop_app
from mcp_server.testing_agent.agent import run_test_case

# ---------------------------------------------------------------------------
# Shared event loop for async calls from sync context
# ---------------------------------------------------------------------------

_LOOP = asyncio.new_event_loop()
asyncio.set_event_loop(_LOOP)


def _run(coro):
    return _LOOP.run_until_complete(coro)


# ---------------------------------------------------------------------------
# Prompts for Claude Code
# ---------------------------------------------------------------------------

_IMPLEMENT_ALL = """\
You are building a web application. Create a complete, working Express.js app
that satisfies ALL of the following test cases.

Instruction: {instruction}

Test cases to satisfy:
{test_cases_json}

Requirements:
- Create package.json with express as a dependency and "start": "node server.js"
- Create server.js that listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / that has all the UI elements the tests need
- Run `npm install` after creating the files
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)
"""

_IMPLEMENT_FEATURE = """\
You are building a web application incrementally. Add the following feature to
the app in this directory. If no app exists yet, create the full Express.js
scaffold plus this feature.

Overall instruction: {instruction}

Feature to implement now:
{tc_json}

Requirements:
- package.json must have express as dependency and "start": "node server.js"
- server.js listens on process.env.PORT || 3000, bound to 127.0.0.1
- Serve a full HTML page at GET / containing UI elements for this feature
- Run `npm install` if you create or update package.json
- Use only express and Node.js built-ins (no extra npm packages)
- Keep all state in memory (no database)
- Do not break any previously passing features
"""

_FIX = """\
The automated browser tests failed. Fix the app in this directory so the
tests pass.

Failure report:
{report}

Instructions:
- Read the existing server.js (and any other files) to understand the current state
- Make the minimal changes needed to fix the failures
- Do not remove any existing passing functionality
- Run `npm install` if you change package.json
"""

# ---------------------------------------------------------------------------
# ClaudeCodeDevAgent
# ---------------------------------------------------------------------------

_CLAUDE_MODEL   = "claude-haiku-4-5-20251001"
_OPENCODE_BIN   = str(Path.home() / ".opencode" / "bin" / "opencode")

_TOGETHER_KEY     = os.environ.get("TOGETHER_API_KEY", "")
_TOGETHER_BASE    = "https://api.together.xyz"   # no /v1; opencode appends /v1/models
_QWEN_MODEL       = "Qwen/Qwen3.5-397B-A17B"
_ANTHROPIC_KEY    = os.environ.get("ANTHROPIC_API_KEY", "")
# Haiku 4.5 is used for the Anthropic backend.  opencode v0.0.55 doesn't know this
# model (released after the binary), so we serve it through a local OpenAI-compat
# proxy (_AnthropicCompatProxy below) and point opencode at it via LOCAL_ENDPOINT.
_OC_HAIKU_MODEL   = "claude-haiku-4-5-20251001"

# .opencode.json for Together.ai + Qwen (intended for unconstrained environments)
# opencode-ai/opencode v0.0.55 format: LOCAL_ENDPOINT env var + local provider config.
# opencode fetches {LOCAL_ENDPOINT}/v1/models at startup (no auth) to register local
# models with a "local." prefix.  API calls then use providers.local.apiKey.
_OPENCODE_CONFIG_TOGETHER = {
    "providers": {
        "local": {"apiKey": _TOGETHER_KEY},
    },
    "agents": {
        "coder":      {"model": f"local.{_QWEN_MODEL}", "maxTokens": 8000},
        "task":       {"model": f"local.{_QWEN_MODEL}", "maxTokens": 4000},
        "title":      {"model": f"local.{_QWEN_MODEL}", "maxTokens": 80},
        "summarizer": {"model": f"local.{_QWEN_MODEL}", "maxTokens": 4000},
    },
}

def _opencode_config_anthropic(port: int) -> dict:
    """
    .opencode.json for the Anthropic-backed local proxy.

    The proxy (_AnthropicCompatProxy) runs at localhost:<port> and exposes an
    OpenAI-compatible API backed by claude-haiku-4-5-20251001 on Anthropic.
    opencode talks to it via LOCAL_ENDPOINT=http://localhost:<port>.
    """
    model_id = f"local.{_OC_HAIKU_MODEL}"
    return {
        "providers": {
            "local": {"apiKey": _ANTHROPIC_KEY},
        },
        "agents": {
            "coder":      {"model": model_id, "maxTokens": 8096},
            "task":       {"model": model_id, "maxTokens": 8096},
            "title":      {"model": model_id, "maxTokens": 80},
            "summarizer": {"model": model_id, "maxTokens": 8096},
        },
    }


# ---------------------------------------------------------------------------
# Anthropic-compat proxy: OpenAI /v1/* → Anthropic messages API
# ---------------------------------------------------------------------------

class _AnthropicCompatProxy(http.server.BaseHTTPRequestHandler):
    """
    Minimal OpenAI-compatible HTTP server that proxies to Anthropic.

    Handles:
      GET  /v1/models           → returns a one-entry model list (no auth)
      POST /v1/chat/completions → converts request/response between formats
    """
    anthropic_key: str = ""
    model: str = _OC_HAIKU_MODEL

    def log_message(self, fmt, *args):  # silence default access log
        pass

    def do_GET(self):
        if self.path.rstrip("/") == "/v1/models":
            body = json.dumps({
                "object": "list",
                "data": [{"id": self.model, "object": "model", "created": 0, "owned_by": "anthropic"}],
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        oai_req = json.loads(self.rfile.read(length))
        wants_stream = oai_req.get("stream", False)
        ant_req = self._to_anthropic(oai_req)
        try:
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=json.dumps(ant_req).encode(),
                headers={
                    "x-api-key": self.anthropic_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
            )
            with urllib.request.urlopen(req, timeout=300) as r:
                ant_resp = json.loads(r.read())
            oai_resp = self._from_anthropic(ant_resp)

            if wants_stream:
                # Simulate SSE streaming from the non-streamed Anthropic response
                self._send_sse(oai_resp)
            else:
                body = json.dumps(oai_resp).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(body)
        except Exception as exc:
            log.error("proxy error: %s", exc)
            self.send_response(502)
            self.end_headers()
            self.wfile.write(json.dumps({"error": str(exc)}).encode())

    def _send_sse(self, oai_resp: dict) -> None:
        """Send a non-streamed OAI response back as SSE chunks."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

        msg     = oai_resp["choices"][0]["message"]
        resp_id = oai_resp.get("id", "x")
        model   = oai_resp.get("model", "")

        def _chunk(delta: dict, finish: str | None = None) -> None:
            data = json.dumps({
                "id": resp_id, "object": "chat.completion.chunk", "model": model,
                "choices": [{"index": 0, "delta": delta,
                             "finish_reason": finish}],
            })
            self.wfile.write(f"data: {data}\n\n".encode())
            self.wfile.flush()

        # 1. role delta
        _chunk({"role": "assistant"})

        # 2. content delta (if any text)
        content = msg.get("content")
        if content:
            _chunk({"content": content})

        # 3. tool_calls deltas
        for i, tc in enumerate(msg.get("tool_calls") or []):
            # first chunk establishes the tool call (id + name + empty args)
            _chunk({"tool_calls": [{"index": i, "id": tc["id"], "type": "function",
                                    "function": {"name": tc["function"]["name"],
                                                 "arguments": ""}}]})
            # second chunk delivers the arguments
            _chunk({"tool_calls": [{"index": i,
                                    "function": {"arguments": tc["function"]["arguments"]}}]})

        # 4. finish chunk
        finish = oai_resp["choices"][0].get("finish_reason", "stop")
        _chunk({}, finish)

        # 5. DONE sentinel
        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()

    @staticmethod
    def _to_anthropic(body: dict) -> dict:
        messages, system = [], None
        for msg in body.get("messages", []):
            role = msg["role"]
            if role == "system":
                system = msg["content"]
            elif role == "tool":
                # tool result → Anthropic tool_result block inside a user turn
                messages.append({
                    "role": "user",
                    "content": [{"type": "tool_result",
                                 "tool_use_id": msg["tool_call_id"],
                                 "content": str(msg.get("content", ""))}],
                })
            elif role == "assistant":
                content = []
                if isinstance(msg.get("content"), str) and msg["content"]:
                    content.append({"type": "text", "text": msg["content"]})
                for tc in msg.get("tool_calls", []):
                    content.append({
                        "type": "tool_use",
                        "id": tc["id"],
                        "name": tc["function"]["name"],
                        "input": json.loads(tc["function"]["arguments"]),
                    })
                if content:
                    messages.append({"role": "assistant", "content": content})
            else:
                messages.append({"role": "user", "content": msg.get("content", "")})

        # Anthropic requires strictly alternating roles; merge consecutive same-role turns
        merged = []
        for msg in messages:
            if merged and merged[-1]["role"] == msg["role"]:
                prev = merged[-1]
                prev_c = prev["content"] if isinstance(prev["content"], list) else [{"type": "text", "text": prev["content"]}]
                cur_c  = msg["content"]  if isinstance(msg["content"],  list) else [{"type": "text", "text": msg["content"]}]
                prev["content"] = prev_c + cur_c
            else:
                merged.append({"role": msg["role"], "content": msg["content"]})

        ant: dict = {
            "model":      _AnthropicCompatProxy.model,
            "messages":   merged,
            "max_tokens": body.get("max_tokens", 8096),
        }
        if system:
            ant["system"] = system
        if body.get("tools"):
            ant["tools"] = [
                {
                    "name":         t["function"]["name"],
                    "description":  t["function"].get("description", ""),
                    "input_schema": t["function"].get("parameters",
                                                      {"type": "object", "properties": {}}),
                }
                for t in body["tools"]
            ]
        return ant

    @staticmethod
    def _from_anthropic(ant: dict) -> dict:
        content = ant.get("content", [])
        text_parts, tool_calls = [], []
        for block in content:
            if block["type"] == "text":
                text_parts.append(block["text"])
            elif block["type"] == "tool_use":
                tool_calls.append({
                    "id": block["id"],
                    "type": "function",
                    "function": {
                        "name":      block["name"],
                        "arguments": json.dumps(block["input"]),
                    },
                })
        stop = ant.get("stop_reason", "end_turn")
        finish = "tool_calls" if stop == "tool_use" else "stop"
        message: dict = {"role": "assistant", "content": "\n".join(text_parts) or None}
        if tool_calls:
            message["tool_calls"] = tool_calls
        return {
            "id":      ant.get("id", ""),
            "object":  "chat.completion",
            "model":   ant.get("model", ""),
            "choices": [{"index": 0, "message": message, "finish_reason": finish}],
            "usage": {
                "prompt_tokens":     ant.get("usage", {}).get("input_tokens", 0),
                "completion_tokens": ant.get("usage", {}).get("output_tokens", 0),
                "total_tokens":      ant.get("usage", {}).get("input_tokens", 0)
                                     + ant.get("usage", {}).get("output_tokens", 0),
            },
        }


def _start_compat_proxy(anthropic_key: str) -> tuple[http.server.HTTPServer, int]:
    """Start the Anthropic-compat proxy on a free port and return (server, port)."""

    class _Handler(_AnthropicCompatProxy):
        pass
    _Handler.anthropic_key = anthropic_key
    _Handler.model = _OC_HAIKU_MODEL

    # bind to port 0 → OS assigns a free port
    server = http.server.HTTPServer(("127.0.0.1", 0), _Handler)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    log.info("AnthropicCompatProxy started on http://127.0.0.1:%d (model=%s)", port, _OC_HAIKU_MODEL)
    return server, port


class ClaudeCodeDevAgent:
    """
    Dev agent that delegates to the Claude Code CLI.

    implement(test_cases_or_tc) is called with:
      - a list[dict]  for condition A (build whole app)
      - a single dict for condition B (add one feature)

    fix(report) is called with a plain-text failure report.

    Both methods run `claude -p` in self.project_dir (a temp dir, not a git
    repo) so the stop-hook exits 0 without interfering.
    """

    def __init__(self, project_dir: str, instruction: str) -> None:
        self.project_dir = project_dir
        self.instruction = instruction

    def implement(self, test_cases) -> None:
        if isinstance(test_cases, dict):
            # Condition B: single feature
            label = f"feature {test_cases.get('test_id', '?')}"
            prompt = _IMPLEMENT_FEATURE.format(
                instruction=self.instruction,
                tc_json=json.dumps(test_cases, indent=2),
            )
        else:
            # Condition A: all features at once
            label = f"{len(test_cases)} test case(s)"
            prompt = _IMPLEMENT_ALL.format(
                instruction=self.instruction,
                test_cases_json=json.dumps(test_cases, indent=2),
            )
        log.info("ClaudeCodeDevAgent.implement(%s)", label)
        self._run_claude(prompt, phase="implement")

    def fix(self, report: str) -> None:
        log.info("ClaudeCodeDevAgent.fix()")
        log.debug("Failure report:\n%s", report)
        prompt = _FIX.format(report=report)
        self._run_claude(prompt, phase="fix")

    def _run_claude(self, prompt: str, phase: str) -> None:
        cmd = [
            "claude", "-p",
            "--model", _CLAUDE_MODEL,
            "--permission-mode", "acceptEdits",
            "--allowed-tools", "Edit,Write,Read,Glob,Grep,Bash",
            "--no-session-persistence",
            prompt,
        ]
        log.debug("claude cmd (phase=%s): %s", phase, " ".join(cmd[:6] + ["<prompt>"]))
        log.debug("Prompt:\n%s", prompt)

        result = subprocess.run(
            cmd,
            cwd=self.project_dir,
            capture_output=True,
            text=True,
            timeout=300,
            env={**os.environ},
        )

        log.info(
            "claude exit=%d  phase=%s  stdout=%d chars  stderr=%d chars",
            result.returncode, phase, len(result.stdout), len(result.stderr),
        )
        if result.stdout:
            log.debug("claude stdout:\n%s", result.stdout)
        if result.stderr:
            log.debug("claude stderr:\n%s", result.stderr)
        if result.returncode != 0:
            log.warning("claude exited non-zero (%d) during %s", result.returncode, phase)


# ---------------------------------------------------------------------------
# OpenCodeDevAgent — drop-in replacement using opencode CLI + Together.ai
# ---------------------------------------------------------------------------

class OpenCodeDevAgent:
    """
    Dev agent that delegates to the opencode CLI (opencode.ai).

    Identical interface to ClaudeCodeDevAgent: implement(test_cases_or_tc)
    and fix(report).  Uses opencode -p in non-interactive mode.

    provider="together" (default): routes to Together.ai's OpenAI-compatible
        endpoint (https://api.together.xyz) using Qwen3.5-397B-A17B.
        Requires LOCAL_ENDPOINT to be accessible from the network.

    provider="anthropic": routes to api.anthropic.com (sandbox fallback when
        Together.ai is unreachable due to egress restrictions).

    A project-local .opencode.json is written into project_dir before the
    first call so opencode picks up the provider config without touching any
    global user settings.
    """

    def __init__(self, project_dir: str, instruction: str, provider: str = "together") -> None:
        self.project_dir = project_dir
        self.instruction = instruction
        self.provider    = provider
        self._config_written = False

    def _ensure_config(self) -> None:
        if self._config_written:
            return
        if self.provider == "anthropic":
            # Start a local OpenAI-compat proxy backed by Anthropic so opencode can use
            # claude-haiku-4-5-20251001 (not in opencode's built-in model registry).
            self._proxy_server, port = _start_compat_proxy(_ANTHROPIC_KEY)
            config    = _opencode_config_anthropic(port)
            extra_env = {"LOCAL_ENDPOINT": f"http://127.0.0.1:{port}"}
        else:
            self._proxy_server = None
            config    = _OPENCODE_CONFIG_TOGETHER
            extra_env = {"LOCAL_ENDPOINT": _TOGETHER_BASE}
        self._extra_env = extra_env
        config_path = Path(self.project_dir) / ".opencode.json"
        config_path.write_text(json.dumps(config, indent=2))
        log.debug(
            "Wrote opencode config (provider=%s) to %s", self.provider, config_path
        )
        self._config_written = True

    def implement(self, test_cases) -> None:
        if isinstance(test_cases, dict):
            label = f"feature {test_cases.get('test_id', '?')}"
            prompt = _IMPLEMENT_FEATURE.format(
                instruction=self.instruction,
                tc_json=json.dumps(test_cases, indent=2),
            )
        else:
            label = f"{len(test_cases)} test case(s)"
            prompt = _IMPLEMENT_ALL.format(
                instruction=self.instruction,
                test_cases_json=json.dumps(test_cases, indent=2),
            )
        log.info("OpenCodeDevAgent.implement(%s) [provider=%s]", label, self.provider)
        self._run_opencode(prompt, phase="implement")

    def fix(self, report: str) -> None:
        log.info("OpenCodeDevAgent.fix() [provider=%s]", self.provider)
        log.debug("Failure report:\n%s", report)
        prompt = _FIX.format(report=report)
        self._run_opencode(prompt, phase="fix")

    def _run_opencode(self, prompt: str, phase: str) -> None:
        self._ensure_config()
        cmd = [
            _OPENCODE_BIN,
            "-p", prompt,
            "-q",                       # hide spinner
            "--cwd", self.project_dir,
        ]
        log.debug("opencode cmd (phase=%s, provider=%s): %s",
                  phase, self.provider, " ".join(cmd[:4] + ["<prompt>"]))
        log.debug("Prompt:\n%s", prompt)

        env = {
            **os.environ,
            "PATH": str(Path(_OPENCODE_BIN).parent) + ":" + os.environ.get("PATH", ""),
            **getattr(self, "_extra_env", {}),
        }
        result = subprocess.run(
            cmd,
            cwd=self.project_dir,
            capture_output=True,
            text=True,
            timeout=600,
            env=env,
        )

        log.info(
            "opencode exit=%d  phase=%s  provider=%s  stdout=%d chars  stderr=%d chars",
            result.returncode, phase, self.provider,
            len(result.stdout), len(result.stderr),
        )
        if result.stdout:
            log.debug("opencode stdout:\n%s", result.stdout)
        if result.stderr:
            log.debug("opencode stderr:\n%s", result.stderr)
        if result.returncode != 0:
            log.warning("opencode exited non-zero (%d) during %s [provider=%s]",
                        result.returncode, phase, self.provider)


# ---------------------------------------------------------------------------
# Adapters shared by both conditions
# ---------------------------------------------------------------------------

def make_adapters(project_dir: str):
    """
    Returns (start_app_fn, run_tests_fn).

    start_app_fn  — stops any running instance first, then starts fresh;
                    stores the URL in url_box[0] for run_tests_fn to use.
    run_tests_fn  — runs test cases against url_box[0] via Playwright + haiku.
    """
    # url_box[0] = URL string on success, None if startup failed
    # url_box[1] = error message when url_box[0] is None
    url_box: list = [None, ""]

    def start_app_fn() -> None:
        log.info("stop_app(%s) then start_app …", project_dir)
        _stop_app(project_dir)
        try:
            info = _start_app(project_dir)
            url_box[0] = info["url"]
            url_box[1] = ""
            log.info(
                "App running → url=%s  port=%s  framework=%s",
                info["url"], info["port"], info["framework"],
            )
        except Exception as exc:
            url_box[0] = None
            url_box[1] = str(exc)
            log.error("start_app FAILED: %s", exc)

    def run_tests_fn(test_cases: list) -> dict:
        if isinstance(test_cases, dict):
            test_cases = [test_cases]

        # If the server failed to start, return all tests as fail so the
        # failure report is fed back to the next fix() call.
        if url_box[0] is None:
            log.warning("Server not running — marking all %d TC(s) as fail", len(test_cases))
            return {"results": [
                {
                    "test_id":        tc["test_id"],
                    "result":         "fail",
                    "failure_report": f"Server failed to start: {url_box[1]}",
                    "trajectory":     [],
                }
                for tc in test_cases
            ]}

        app_url = url_box[0]
        log.info("run_tests(%s) | %d test case(s)", app_url, len(test_cases))

        results = []
        for tc in test_cases:
            log.info("  TC %s — %s", tc["test_id"], tc["feature"])
            outcome = _run(run_test_case(tc, app_url))
            log.info("  TC %s → result=%s", tc["test_id"], outcome["result"])
            log.debug(
                "  TC %s trajectory:\n%s",
                tc["test_id"],
                json.dumps(outcome["trajectory"], indent=4),
            )
            if outcome["failure_report"]:
                log.warning(
                    "  TC %s failure_report: %s",
                    tc["test_id"], outcome["failure_report"],
                )
            results.append({
                "test_id":        tc["test_id"],
                "result":         outcome["result"],
                "failure_report": outcome["failure_report"],
                "trajectory":     outcome["trajectory"],
            })

        return {"results": results}

    return start_app_fn, run_tests_fn


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _banner(msg: str) -> None:
    bar = "=" * 60
    log.info("\n%s\n  %s\n%s", bar, msg, bar)


def _run_condition(label, condition, case, result_file, tmpdir, agent_cls):
    """Run one condition and return the summary dict."""
    _banner(f"Condition {label}  —  {condition}  (dir: {tmpdir})")

    agent = agent_cls(tmpdir, case["instruction"])
    start_fn, run_tests_fn = make_adapters(tmpdir)

    try:
        summary = run_case(
            case         = case,
            condition    = condition,
            dev_agent    = agent,
            start_app    = start_fn,
            run_tests    = run_tests_fn,
            log_path     = str(result_file),
            max_attempts = 5,
        )
    finally:
        log.info("Stopping app in %s …", tmpdir)
        _stop_app(tmpdir)

    log.info("Condition %s summary:\n%s", label, json.dumps(summary, indent=2))

    entries = load_log(str(result_file))
    log.info("JSONL entries: %d", len(entries))
    for e in entries:
        log.info("  %s", json.dumps(e))

    metrics = summarize(entries, max_k=5)
    log.info("Condition %s metrics:\n%s", label, json.dumps(metrics, indent=2))

    return summary, metrics


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="TDD smoke test")
    parser.add_argument(
        "--agent",
        choices=["claude", "opencode"],
        default="claude",
        help=(
            "Dev agent to use: 'claude' (Claude Code CLI, default) or "
            "'opencode' (opencode CLI)"
        ),
    )
    parser.add_argument(
        "--opencode-provider",
        choices=["together", "anthropic"],
        default="together",
        help=(
            "Backend for opencode agent (ignored when --agent=claude). "
            "'together' (default): Together.ai + Qwen3.5-397B-A17B via OpenAI-compatible API. "
            "'anthropic': Anthropic Claude via api.anthropic.com (use when Together.ai is unreachable)."
        ),
    )
    args = parser.parse_args()

    if args.agent == "opencode":
        _provider = args.opencode_provider
        if _provider == "together":
            model_label = f"{_QWEN_MODEL} via Together.ai"
        else:
            model_label = f"{_OC_HAIKU_MODEL} via Anthropic (local compat proxy)"
        agent_cls   = lambda d, i: OpenCodeDevAgent(d, i, provider=_provider)
        agent_label = f"opencode ({model_label})"
    else:
        agent_cls   = ClaudeCodeDevAgent
        agent_label = f"Claude Code ({_CLAUDE_MODEL})"

    _banner("SMOKE TEST START")
    log.info("Dev agent: %s", agent_label)
    log.info("Log:      %s", LOG_FILE)
    log.info("Results A: %s", RESULT_FILE_A)
    log.info("Results B: %s", RESULT_FILE_B)

    # Load case 000001 from fixture data
    bench     = load_jsonl("tests/fixtures/sample_bench.jsonl")
    converted = {
        e["id"]: e.get("test_cases", [])
        for e in load_jsonl("tests/fixtures/sample_converted.jsonl")
    }
    case = dict(bench[0])
    case["test_cases"] = converted.get(case["id"], [])

    _banner(f"Case {case['id']} — {case['instruction']}")
    log.info("Test cases:\n%s", json.dumps(case["test_cases"], indent=2))

    results = {}

    # ── Condition A: whole-project ────────────────────────────────────────
    with tempfile.TemporaryDirectory(prefix="smoke_A_") as tmpdir_a:
        summary_a, metrics_a = _run_condition(
            "A", "A", case, RESULT_FILE_A, tmpdir_a, agent_cls,
        )
        results["A"] = {"summary": summary_a, "metrics": metrics_a}

    # ── Condition B: incremental ──────────────────────────────────────────
    with tempfile.TemporaryDirectory(prefix="smoke_B_") as tmpdir_b:
        summary_b, metrics_b = _run_condition(
            "B", "B", case, RESULT_FILE_B, tmpdir_b, agent_cls,
        )
        results["B"] = {"summary": summary_b, "metrics": metrics_b}

    # ── Final comparison ──────────────────────────────────────────────────
    _banner("SMOKE TEST COMPLETE")
    log.info("Agent: %s", agent_label)
    log.info("%-12s  %-10s  %-10s  %s",
             "Condition", "final_pass", "acc@1", "acc@5")
    log.info("-" * 50)
    for cond, data in results.items():
        fp  = data["summary"]["final_pass"]
        a1  = data["metrics"].get("accuracy@1", 0.0)
        a5  = data["metrics"].get("accuracy@5", 0.0)
        log.info("%-12s  %-10s  %-10.0f%%  %.0f%%", cond, fp, a1, a5)

    log.info("Full log  → %s", LOG_FILE)
    log.info("Results A → %s", RESULT_FILE_A)
    log.info("Results B → %s", RESULT_FILE_B)


if __name__ == "__main__":
    main()
