const express = require('express');
const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.get('/', (req, res) => res.send('OK'));

app.listen(port, '127.0.0.1', () => {
  console.log(`Express fixture listening on port ${port}`);
});
