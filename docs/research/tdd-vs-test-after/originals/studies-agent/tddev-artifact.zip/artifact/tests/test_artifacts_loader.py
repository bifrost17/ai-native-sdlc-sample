"""
Tests for experiment/artifacts_loader.py

All network calls are mocked — no real HuggingFace API access needed.

Covers:
  1. fetch_artifacts_samples returns n items
  2. Returned items have all required keys
  3. Sampling is reproducible with the same seed
  4. Different seeds return different subsets
  5. Cache is used on second call (no second HTTP request)
  6. Invalid (empty) rows are filtered out
  7. RuntimeError raised when not enough valid samples
  8. Checklist JSON-string is parsed into a list
"""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

import experiment.artifacts_loader as al

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_raw_rows(n: int = 10) -> list[dict]:
    """Build fake normalised rows (already processed by _normalise)."""
    return [
        {
            "index":      i,
            "question":   f"Build a {i} counter widget",
            "checklist":  [f"Counter displays {i}", f"Button increments by 1"],
            "class":      ["Game Development", "Web Applications"][i % 2],
            "difficulty": ["Easy", "Medium", "Hard"][i % 3],
        }
        for i in range(n)
    ]


def _make_hf_api_response(rows: list[dict]) -> bytes:
    """Wrap normalised rows in the HuggingFace API response envelope."""
    payload = {"rows": [{"row": r} for r in rows]}
    return json.dumps(payload).encode()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestFetchArtifactsSamples:
    """All tests patch the cache + network so nothing hits the filesystem or internet."""

    @pytest.fixture(autouse=True)
    def isolate_cache(self, tmp_path, monkeypatch):
        """Redirect cache path to a temp dir so tests don't touch data/."""
        fake_cache = tmp_path / "artifacts_cache.json"
        monkeypatch.setattr(al, "_CACHE_PATH", fake_cache)

    def _mock_http(self, rows: list[dict]):
        """Return a context-manager mock for urllib.request.urlopen."""
        resp_mock = MagicMock()
        resp_mock.__enter__ = MagicMock(return_value=resp_mock)
        resp_mock.__exit__ = MagicMock(return_value=False)
        resp_mock.read.return_value = _make_hf_api_response(rows)
        return resp_mock

    @patch("experiment.artifacts_loader.urllib.request.urlopen")
    def test_returns_n_items(self, mock_urlopen):
        mock_urlopen.return_value = self._mock_http(_make_raw_rows(10))
        result = al.fetch_artifacts_samples(n=3, seed=0)
        assert len(result) == 3

    @patch("experiment.artifacts_loader.urllib.request.urlopen")
    def test_items_have_required_keys(self, mock_urlopen):
        mock_urlopen.return_value = self._mock_http(_make_raw_rows(10))
        result = al.fetch_artifacts_samples(n=1, seed=0)
        required = {"index", "question", "checklist", "class", "difficulty"}
        assert required.issubset(result[0].keys())

    @patch("experiment.artifacts_loader.urllib.request.urlopen")
    def test_checklist_is_list(self, mock_urlopen):
        mock_urlopen.return_value = self._mock_http(_make_raw_rows(10))
        result = al.fetch_artifacts_samples(n=3, seed=0)
        for r in result:
            assert isinstance(r["checklist"], list)
            assert len(r["checklist"]) > 0

    @patch("experiment.artifacts_loader.urllib.request.urlopen")
    def test_same_seed_gives_same_result(self, mock_urlopen):
        mock_urlopen.return_value = self._mock_http(_make_raw_rows(10))
        r1 = al.fetch_artifacts_samples(n=3, seed=7)
        # Cache is already populated; second call should use it
        r2 = al.fetch_artifacts_samples(n=3, seed=7)
        assert [r["index"] for r in r1] == [r["index"] for r in r2]

    @patch("experiment.artifacts_loader.urllib.request.urlopen")
    def test_different_seeds_give_different_results(self, mock_urlopen):
        mock_urlopen.return_value = self._mock_http(_make_raw_rows(10))
        r1 = al.fetch_artifacts_samples(n=3, seed=1)
        r2 = al.fetch_artifacts_samples(n=3, seed=99)
        # With 10 items and n=3 it's very unlikely both seeds pick same 3
        assert [r["index"] for r in r1] != [r["index"] for r in r2]

    @patch("experiment.artifacts_loader.urllib.request.urlopen")
    def test_cache_prevents_second_http_call(self, mock_urlopen, tmp_path, monkeypatch):
        fake_cache = tmp_path / "c2.json"
        monkeypatch.setattr(al, "_CACHE_PATH", fake_cache)
        mock_urlopen.return_value = self._mock_http(_make_raw_rows(10))

        al.fetch_artifacts_samples(n=2, seed=0)   # populates cache
        al.fetch_artifacts_samples(n=2, seed=0)   # should read cache
        # urlopen should have been called exactly once
        assert mock_urlopen.call_count == 1

    @patch("experiment.artifacts_loader.urllib.request.urlopen")
    def test_empty_rows_are_filtered(self, mock_urlopen):
        rows = _make_raw_rows(5)
        # Inject two bad rows
        rows.append({"index": 99, "question": "", "checklist": [], "class": "X", "difficulty": "Easy"})
        rows.append({"index": 100, "question": "Valid", "checklist": [], "class": "Y", "difficulty": "Easy"})
        mock_urlopen.return_value = self._mock_http(rows)
        result = al.fetch_artifacts_samples(n=3, seed=0)
        for r in result:
            assert r["question"]
            assert r["checklist"]

    @patch("experiment.artifacts_loader.urllib.request.urlopen")
    def test_raises_when_not_enough_samples(self, mock_urlopen):
        mock_urlopen.return_value = self._mock_http(_make_raw_rows(2))
        with pytest.raises(RuntimeError, match="valid"):
            al.fetch_artifacts_samples(n=5, seed=0)

    @patch("experiment.artifacts_loader.urllib.request.urlopen")
    def test_checklist_json_string_is_parsed(self, mock_urlopen):
        """If checklist arrives as a JSON string it should be parsed into a list."""
        rows = _make_raw_rows(3)
        rows[0]["checklist"] = json.dumps(["item A", "item B"])  # JSON string form
        mock_urlopen.return_value = self._mock_http(rows)
        result = al.fetch_artifacts_samples(n=1, seed=0)
        # At least one result should have a list checklist
        assert all(isinstance(r["checklist"], list) for r in result)
