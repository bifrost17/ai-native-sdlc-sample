"""
Phase 1 tests for mcp_server/tools/deployment.py

Test plan (from RESEARCH_PLAN.md):
1. detect_framework returns correct framework + dev_command for each fixture
2. start_app returns reachable URL (HTTP 200)
3. Returned port matches what is actually listening
4. stop_app closes the port
5. Calling start_app twice on the same dir returns the existing process (no conflict)
"""

import socket
import time
import urllib.request
from pathlib import Path

import pytest

# Add project root to path so imports work without installation
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp_server.tools.deployment import detect_framework, start_app, stop_app, _process_registry

FIXTURES = Path(__file__).parent / "fixtures"
EXPRESS_DIR = str(FIXTURES / "express_app")
VITE_REACT_DIR = str(FIXTURES / "vite_react_app")
NEXTJS_DIR = str(FIXTURES / "nextjs_app")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def is_port_open(port: int, host: str = "127.0.0.1") -> bool:
    try:
        with socket.create_connection((host, port), timeout=1):
            return True
    except OSError:
        return False


def http_get_status(url: str) -> int:
    try:
        with urllib.request.urlopen(url, timeout=5) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception:
        return -1


# ---------------------------------------------------------------------------
# detect_framework — pure function, no subprocess
# ---------------------------------------------------------------------------

class TestDetectFramework:
    def test_express(self):
        info = detect_framework(EXPRESS_DIR)
        assert info["framework"] == "express"
        assert "node" in info["dev_command"] or "npm" in info["dev_command"]
        assert info["default_port"] == 3000

    def test_vite_react(self):
        info = detect_framework(VITE_REACT_DIR)
        assert info["framework"] == "react"
        assert info["dev_command"] == "npm run dev"
        assert info["default_port"] == 5173

    def test_nextjs(self):
        info = detect_framework(NEXTJS_DIR)
        assert info["framework"] == "nextjs"
        assert info["dev_command"] == "npm run dev"
        assert info["default_port"] == 3000

    def test_missing_package_json(self, tmp_path):
        info = detect_framework(str(tmp_path))
        assert info["framework"] == "unknown"

    def test_empty_package_json(self, tmp_path):
        (tmp_path / "package.json").write_text("{}")
        info = detect_framework(str(tmp_path))
        assert info["framework"] == "unknown"


# ---------------------------------------------------------------------------
# start_app / stop_app — requires node + express installed in fixture
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def cleanup_registry():
    """Ensure no leftover processes leak between tests."""
    yield
    for key in list(_process_registry.keys()):
        try:
            stop_app(key)
        except Exception:
            pass


@pytest.mark.integration
class TestStartStopApp:
    """
    These tests actually spawn the Express fixture server.
    Requires: npm install has been run inside tests/fixtures/express_app/
    """

    def test_start_returns_correct_keys(self):
        info = start_app(EXPRESS_DIR)
        try:
            assert "url" in info
            assert "port" in info
            assert "framework" in info
            assert info["framework"] == "express"
        finally:
            stop_app(EXPRESS_DIR)

    def test_url_is_reachable(self):
        info = start_app(EXPRESS_DIR)
        try:
            status = http_get_status(info["url"])
            assert status == 200, f"Expected HTTP 200, got {status}"
        finally:
            stop_app(EXPRESS_DIR)

    def test_port_matches_listening_port(self):
        info = start_app(EXPRESS_DIR)
        try:
            assert is_port_open(info["port"]), f"Port {info['port']} is not open"
        finally:
            stop_app(EXPRESS_DIR)

    def test_stop_closes_port(self):
        info = start_app(EXPRESS_DIR)
        port = info["port"]
        assert is_port_open(port), "Port should be open after start_app"
        stop_app(EXPRESS_DIR)
        # Give the OS a moment to release the port
        time.sleep(0.5)
        assert not is_port_open(port), "Port should be closed after stop_app"

    def test_start_twice_returns_same_process(self):
        info1 = start_app(EXPRESS_DIR)
        try:
            info2 = start_app(EXPRESS_DIR)
            assert info1["port"] == info2["port"]
            assert info1["url"] == info2["url"]
            # Only one process should be in the registry
            from pathlib import Path
            key = str(Path(EXPRESS_DIR).resolve())
            assert key in _process_registry
        finally:
            stop_app(EXPRESS_DIR)

    def test_stop_nonexistent_is_noop(self):
        # Should not raise
        stop_app("/tmp/nonexistent_project_xyz")
