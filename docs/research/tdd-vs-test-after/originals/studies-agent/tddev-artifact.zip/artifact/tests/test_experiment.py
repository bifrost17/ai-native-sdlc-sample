"""
Phase 5 — Experiment infrastructure tests.

All tests are fully mocked — no LLM calls, no browser, no subprocess.

Test plan (from RESEARCH_PLAN.md Phase 5):

  loader.py
    1. Same seed → same case IDs on two calls
    2. Different seed → different sample order/selection
    3. Every returned item has 'instruction' and 'test_cases' keys
    4. Exactly n items returned

  metrics.py
    5. Known log (3 pass@1, 1 pass@3, 1 never) → correct accuracy@k values
    6. Monotonicity: accuracy@k+1 >= accuracy@k for all k
    7. All fail → accuracy@k = 0 for all k
    8. All pass at attempt 1 → accuracy@1 = 100
    9. Partial counts as 0.5

  runner.py
    10. Condition A: produces JSONL log with one entry per (tc_id, attempt)
    11. Condition B: produces JSONL log; entries have all required fields
    12. Condition D: dev_agent.fix never called (no fix loop)
    13. Condition D: run_tests called exactly once (one evaluation pass)
    14. Unknown condition raises ValueError
    15. JSONL log entries have all required fields
"""

import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, call

import pytest

# ---------------------------------------------------------------------------
# Path setup
# ---------------------------------------------------------------------------

sys.path.insert(0, str(Path(__file__).parent.parent))

FIXTURES = Path(__file__).parent / "fixtures"
BENCH_PATH = str(FIXTURES / "sample_bench.jsonl")
CONVERTED_PATH = str(FIXTURES / "sample_converted.jsonl")

from experiment.loader import sample_cases, load_jsonl
from experiment.metrics import compute_accuracy_at_k, summarize, load_log
from experiment.runner import run_case


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _tc(tid: str) -> dict:
    return {"test_id": tid, "feature": f"Feature {tid}", "steps": [], "expected": "ok"}


def _make_results(test_cases, passing_ids: set) -> dict:
    return {
        "results": [
            {
                "test_id": tc["test_id"],
                "result": "pass" if tc["test_id"] in passing_ids else "fail",
                "failure_report": "" if tc["test_id"] in passing_ids else "Something failed",
            }
            for tc in test_cases
        ]
    }


def _make_case(case_id: str, n_tcs: int = 2) -> dict:
    return {
        "id":           case_id,
        "instruction":  f"Build app {case_id}",
        "test_cases":   [_tc(f"TC-0{i}") for i in range(1, n_tcs + 1)],
    }


def _build_log(entries_spec: list) -> list:
    """
    Build a list of log entry dicts from a compact spec.

    entries_spec is a list of (tc_id, attempt, result) tuples.
    """
    return [
        {
            "case_id":        "000001",
            "condition":      "A",
            "tc_id":          tc_id,
            "attempt":        attempt,
            "result":         result,
            "failure_report": "" if result == "pass" else "err",
        }
        for tc_id, attempt, result in entries_spec
    ]


# ---------------------------------------------------------------------------
# TestLoader
# ---------------------------------------------------------------------------

class TestLoader:

    def test_same_seed_returns_same_ids(self):
        """Calling sample_cases twice with the same seed returns the same IDs."""
        sample_a = sample_cases(BENCH_PATH, CONVERTED_PATH, n=5, seed=42)
        sample_b = sample_cases(BENCH_PATH, CONVERTED_PATH, n=5, seed=42)
        assert [c["id"] for c in sample_a] == [c["id"] for c in sample_b]

    def test_different_seed_returns_different_sample(self):
        """Two different seeds produce a different ordering or selection."""
        sample_a = sample_cases(BENCH_PATH, CONVERTED_PATH, n=5, seed=42)
        sample_b = sample_cases(BENCH_PATH, CONVERTED_PATH, n=5, seed=99)
        # At least the order must differ (fixture has 7 items, sample 5 → very
        # likely different order; seeds 42 vs 99 are verified to differ)
        assert [c["id"] for c in sample_a] != [c["id"] for c in sample_b]

    def test_returns_exactly_n_items(self):
        """sample_cases returns exactly n items."""
        sample = sample_cases(BENCH_PATH, CONVERTED_PATH, n=3, seed=42)
        assert len(sample) == 3

    def test_n_capped_at_available_items(self):
        """Requesting more items than available returns all available items."""
        all_items = load_jsonl(BENCH_PATH)
        sample = sample_cases(BENCH_PATH, CONVERTED_PATH, n=1000, seed=42)
        assert len(sample) == len(all_items)

    def test_each_item_has_instruction(self):
        """Every returned item has a non-empty 'instruction' key."""
        sample = sample_cases(BENCH_PATH, CONVERTED_PATH, n=5, seed=42)
        for case in sample:
            assert "instruction" in case
            assert case["instruction"]

    def test_each_item_has_test_cases(self):
        """Every returned item has a 'test_cases' key (list, possibly empty)."""
        sample = sample_cases(BENCH_PATH, CONVERTED_PATH, n=5, seed=42)
        for case in sample:
            assert "test_cases" in case
            assert isinstance(case["test_cases"], list)

    def test_test_cases_joined_correctly(self):
        """
        For a known ID, the joined test_cases match the converted file entry.
        """
        # Load all converted data to find an ID to check
        converted = load_jsonl(CONVERTED_PATH)
        first_converted = converted[0]
        expected_tc = first_converted["test_cases"]

        # Load all bench items to confirm the ID is in the bench file
        all_bench = load_jsonl(BENCH_PATH)
        bench_ids = {item["id"] for item in all_bench}
        assert first_converted["id"] in bench_ids, "fixture mismatch"

        # Sample all items (seed doesn't matter if we take everything)
        sample = sample_cases(BENCH_PATH, CONVERTED_PATH, n=100, seed=1)
        matched = [c for c in sample if c["id"] == first_converted["id"]]
        assert matched, f"ID {first_converted['id']} not found in sample"
        assert matched[0]["test_cases"] == expected_tc

    def test_missing_converted_id_gets_empty_list(self):
        """Items not in the converted file receive an empty test_cases list."""
        # Write a bench file with an extra ID not in converted
        with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
            f.write('{"id": "999999", "instruction": "Orphan item"}\n')
            extra_bench = f.name

        with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
            extra_conv = f.name  # empty converted file

        try:
            sample = sample_cases(extra_bench, extra_conv, n=1, seed=42)
            assert sample[0]["test_cases"] == []
        finally:
            os.unlink(extra_bench)
            os.unlink(extra_conv)


# ---------------------------------------------------------------------------
# TestMetrics
# ---------------------------------------------------------------------------

class TestMetrics:
    """
    Fixture: 5 test cases
        TC-01: pass at attempt 1
        TC-02: pass at attempt 1
        TC-03: pass at attempt 1
        TC-04: pass at attempt 3 (fail at 1, fail at 2, pass at 3)
        TC-05: never passes (fail at attempts 1..5)

    Expected:
        accuracy@1 = (3×1) / 5 × 100 = 60.0
        accuracy@2 = 60.0   (TC-04 still failing)
        accuracy@3 = (4×1) / 5 × 100 = 80.0
        accuracy@4 = 80.0
        accuracy@5 = 80.0
    """

    def _known_log(self) -> list:
        entries = []
        # TC-01,02,03: pass at attempt 1
        for tc in ("TC-01", "TC-02", "TC-03"):
            entries.append(("TC-01", 1, "pass"))  # BUG: using tc variable
        entries = []
        for tc in ("TC-01", "TC-02", "TC-03"):
            entries.append((tc, 1, "pass"))
        # TC-04: fail,fail,pass
        entries += [
            ("TC-04", 1, "fail"),
            ("TC-04", 2, "fail"),
            ("TC-04", 3, "pass"),
        ]
        # TC-05: fail through all 5 attempts
        for a in range(1, 6):
            entries.append(("TC-05", a, "fail"))
        return _build_log(entries)

    def test_accuracy_at_1(self):
        assert compute_accuracy_at_k(self._known_log(), 1) == pytest.approx(60.0)

    def test_accuracy_at_2(self):
        assert compute_accuracy_at_k(self._known_log(), 2) == pytest.approx(60.0)

    def test_accuracy_at_3(self):
        assert compute_accuracy_at_k(self._known_log(), 3) == pytest.approx(80.0)

    def test_accuracy_at_4(self):
        assert compute_accuracy_at_k(self._known_log(), 4) == pytest.approx(80.0)

    def test_accuracy_at_5(self):
        assert compute_accuracy_at_k(self._known_log(), 5) == pytest.approx(80.0)

    def test_monotonicity(self):
        """accuracy@k+1 >= accuracy@k for all k."""
        log = self._known_log()
        values = [compute_accuracy_at_k(log, k) for k in range(1, 6)]
        for i in range(len(values) - 1):
            assert values[i + 1] >= values[i], (
                f"Non-monotonic: accuracy@{i+1}={values[i]} > "
                f"accuracy@{i+2}={values[i+1]}"
            )

    def test_all_fail_gives_zero(self):
        """All failing test cases → accuracy@k = 0 for all k."""
        log = _build_log([
            ("TC-01", 1, "fail"),
            ("TC-01", 2, "fail"),
            ("TC-02", 1, "fail"),
        ])
        for k in range(1, 6):
            assert compute_accuracy_at_k(log, k) == pytest.approx(0.0)

    def test_all_pass_at_1_gives_100(self):
        """All passing at attempt 1 → accuracy@1 = 100."""
        log = _build_log([
            ("TC-01", 1, "pass"),
            ("TC-02", 1, "pass"),
            ("TC-03", 1, "pass"),
        ])
        assert compute_accuracy_at_k(log, 1) == pytest.approx(100.0)

    def test_partial_counts_as_half(self):
        """One partial, one fail, two total → accuracy@1 = 25.0."""
        log = _build_log([
            ("TC-01", 1, "partial"),
            ("TC-02", 1, "fail"),
        ])
        assert compute_accuracy_at_k(log, 1) == pytest.approx(25.0)

    def test_empty_log_returns_zero(self):
        assert compute_accuracy_at_k([], 1) == pytest.approx(0.0)

    def test_summarize_returns_all_k(self):
        """summarize() returns accuracy@1 through accuracy@5."""
        result = summarize(self._known_log())
        assert set(result.keys()) == {f"accuracy@{k}" for k in range(1, 6)}

    def test_load_log_roundtrip(self, tmp_path):
        """load_log reads back what append_log_entry wrote."""
        from experiment.metrics import append_log_entry
        log_path = str(tmp_path / "test.jsonl")
        entry = {
            "case_id": "000001", "condition": "A",
            "tc_id": "TC-01", "attempt": 1,
            "result": "pass", "failure_report": "",
        }
        append_log_entry(log_path, entry)
        loaded = load_log(log_path)
        assert loaded == [entry]


# ---------------------------------------------------------------------------
# TestRunner
# ---------------------------------------------------------------------------

class TestRunner:

    def _make_agent(self):
        return MagicMock()

    def _always_pass_run_tests(self, test_cases):
        return _make_results(test_cases, {tc["test_id"] for tc in test_cases})

    def _always_fail_run_tests(self, test_cases):
        return _make_results(test_cases, set())

    def test_condition_a_produces_jsonl_log(self, tmp_path):
        """Condition A: JSONL log file is created with at least one entry."""
        case = _make_case("000001", n_tcs=1)
        log_path = str(tmp_path / "log.jsonl")

        run_case(
            case         = case,
            condition    = "A",
            dev_agent    = self._make_agent(),
            start_app    = MagicMock(),
            run_tests    = self._always_pass_run_tests,
            log_path     = log_path,
            max_attempts = 3,
        )

        assert os.path.exists(log_path)
        entries = load_log(log_path)
        assert len(entries) >= 1

    def test_condition_b_produces_jsonl_log(self, tmp_path):
        """Condition B: JSONL log file is created with valid entries."""
        case = _make_case("000001", n_tcs=2)
        log_path = str(tmp_path / "log.jsonl")

        run_case(
            case         = case,
            condition    = "B",
            dev_agent    = self._make_agent(),
            start_app    = MagicMock(),
            run_tests    = self._always_pass_run_tests,
            log_path     = log_path,
            max_attempts = 3,
        )

        assert os.path.exists(log_path)
        entries = load_log(log_path)
        assert len(entries) >= 1

    def test_log_entries_have_required_fields(self, tmp_path):
        """Every log entry has case_id, condition, tc_id, attempt, result, failure_report."""
        case = _make_case("000002", n_tcs=2)
        log_path = str(tmp_path / "log.jsonl")

        run_case(
            case         = case,
            condition    = "A",
            dev_agent    = self._make_agent(),
            start_app    = MagicMock(),
            run_tests    = self._always_pass_run_tests,
            log_path     = log_path,
        )

        for entry in load_log(log_path):
            assert "case_id"        in entry
            assert "condition"      in entry
            assert "tc_id"          in entry
            assert "attempt"        in entry
            assert "result"         in entry
            assert "failure_report" in entry

    def test_condition_d_fix_never_called(self, tmp_path):
        """Condition D: dev_agent.fix is never called (no loop)."""
        case = _make_case("000001", n_tcs=1)
        agent = self._make_agent()
        log_path = str(tmp_path / "log.jsonl")

        run_case(
            case      = case,
            condition = "D",
            dev_agent = agent,
            start_app = MagicMock(),
            run_tests = self._always_fail_run_tests,
            log_path  = log_path,
        )

        agent.fix.assert_not_called()

    def test_condition_d_run_tests_called_once(self, tmp_path):
        """Condition D: run_tests is called exactly once (one evaluation pass)."""
        case = _make_case("000001", n_tcs=1)
        run_tests_mock = MagicMock(side_effect=self._always_pass_run_tests)
        log_path = str(tmp_path / "log.jsonl")

        run_case(
            case      = case,
            condition = "D",
            dev_agent = self._make_agent(),
            start_app = MagicMock(),
            run_tests = run_tests_mock,
            log_path  = log_path,
        )

        assert run_tests_mock.call_count == 1

    def test_condition_a_final_pass_true_when_all_pass(self, tmp_path):
        """Condition A: summary.final_pass is True when run_tests returns all pass."""
        case = _make_case("000001", n_tcs=2)
        log_path = str(tmp_path / "log.jsonl")

        summary = run_case(
            case      = case,
            condition = "A",
            dev_agent = self._make_agent(),
            start_app = MagicMock(),
            run_tests = self._always_pass_run_tests,
            log_path  = log_path,
        )

        assert summary["final_pass"] is True

    def test_condition_a_final_pass_false_when_all_fail(self, tmp_path):
        """Condition A: summary.final_pass is False when tests always fail."""
        case = _make_case("000001", n_tcs=1)
        log_path = str(tmp_path / "log.jsonl")

        summary = run_case(
            case         = case,
            condition    = "A",
            dev_agent    = self._make_agent(),
            start_app    = MagicMock(),
            run_tests    = self._always_fail_run_tests,
            log_path     = log_path,
            max_attempts = 2,
        )

        assert summary["final_pass"] is False

    def test_unknown_condition_raises(self, tmp_path):
        """An unrecognised condition string raises ValueError."""
        case = _make_case("000001")
        with pytest.raises(ValueError, match="Unknown condition"):
            run_case(
                case      = case,
                condition = "Z",
                dev_agent = self._make_agent(),
                start_app = MagicMock(),
                run_tests = self._always_pass_run_tests,
                log_path  = str(tmp_path / "log.jsonl"),
            )

    def test_log_case_id_and_condition_match_inputs(self, tmp_path):
        """Log entries have case_id and condition matching the inputs."""
        case = _make_case("000042", n_tcs=1)
        log_path = str(tmp_path / "log.jsonl")

        run_case(
            case      = case,
            condition = "B",
            dev_agent = self._make_agent(),
            start_app = MagicMock(),
            run_tests = self._always_pass_run_tests,
            log_path  = log_path,
        )

        for entry in load_log(log_path):
            assert entry["case_id"] == "000042"
            assert entry["condition"] == "B"

    def test_condition_c_is_single_shot(self, tmp_path):
        """
        Condition C (agentic TDD) is single-shot: implement once, deploy once,
        test once. dev_agent.fix is never called; run_tests is called exactly once.
        """
        case = _make_case("000001", n_tcs=1)
        log_path = str(tmp_path / "log.jsonl")
        agent = self._make_agent()
        run_tests_mock = MagicMock(side_effect=self._always_pass_run_tests)

        summary = run_case(
            case      = case,
            condition = "C",
            dev_agent = agent,
            start_app = MagicMock(),
            run_tests = run_tests_mock,
            log_path  = log_path,
        )

        assert summary["final_pass"] is True
        assert os.path.exists(log_path)
        assert len(load_log(log_path)) >= 1
        agent.fix.assert_not_called()
        assert run_tests_mock.call_count == 1

    def test_existing_log_is_overwritten(self, tmp_path):
        """run_case overwrites an existing log file rather than appending."""
        case = _make_case("000001", n_tcs=1)
        log_path = str(tmp_path / "log.jsonl")

        # Run once
        run_case(
            case      = case,
            condition = "A",
            dev_agent = self._make_agent(),
            start_app = MagicMock(),
            run_tests = self._always_pass_run_tests,
            log_path  = log_path,
            max_attempts = 1,
        )
        first_count = len(load_log(log_path))

        # Run again — should overwrite, not append
        run_case(
            case      = case,
            condition = "A",
            dev_agent = self._make_agent(),
            start_app = MagicMock(),
            run_tests = self._always_pass_run_tests,
            log_path  = log_path,
            max_attempts = 1,
        )
        second_count = len(load_log(log_path))

        assert second_count == first_count  # not doubled
