"""
Phase 6 — MCP Server tests.

Starts the server as a subprocess, connects via the MCP Python client,
and verifies the full transport layer end-to-end.

Test plan (from RESEARCH_PLAN.md Phase 6):
  1. list_tools returns all expected tool names
  2. start_app via MCP returns {url, port, framework} for a real fixture app
  3. stop_app via MCP closes the port
  4. detect_framework via MCP returns correct framework for express fixture
  5. Malformed call (missing required arg) returns structured error, not crash

All tests in TestMCPServer use a real subprocess + real MCP client.
No LLM calls are made (generate_test_cases and run_tests are not called here).
"""

import asyncio
import json
import socket
import sys
import os
from pathlib import Path

import pytest

from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp import ClientSession

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

ROOT = Path(__file__).parent.parent          # tdd-web-agent/
FIXTURES = Path(__file__).parent / "fixtures"
EXPRESS_APP = str(FIXTURES / "express_app")

_EXPECTED_TOOLS = {
    "generate_test_cases",
    "start_app",
    "stop_app",
    "detect_framework",
    "run_tests",
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _server_params() -> StdioServerParameters:
    return StdioServerParameters(
        command=sys.executable,
        args=["-m", "mcp_server.server"],
        cwd=str(ROOT),
        env={**os.environ},
    )


def _port_open(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", port)) == 0


async def _call(session: ClientSession, tool: str, args: dict):
    """Call a tool and return the parsed JSON result."""
    response = await session.call_tool(tool, args)
    raw = response.content[0].text
    return json.loads(raw)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestMCPServer:
    """
    End-to-end MCP protocol tests.

    Each test opens a fresh server subprocess and client session.
    The express_app fixture requires `npm install` (done in Phase 1 setup).
    """

    @pytest.mark.asyncio
    async def test_list_tools_returns_all_names(self):
        """list_tools must return all five expected tool names."""
        async with stdio_client(_server_params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                names = {t.name for t in result.tools}
                assert _EXPECTED_TOOLS == names, (
                    f"Missing: {_EXPECTED_TOOLS - names}, "
                    f"extra: {names - _EXPECTED_TOOLS}"
                )

    @pytest.mark.asyncio
    async def test_list_tools_each_has_description(self):
        """Every registered tool has a non-empty description."""
        async with stdio_client(_server_params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                for tool in result.tools:
                    assert tool.description, f"Tool {tool.name!r} has no description"

    @pytest.mark.asyncio
    async def test_list_tools_each_has_input_schema(self):
        """Every registered tool exposes an inputSchema."""
        async with stdio_client(_server_params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                for tool in result.tools:
                    assert tool.inputSchema, f"Tool {tool.name!r} has no inputSchema"

    @pytest.mark.asyncio
    async def test_detect_framework_express(self):
        """
        detect_framework on the express_app fixture returns
        {"framework": "express", ...} via the MCP protocol.
        """
        async with stdio_client(_server_params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await _call(session, "detect_framework",
                                     {"project_dir": EXPRESS_APP})
                assert "framework" in result
                assert result["framework"] == "express"
                assert "dev_command" in result
                assert "default_port" in result

    @pytest.mark.asyncio
    async def test_start_app_returns_url_port_framework(self):
        """
        start_app on the express_app fixture returns {url, port, framework}
        and the port is actually reachable.
        """
        async with stdio_client(_server_params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await _call(session, "start_app",
                                     {"project_dir": EXPRESS_APP})
                try:
                    assert "url" in result, f"Response missing 'url': {result}"
                    assert "port" in result, f"Response missing 'port': {result}"
                    assert "framework" in result, f"Response missing 'framework': {result}"
                    assert _port_open(result["port"]), (
                        f"Port {result['port']} not reachable after start_app"
                    )
                finally:
                    # Always clean up the server process
                    await _call(session, "stop_app",
                                {"project_dir": EXPRESS_APP})

    @pytest.mark.asyncio
    async def test_stop_app_closes_port(self):
        """
        After stop_app, the port returned by start_app is no longer reachable.
        """
        async with stdio_client(_server_params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                start_result = await _call(session, "start_app",
                                           {"project_dir": EXPRESS_APP})
                port = start_result["port"]
                assert _port_open(port), "Port should be open after start_app"

                stop_result = await _call(session, "stop_app",
                                          {"project_dir": EXPRESS_APP})
                assert stop_result.get("stopped") is True

                # Give the process a moment to release the port
                await asyncio.sleep(0.5)
                assert not _port_open(port), (
                    f"Port {port} still open after stop_app"
                )

    @pytest.mark.asyncio
    async def test_missing_required_arg_returns_error_not_crash(self):
        """
        Calling start_app without project_dir returns a structured
        {"error": ...} JSON response rather than crashing the server.
        """
        async with stdio_client(_server_params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await _call(session, "start_app", {})
                assert "error" in result, (
                    f"Expected error key in response, got: {result}"
                )
                assert "project_dir" in result["error"].lower() or \
                       "missing" in result["error"].lower() or \
                       "required" in result["error"].lower(), (
                    f"Error message doesn't mention missing arg: {result['error']}"
                )

    @pytest.mark.asyncio
    async def test_unknown_tool_returns_error_not_crash(self):
        """
        Calling a non-existent tool name returns a structured error response.
        The MCP SDK may raise an error at the protocol level; we verify the
        server remains alive (subsequent list_tools call succeeds).
        """
        async with stdio_client(_server_params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                # The SDK may raise McpError for unknown tools; catch it
                try:
                    result = await _call(session, "nonexistent_tool", {})
                    # If it returns, it should be an error response
                    assert "error" in result
                except Exception:
                    pass  # Protocol-level error is also acceptable

                # Server must still be alive
                list_result = await session.list_tools()
                assert len(list_result.tools) == len(_EXPECTED_TOOLS)

    @pytest.mark.asyncio
    async def test_server_handles_multiple_sequential_calls(self):
        """
        The server correctly handles multiple tool calls in one session.
        """
        async with stdio_client(_server_params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                # First call
                r1 = await _call(session, "detect_framework",
                                 {"project_dir": EXPRESS_APP})
                assert r1["framework"] == "express"

                # Second call
                r2 = await _call(session, "detect_framework",
                                 {"project_dir": EXPRESS_APP})
                assert r2["framework"] == "express"

                # Third: missing-arg error — server stays alive
                r3 = await _call(session, "stop_app", {})
                assert "error" in r3

                # Fourth call still works
                r4 = await _call(session, "detect_framework",
                                 {"project_dir": EXPRESS_APP})
                assert r4["framework"] == "express"
