"""
Phase 4 — Protocol tests.

All tests use mock stubs for dev_agent, start_app, run_tests, and log_result.
No real Claude Code CLI, no browser, no LLM calls are made.

Test plan (from RESEARCH_PLAN.md Phase 4):
  Whole-project:
    1. Happy path: run_tests returns all-pass on attempt 1
       → protocol exits after one deploy+test cycle; log records attempt 1 as passing
    2. Retry: run_tests fails on attempts 1-2, passes on attempt 3
       → dev_agent.fix called exactly twice; log records 3 entries
    3. Ceiling: run_tests always fails
       → protocol stops after exactly MAX_ATTEMPTS; fix not called a (MAX_ATTEMPTS+1)-th time

  Incremental:
    4. Regression guard: tc2 always causes tc1 (previously passing) to fail
       → tc2 marked failed; passed_suite contains only tc1
    5. Ceiling: a feature that never passes
       → marked failed; loop continues to next feature
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from unittest.mock import MagicMock, call

import pytest

from protocols.whole_project import run_whole_project, MAX_ATTEMPTS as WP_MAX
from protocols.incremental import run_incremental, MAX_ATTEMPTS as INC_MAX


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _tc(tid: str) -> dict:
    return {"test_id": tid, "feature": f"Feature {tid}", "steps": [], "expected": "ok"}


def _pass_result(tc: dict) -> dict:
    return {"test_id": tc["test_id"], "result": "pass", "failure_report": ""}


def _fail_result(tc: dict) -> dict:
    return {"test_id": tc["test_id"], "result": "fail", "failure_report": "Something went wrong"}


def _make_results(test_cases: list, passing_ids: set) -> dict:
    return {
        "results": [
            _pass_result(tc) if tc["test_id"] in passing_ids else _fail_result(tc)
            for tc in test_cases
        ]
    }


# ---------------------------------------------------------------------------
# Whole-project tests
# ---------------------------------------------------------------------------

class TestWholeProject:

    def _make_agent(self):
        agent = MagicMock()
        return agent

    def test_happy_path_exits_after_one_attempt(self):
        """
        run_tests returns all-pass on attempt 1.
        Protocol should exit after one deploy+test cycle.
        """
        tcs = [_tc("TC-01"), _tc("TC-02")]
        agent = self._make_agent()
        start_app = MagicMock()
        run_tests = MagicMock(return_value=_make_results(tcs, {"TC-01", "TC-02"}))
        log_result = MagicMock()

        result = run_whole_project(tcs, agent, start_app, run_tests, log_result)

        assert len(result["log"]) == 1
        assert result["log"][0]["attempt"] == 1
        assert result["log"][0]["all_pass"] is True
        assert result["final_pass"] is True
        # start_app and run_tests each called exactly once
        assert start_app.call_count == 1
        assert run_tests.call_count == 1
        # fix never called because first attempt passed
        agent.fix.assert_not_called()

    def test_retry_calls_fix_exactly_twice(self):
        """
        run_tests fails on attempts 1 and 2, passes on attempt 3.
        dev_agent.fix should be called exactly twice.
        Log should record 3 entries.
        """
        tcs = [_tc("TC-01")]
        agent = self._make_agent()
        start_app = MagicMock()
        outcomes = [
            _make_results(tcs, set()),          # attempt 1: fail
            _make_results(tcs, set()),          # attempt 2: fail
            _make_results(tcs, {"TC-01"}),      # attempt 3: pass
        ]
        run_tests = MagicMock(side_effect=outcomes)
        log_result = MagicMock()

        result = run_whole_project(tcs, agent, start_app, run_tests, log_result)

        assert len(result["log"]) == 3
        assert result["log"][0]["all_pass"] is False
        assert result["log"][1]["all_pass"] is False
        assert result["log"][2]["all_pass"] is True
        assert result["final_pass"] is True
        assert agent.fix.call_count == 2

    def test_ceiling_stops_at_max_attempts(self):
        """
        run_tests always fails.
        Protocol must stop after exactly MAX_ATTEMPTS iterations.
        """
        tcs = [_tc("TC-01")]
        agent = self._make_agent()
        start_app = MagicMock()
        run_tests = MagicMock(return_value=_make_results(tcs, set()))
        log_result = MagicMock()

        result = run_whole_project(tcs, agent, start_app, run_tests, log_result)

        assert len(result["log"]) == WP_MAX
        assert start_app.call_count == WP_MAX
        assert run_tests.call_count == WP_MAX
        assert result["final_pass"] is False

    def test_ceiling_does_not_exceed_max_fix_calls(self):
        """
        run_tests always fails.
        dev_agent.fix is called once per failing attempt (MAX_ATTEMPTS times),
        never more.
        """
        tcs = [_tc("TC-01")]
        agent = self._make_agent()
        start_app = MagicMock()
        run_tests = MagicMock(return_value=_make_results(tcs, set()))
        log_result = MagicMock()

        run_whole_project(tcs, agent, start_app, run_tests, log_result)

        assert agent.fix.call_count == WP_MAX

    def test_implement_called_once_before_loop(self):
        """dev_agent.implement is called exactly once with all test cases."""
        tcs = [_tc("TC-01"), _tc("TC-02")]
        agent = self._make_agent()
        run_tests = MagicMock(return_value=_make_results(tcs, {"TC-01", "TC-02"}))

        run_whole_project(tcs, agent, MagicMock(), run_tests, MagicMock())

        agent.implement.assert_called_once_with(tcs)

    def test_log_result_called_each_attempt(self):
        """log_result is called once per attempt with (attempt_number, results)."""
        tcs = [_tc("TC-01")]
        agent = self._make_agent()
        outcomes = [
            _make_results(tcs, set()),
            _make_results(tcs, {"TC-01"}),
        ]
        run_tests = MagicMock(side_effect=outcomes)
        log_result = MagicMock()

        run_whole_project(tcs, agent, MagicMock(), run_tests, log_result)

        assert log_result.call_count == 2
        assert log_result.call_args_list[0][0][0] == 1   # first arg is attempt number
        assert log_result.call_args_list[1][0][0] == 2


# ---------------------------------------------------------------------------
# Incremental tests
# ---------------------------------------------------------------------------

class TestIncremental:

    def _make_agent(self):
        return MagicMock()

    def test_happy_path_all_features_pass(self):
        """
        Each feature passes on its first attempt.
        passed_suite should contain all test cases; failed should be empty.
        """
        tcs = [_tc("TC-01"), _tc("TC-02"), _tc("TC-03")]
        agent = self._make_agent()

        def run_tests(test_cases):
            return _make_results(test_cases, {tc["test_id"] for tc in test_cases})

        result = run_incremental(tcs, agent, MagicMock(), run_tests, MagicMock())

        assert [tc["test_id"] for tc in result["passed_suite"]] == ["TC-01", "TC-02", "TC-03"]
        assert result["failed"] == []

    def test_regression_guard(self):
        """
        tc1 passes and joins passed_suite.
        tc2 always causes tc1 to regress (run_tests([tc1, tc2]) has tc1 failing).
        Expected: tc2 is marked failed; passed_suite contains only tc1.
        """
        tc1 = _tc("TC-01")
        tc2 = _tc("TC-02")

        agent = self._make_agent()

        def run_tests(test_cases):
            ids = {tc["test_id"] for tc in test_cases}
            if ids == {"TC-01"}:
                # tc1 alone: passes
                return _make_results(test_cases, {"TC-01"})
            else:
                # once tc2 enters, tc1 regresses and tc2 also fails
                return _make_results(test_cases, set())

        result = run_incremental([tc1, tc2], agent, MagicMock(), run_tests, MagicMock())

        assert [tc["test_id"] for tc in result["passed_suite"]] == ["TC-01"]
        assert result["failed"] == ["TC-02"]

    def test_ceiling_marks_feature_failed(self):
        """
        A feature that never passes within MAX_ATTEMPTS should be in failed,
        not in passed_suite.
        """
        tc = _tc("TC-01")
        agent = self._make_agent()
        run_tests = MagicMock(return_value=_make_results([tc], set()))

        result = run_incremental([tc], agent, MagicMock(), run_tests, MagicMock())

        assert result["failed"] == ["TC-01"]
        assert result["passed_suite"] == []

    def test_ceiling_does_not_block_next_feature(self):
        """
        A feature that hits the ceiling is abandoned; the loop moves on
        to subsequent features.
        """
        tc1 = _tc("TC-01")  # never passes
        tc2 = _tc("TC-02")  # always passes

        agent = self._make_agent()

        def run_tests(test_cases):
            ids = {tc["test_id"] for tc in test_cases}
            if "TC-01" in ids:
                return _make_results(test_cases, set())   # TC-01 always fails
            return _make_results(test_cases, ids)         # TC-02 passes

        result = run_incremental([tc1, tc2], agent, MagicMock(), run_tests, MagicMock())

        assert result["failed"] == ["TC-01"]
        assert [tc["test_id"] for tc in result["passed_suite"]] == ["TC-02"]

    def test_implement_called_per_feature(self):
        """dev_agent.implement is called once for each test case, in order."""
        tcs = [_tc("TC-01"), _tc("TC-02")]
        agent = self._make_agent()

        def run_tests(test_cases):
            return _make_results(test_cases, {tc["test_id"] for tc in test_cases})

        run_incremental(tcs, agent, MagicMock(), run_tests, MagicMock())

        assert agent.implement.call_count == 2
        assert agent.implement.call_args_list[0] == call(tcs[0])
        assert agent.implement.call_args_list[1] == call(tcs[1])

    def test_regression_included_in_run_suite(self):
        """
        After tc1 is confirmed passing, tc2's test run must include tc1
        (regression suite). Verify by inspecting the args passed to run_tests.
        """
        tc1 = _tc("TC-01")
        tc2 = _tc("TC-02")
        agent = self._make_agent()

        called_with: list = []

        def run_tests(test_cases):
            called_with.append([tc["test_id"] for tc in test_cases])
            return _make_results(test_cases, {tc["test_id"] for tc in test_cases})

        run_incremental([tc1, tc2], agent, MagicMock(), run_tests, MagicMock())

        # First call: only tc1
        assert called_with[0] == ["TC-01"]
        # Second call: tc1 (regression) + tc2
        assert called_with[1] == ["TC-01", "TC-02"]
