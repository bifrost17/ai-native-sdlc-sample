"""
Tests for mcp_server/testing_agent/screenshot_judge.py

All LLM and browser calls are mocked — no real API key or Playwright needed.

Covers:
  1. _parse_judge_output extracts JSON array correctly
  2. _parse_judge_output strips markdown fences
  3. _parse_judge_output raises ValueError on garbage input
  4. screenshot_and_judge returns correct score (pass count / total)
  5. screenshot_and_judge normalises unexpected verdict strings
  6. screenshot_and_judge returns score=0 for empty checklist
  7. Verdicts are all normalised to "pass" or "fail"
"""

import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp_server.testing_agent.screenshot_judge import (
    _parse_judge_output,
    screenshot_and_judge,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_judge_response(items: list[dict]) -> MagicMock:
    """Build a fake Anthropic API response containing a JSON array."""
    msg = MagicMock()
    msg.content = [MagicMock(text=json.dumps(items))]
    return msg


def _make_obs(screenshot_b64: str = "FAKEB64") -> dict:
    return {"accessibility_tree": "- heading: test", "screenshot": screenshot_b64}


# ---------------------------------------------------------------------------
# _parse_judge_output
# ---------------------------------------------------------------------------

class TestParseJudgeOutput:
    def test_bare_json_array(self):
        raw = json.dumps([{"item": "a", "verdict": "pass", "reason": "ok"}])
        result = _parse_judge_output(raw)
        assert len(result) == 1
        assert result[0]["verdict"] == "pass"

    def test_strips_markdown_fences(self):
        inner = json.dumps([{"item": "b", "verdict": "fail", "reason": "missing"}])
        raw = f"```json\n{inner}\n```"
        result = _parse_judge_output(raw)
        assert result[0]["verdict"] == "fail"

    def test_json_embedded_in_prose(self):
        inner = json.dumps([{"item": "c", "verdict": "pass", "reason": "yes"}])
        raw = f"Here is my evaluation:\n{inner}\nThat's it."
        result = _parse_judge_output(raw)
        assert result[0]["item"] == "c"

    def test_raises_on_garbage(self):
        with pytest.raises(ValueError, match="No JSON array"):
            _parse_judge_output("This is not JSON at all.")

    def test_multiple_items(self):
        items = [
            {"item": f"item {i}", "verdict": "pass", "reason": "ok"}
            for i in range(5)
        ]
        result = _parse_judge_output(json.dumps(items))
        assert len(result) == 5


# ---------------------------------------------------------------------------
# screenshot_and_judge
# ---------------------------------------------------------------------------

class TestScreenshotAndJudge:
    """All external calls are mocked."""

    def _run(self, coro):
        return asyncio.get_event_loop().run_until_complete(coro)

    @patch("mcp_server.testing_agent.screenshot_judge.anthropic.Anthropic")
    @patch("mcp_server.testing_agent.screenshot_judge.BrowserSession")
    def test_all_pass_gives_100(self, mock_browser_cls, mock_anthropic_cls):
        items = [
            {"item": "Canvas is visible",   "verdict": "pass", "reason": "seen"},
            {"item": "Snake moves on keys", "verdict": "pass", "reason": "seen"},
        ]
        mock_browser_cls.return_value.__aenter__ = AsyncMock(
            return_value=MagicMock(observe=AsyncMock(return_value=_make_obs()))
        )
        mock_browser_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        mock_anthropic_cls.return_value.messages.create.return_value = (
            _make_judge_response(items)
        )

        result = self._run(
            screenshot_and_judge(["Canvas is visible", "Snake moves on keys"], "http://x")
        )
        assert result["score"] == 100.0
        assert all(r["verdict"] == "pass" for r in result["results"])

    @patch("mcp_server.testing_agent.screenshot_judge.anthropic.Anthropic")
    @patch("mcp_server.testing_agent.screenshot_judge.BrowserSession")
    def test_all_fail_gives_0(self, mock_browser_cls, mock_anthropic_cls):
        items = [
            {"item": "Score counter shows", "verdict": "fail", "reason": "absent"},
        ]
        mock_browser_cls.return_value.__aenter__ = AsyncMock(
            return_value=MagicMock(observe=AsyncMock(return_value=_make_obs()))
        )
        mock_browser_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        mock_anthropic_cls.return_value.messages.create.return_value = (
            _make_judge_response(items)
        )

        result = self._run(
            screenshot_and_judge(["Score counter shows"], "http://x")
        )
        assert result["score"] == 0.0

    @patch("mcp_server.testing_agent.screenshot_judge.anthropic.Anthropic")
    @patch("mcp_server.testing_agent.screenshot_judge.BrowserSession")
    def test_mixed_gives_correct_score(self, mock_browser_cls, mock_anthropic_cls):
        items = [
            {"item": "A", "verdict": "pass", "reason": "ok"},
            {"item": "B", "verdict": "fail", "reason": "missing"},
            {"item": "C", "verdict": "pass", "reason": "ok"},
            {"item": "D", "verdict": "fail", "reason": "missing"},
        ]
        mock_browser_cls.return_value.__aenter__ = AsyncMock(
            return_value=MagicMock(observe=AsyncMock(return_value=_make_obs()))
        )
        mock_browser_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        mock_anthropic_cls.return_value.messages.create.return_value = (
            _make_judge_response(items)
        )

        result = self._run(
            screenshot_and_judge(["A", "B", "C", "D"], "http://x")
        )
        assert result["score"] == pytest.approx(50.0)

    def test_empty_checklist_returns_zero(self):
        result = self._run(screenshot_and_judge([], "http://x"))
        assert result["score"] == 0.0
        assert result["results"] == []
        assert result["screenshot_b64"] == ""

    @patch("mcp_server.testing_agent.screenshot_judge.anthropic.Anthropic")
    @patch("mcp_server.testing_agent.screenshot_judge.BrowserSession")
    def test_normalises_unexpected_verdict_to_fail(
        self, mock_browser_cls, mock_anthropic_cls
    ):
        """Verdicts that are not 'pass' must be mapped to 'fail'."""
        items = [
            {"item": "X", "verdict": "PASS", "reason": "ok"},   # uppercase
            {"item": "Y", "verdict": "maybe", "reason": "unsure"},  # unknown
        ]
        mock_browser_cls.return_value.__aenter__ = AsyncMock(
            return_value=MagicMock(observe=AsyncMock(return_value=_make_obs()))
        )
        mock_browser_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        mock_anthropic_cls.return_value.messages.create.return_value = (
            _make_judge_response(items)
        )

        result = self._run(screenshot_and_judge(["X", "Y"], "http://x"))
        verdicts = {r["item"]: r["verdict"] for r in result["results"]}
        assert verdicts["X"] == "pass"   # PASS → normalised to pass
        assert verdicts["Y"] == "fail"   # unknown → fail

    @patch("mcp_server.testing_agent.screenshot_judge.anthropic.Anthropic")
    @patch("mcp_server.testing_agent.screenshot_judge.BrowserSession")
    def test_screenshot_b64_is_returned(self, mock_browser_cls, mock_anthropic_cls):
        items = [{"item": "A", "verdict": "pass", "reason": "ok"}]
        mock_browser_cls.return_value.__aenter__ = AsyncMock(
            return_value=MagicMock(observe=AsyncMock(return_value=_make_obs("MYIMAGE")))
        )
        mock_browser_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        mock_anthropic_cls.return_value.messages.create.return_value = (
            _make_judge_response(items)
        )

        result = self._run(screenshot_and_judge(["A"], "http://x"))
        assert result["screenshot_b64"] == "MYIMAGE"
