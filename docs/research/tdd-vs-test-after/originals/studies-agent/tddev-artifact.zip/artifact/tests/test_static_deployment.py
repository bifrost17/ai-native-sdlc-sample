"""
Tests for static_html support in mcp_server/tools/deployment.py

Covers:
  1. detect_framework returns "static_html" when only .html files exist
  2. detect_framework still returns "unknown" when no html or package.json
  3. detect_framework does NOT return static_html when package.json exists
  4. start_app / stop_app work end-to-end for a static HTML file
  5. HTTP GET on the served URL returns 200
"""

import socket
import time
import urllib.request
from pathlib import Path

import pytest
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp_server.tools.deployment import (
    detect_framework,
    start_app,
    stop_app,
    _process_registry,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def is_port_open(port: int, host: str = "127.0.0.1") -> bool:
    try:
        with socket.create_connection((host, port), timeout=1):
            return True
    except OSError:
        return False


def http_get_status(url: str) -> int:
    try:
        with urllib.request.urlopen(url, timeout=5) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception:
        return -1


@pytest.fixture(autouse=True)
def cleanup_registry():
    """Ensure no leftover processes leak between tests."""
    yield
    for key in list(_process_registry.keys()):
        try:
            stop_app(key)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# detect_framework — static_html detection
# ---------------------------------------------------------------------------

class TestDetectFrameworkStaticHtml:
    def test_html_only_dir_returns_static_html(self, tmp_path):
        (tmp_path / "index.html").write_text("<html><body>Hello</body></html>")
        info = detect_framework(str(tmp_path))
        assert info["framework"] == "static_html"
        assert "python" in info["dev_command"]
        assert info["default_port"] == 8080

    def test_any_html_file_triggers_static(self, tmp_path):
        (tmp_path / "app.html").write_text("<html></html>")
        info = detect_framework(str(tmp_path))
        assert info["framework"] == "static_html"

    def test_empty_dir_returns_unknown_not_static(self, tmp_path):
        info = detect_framework(str(tmp_path))
        assert info["framework"] == "unknown"

    def test_package_json_takes_precedence_over_html(self, tmp_path):
        """If package.json exists alongside index.html, use npm-based detection."""
        (tmp_path / "index.html").write_text("<html></html>")
        (tmp_path / "package.json").write_text(
            '{"dependencies": {"express": "^4"}}'
        )
        info = detect_framework(str(tmp_path))
        assert info["framework"] == "express"

    def test_static_html_dev_command_includes_http_server(self, tmp_path):
        (tmp_path / "index.html").write_text("<html></html>")
        info = detect_framework(str(tmp_path))
        assert "http.server" in info["dev_command"]


# ---------------------------------------------------------------------------
# start_app / stop_app — integration (real subprocess)
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestStaticAppStartStop:
    """Spawns python3 -m http.server; requires python3 in PATH (always true)."""

    @pytest.fixture
    def static_dir(self, tmp_path):
        (tmp_path / "index.html").write_text(
            "<html><body><h1>Hello static</h1></body></html>"
        )
        return str(tmp_path)

    def test_start_returns_static_html_framework(self, static_dir):
        info = start_app(static_dir)
        try:
            assert info["framework"] == "static_html"
        finally:
            stop_app(static_dir)

    def test_url_is_reachable(self, static_dir):
        info = start_app(static_dir)
        try:
            status = http_get_status(info["url"])
            assert status == 200, f"Expected 200, got {status}"
        finally:
            stop_app(static_dir)

    def test_port_is_open(self, static_dir):
        info = start_app(static_dir)
        try:
            assert is_port_open(info["port"])
        finally:
            stop_app(static_dir)

    def test_stop_closes_port(self, static_dir):
        info = start_app(static_dir)
        port = info["port"]
        assert is_port_open(port)
        stop_app(static_dir)
        time.sleep(0.5)
        assert not is_port_open(port)

    def test_start_twice_returns_same_url(self, static_dir):
        info1 = start_app(static_dir)
        try:
            info2 = start_app(static_dir)
            assert info1["url"] == info2["url"]
            assert info1["port"] == info2["port"]
        finally:
            stop_app(static_dir)
