"""
Phase 2 tests for mcp_server/tools/test_generation.py

Test plan (from RESEARCH_PLAN.md §Phase 2):
- Run convert mode on one WebGen-Bench item; validate JSON schema of every
  output test case (required fields: test_id, feature, steps, expected;
  steps is a non-empty list of strings; test_id values are unique).
- Run generate mode on the same item's instruction; apply the same schema
  validation; assert the output is a non-empty list.
- No assumptions on content quality — passing = valid schema.

LLM is mocked in all tests; no real API key is required.
"""

import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp_server.tools.test_generation import generate_test_cases, _parse_test_cases


# ---------------------------------------------------------------------------
# Shared test data
# ---------------------------------------------------------------------------

REQUIREMENTS = (
    "Please implement a simple task management web app where users can "
    "register, log in, create tasks, and view their task list."
)

UI_INSTRUCT = [
    {
        "task": "Verify the user registration functionality",
        "expected_result": (
            "User account is created and the user is redirected to the dashboard"
        ),
    },
    {
        "task": "Verify the task creation functionality",
        "expected_result": "The new task appears in the task list",
    },
]

# A minimal but fully valid LLM response fixture used by most tests.
_FIXTURE_TEST_CASES = [
    {
        "test_id": "TC-01",
        "feature": "User registration",
        "steps": [
            "Navigate to the registration page",
            "Enter email 'testuser@example.com' and password 'Test@1234'",
            "Click the Register button",
        ],
        "expected": (
            "User account is created and the user is redirected to the dashboard"
        ),
    },
    {
        "test_id": "TC-02",
        "feature": "Task creation",
        "steps": [
            "Log in with email 'testuser@example.com' and password 'Test@1234'",
            "Navigate to the task creation page",
            "Enter task title 'Test Item' and click Submit",
        ],
        "expected": "The new task 'Test Item' appears in the task list",
    },
]


def _mock_llm_response(test_cases: list[dict]) -> MagicMock:
    """Build a fake Anthropic message whose text is a JSON array."""
    msg = MagicMock()
    msg.content = [MagicMock(text=json.dumps(test_cases))]
    return msg


# ---------------------------------------------------------------------------
# Helper: assert the schema of a single test case
# ---------------------------------------------------------------------------

def _assert_schema(tc: dict) -> None:
    """Raise AssertionError if *tc* violates the required test-case schema."""
    for field in ("test_id", "feature", "steps", "expected"):
        assert field in tc, f"Missing field '{field}' in: {tc}"
        assert tc[field], f"Field '{field}' is empty in: {tc}"

    assert isinstance(tc["steps"], list), \
        f"'steps' must be a list, got {type(tc['steps'])}: {tc}"
    assert len(tc["steps"]) > 0, f"'steps' must be non-empty in: {tc}"
    for step in tc["steps"]:
        assert isinstance(step, str), \
            f"Each step must be a string, got {type(step)}: {step}"


# ---------------------------------------------------------------------------
# Convert mode
# ---------------------------------------------------------------------------

@pytest.fixture()
def patched_client():
    """Patch _client() so no real Anthropic call is made."""
    mock_client = MagicMock()
    with patch("mcp_server.tools.test_generation._client", return_value=mock_client):
        yield mock_client


class TestConvertMode:

    def _run(self, patched_client, test_cases=None):
        if test_cases is None:
            test_cases = _FIXTURE_TEST_CASES
        patched_client.messages.create.return_value = _mock_llm_response(test_cases)
        return generate_test_cases(REQUIREMENTS, UI_INSTRUCT)

    def test_returns_nonempty_list(self, patched_client):
        result = self._run(patched_client)
        assert isinstance(result, list)
        assert len(result) > 0

    def test_schema_has_required_fields(self, patched_client):
        result = self._run(patched_client)
        for tc in result:
            _assert_schema(tc)

    def test_steps_is_nonempty_list_of_strings(self, patched_client):
        result = self._run(patched_client)
        for tc in result:
            assert isinstance(tc["steps"], list)
            assert len(tc["steps"]) > 0
            for step in tc["steps"]:
                assert isinstance(step, str)

    def test_test_ids_are_unique(self, patched_client):
        result = self._run(patched_client)
        ids = [tc["test_id"] for tc in result]
        assert len(ids) == len(set(ids)), f"Duplicate test_ids: {ids}"

    def test_required_fields_nonempty(self, patched_client):
        result = self._run(patched_client)
        for tc in result:
            assert tc["test_id"]
            assert tc["feature"]
            assert tc["expected"]

    def test_calls_llm_exactly_once(self, patched_client):
        self._run(patched_client)
        assert patched_client.messages.create.call_count == 1


# ---------------------------------------------------------------------------
# Generate mode
# ---------------------------------------------------------------------------

class TestGenerateMode:

    def _run(self, patched_client, test_cases=None):
        if test_cases is None:
            test_cases = _FIXTURE_TEST_CASES
        patched_client.messages.create.return_value = _mock_llm_response(test_cases)
        # No ui_instruct → generate mode
        return generate_test_cases(REQUIREMENTS)

    def test_returns_nonempty_list(self, patched_client):
        result = self._run(patched_client)
        assert isinstance(result, list)
        assert len(result) > 0

    def test_schema_has_required_fields(self, patched_client):
        result = self._run(patched_client)
        for tc in result:
            _assert_schema(tc)

    def test_steps_is_nonempty_list_of_strings(self, patched_client):
        result = self._run(patched_client)
        for tc in result:
            assert isinstance(tc["steps"], list)
            assert len(tc["steps"]) > 0
            for step in tc["steps"]:
                assert isinstance(step, str)

    def test_test_ids_are_unique(self, patched_client):
        result = self._run(patched_client)
        ids = [tc["test_id"] for tc in result]
        assert len(ids) == len(set(ids)), f"Duplicate test_ids: {ids}"

    def test_required_fields_nonempty(self, patched_client):
        result = self._run(patched_client)
        for tc in result:
            assert tc["test_id"]
            assert tc["feature"]
            assert tc["expected"]

    def test_calls_llm_exactly_once(self, patched_client):
        self._run(patched_client)
        assert patched_client.messages.create.call_count == 1


# ---------------------------------------------------------------------------
# _parse_test_cases
# ---------------------------------------------------------------------------

class TestParseTestCases:

    def test_parses_bare_json_array(self):
        text = json.dumps(_FIXTURE_TEST_CASES)
        assert _parse_test_cases(text) == _FIXTURE_TEST_CASES

    def test_parses_json_in_xml_tags(self):
        text = f"Some reasoning...\n<json>{json.dumps(_FIXTURE_TEST_CASES)}</json>"
        assert _parse_test_cases(text) == _FIXTURE_TEST_CASES

    def test_parses_json_in_markdown_fence(self):
        text = f"Here:\n```json\n{json.dumps(_FIXTURE_TEST_CASES)}\n```\nDone."
        assert _parse_test_cases(text) == _FIXTURE_TEST_CASES

    def test_parses_json_with_surrounding_prose(self):
        text = f"Test cases below:\n{json.dumps(_FIXTURE_TEST_CASES)}\nEnd."
        assert _parse_test_cases(text) == _FIXTURE_TEST_CASES

    def test_raises_on_no_json(self):
        with pytest.raises(ValueError, match="No JSON array found"):
            _parse_test_cases("There is no JSON here at all.")
