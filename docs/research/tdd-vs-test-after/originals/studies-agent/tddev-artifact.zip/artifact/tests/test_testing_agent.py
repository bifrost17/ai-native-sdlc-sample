"""
Phase 3 tests for mcp_server/testing_agent/

All tests use real LLM calls and a real Playwright browser.
Fixtures are served via Python's built-in HTTP server on a random port.

Test plan:
1. observe() returns non-empty accessibility_tree and valid base64 PNG
2. Happy path: working todo app → result == "pass", trajectory is non-empty
3. Broken app (button removed): same test case → result == "fail",
   failure_report is non-empty
4. Non-existent element: result == "fail" with meaningful failure report,
   no unhandled exception
"""

import asyncio
import base64
import os
import socket
import threading
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

import pytest

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp_server.testing_agent.browser import BrowserSession
from mcp_server.testing_agent.agent import run_test_case

# ---------------------------------------------------------------------------
# Ensure ANTHROPIC_API_KEY is available
# ---------------------------------------------------------------------------

# ANTHROPIC_API_KEY must be set in the environment before running these tests.

FIXTURES = Path(__file__).parent / "fixtures"


# ---------------------------------------------------------------------------
# HTTP fixture server helpers
# ---------------------------------------------------------------------------

def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class _SilentHandler(SimpleHTTPRequestHandler):
    """Suppress log output during tests."""
    def log_message(self, *args):
        pass


def _serve(directory: Path):
    """
    Start an HTTP server in a daemon thread serving *directory*.

    Returns (url, server) — call server.shutdown() to stop.
    """
    port = _free_port()
    handler = lambda *a, **kw: _SilentHandler(*a, directory=str(directory), **kw)
    server = HTTPServer(("127.0.0.1", port), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return f"http://127.0.0.1:{port}", server


# ---------------------------------------------------------------------------
# Pytest fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def todo_app_url():
    url, server = _serve(FIXTURES / "todo_app")
    yield url
    server.shutdown()


@pytest.fixture(scope="module")
def todo_app_broken_url():
    url, server = _serve(FIXTURES / "todo_app_broken")
    yield url
    server.shutdown()


# ---------------------------------------------------------------------------
# Reusable test cases
# ---------------------------------------------------------------------------

TODO_TEST_CASE = {
    "test_id": "TC-01",
    "feature": "User can add a task",
    "steps": [
        "Fill the task input with 'Buy milk'",
        "Click the Add button",
    ],
    "expected": "'Buy milk' appears in the task list",
}

NONEXISTENT_ELEMENT_TEST_CASE = {
    "test_id": "TC-X1",
    "feature": "Purple dragon button",
    "steps": [
        "Click the purple dragon button",
    ],
    "expected": "Purple dragon message is shown",
}


# ---------------------------------------------------------------------------
# Helper to run async functions in sync tests
# ---------------------------------------------------------------------------

def _run(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


# ---------------------------------------------------------------------------
# Test 1: observe() returns valid data
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestObserve:
    def test_accessibility_tree_is_nonempty(self, todo_app_url):
        async def _go():
            async with BrowserSession(todo_app_url) as session:
                obs = await session.observe()
                return obs
        obs = _run(_go())
        assert "accessibility_tree" in obs
        assert isinstance(obs["accessibility_tree"], str)
        assert len(obs["accessibility_tree"]) > 10, "accessibility_tree should not be empty"

    def test_screenshot_is_valid_base64_png(self, todo_app_url):
        async def _go():
            async with BrowserSession(todo_app_url) as session:
                obs = await session.observe()
                return obs
        obs = _run(_go())
        assert "screenshot" in obs
        # Must be valid base64
        raw = base64.b64decode(obs["screenshot"])
        # PNG magic bytes: \x89PNG
        assert raw[:4] == b"\x89PNG", "Screenshot is not a valid PNG"


# ---------------------------------------------------------------------------
# Test 2: Happy path — working todo app → pass
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestHappyPath:
    def test_result_is_pass(self, todo_app_url):
        result = _run(run_test_case(TODO_TEST_CASE, todo_app_url))
        assert result["result"] == "pass", (
            f"Expected 'pass' but got {result['result']!r}. "
            f"Failure report: {result['failure_report']}"
        )

    def test_trajectory_is_nonempty(self, todo_app_url):
        result = _run(run_test_case(TODO_TEST_CASE, todo_app_url))
        assert len(result["trajectory"]) >= 1, (
            "Trajectory should have at least one entry on pass"
        )

    def test_trajectory_entries_have_required_keys(self, todo_app_url):
        result = _run(run_test_case(TODO_TEST_CASE, todo_app_url))
        for entry in result["trajectory"]:
            assert "step" in entry, "Trajectory entry missing 'step' key"
            assert "action" in entry, "Trajectory entry missing 'action' key"
            assert "status" in entry, "Trajectory entry missing 'status' key"
            assert entry["status"] in ("executed", "failed")


# ---------------------------------------------------------------------------
# Test 3: Broken app — button removed → fail
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestBrokenApp:
    def test_result_is_fail_with_report(self, todo_app_broken_url):
        result = _run(run_test_case(TODO_TEST_CASE, todo_app_broken_url))
        assert result["result"] in ("fail", "partial"), (
            f"Expected 'fail' or 'partial' but got {result['result']!r}"
        )
        assert result["failure_report"], "failure_report should be non-empty on failure"


# ---------------------------------------------------------------------------
# Test 4: Non-existent element → fail, no unhandled exception
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestNonexistentElement:
    def test_result_is_fail(self, todo_app_url):
        result = _run(run_test_case(NONEXISTENT_ELEMENT_TEST_CASE, todo_app_url))
        assert result["result"] == "fail", (
            f"Expected 'fail' for nonexistent element, got {result['result']!r}"
        )

    def test_failure_report_is_nonempty(self, todo_app_url):
        result = _run(run_test_case(NONEXISTENT_ELEMENT_TEST_CASE, todo_app_url))
        assert result["failure_report"], (
            "failure_report should be non-empty for nonexistent element"
        )

    def test_no_unhandled_exception(self, todo_app_url):
        # Passing if run_test_case completes without raising
        result = _run(run_test_case(NONEXISTENT_ELEMENT_TEST_CASE, todo_app_url))
        assert isinstance(result, dict)
        assert "result" in result
        assert "trajectory" in result
        assert "failure_report" in result
