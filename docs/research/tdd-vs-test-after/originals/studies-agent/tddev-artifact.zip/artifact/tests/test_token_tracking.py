"""
Unit tests for experiment.token_tracking.
"""

from experiment.token_tracking import reset, record, get_totals, get_entries


class TestTokenTracking:
    """Tests for the module-level token accumulator."""

    def setup_method(self):
        reset()

    def test_empty_after_reset(self):
        assert get_totals() == {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
        assert get_entries() == []

    def test_single_record(self):
        record("grounding", input_tokens=100, output_tokens=20, model="test-model")
        totals = get_totals()
        assert totals["input_tokens"] == 100
        assert totals["output_tokens"] == 20
        assert totals["total_tokens"] == 120

    def test_multiple_records_accumulate(self):
        record("grounding", 100, 20, "m1")
        record("verification", 200, 10, "m1")
        record("generation", 500, 100, "m2")
        totals = get_totals()
        assert totals["input_tokens"] == 800
        assert totals["output_tokens"] == 130
        assert totals["total_tokens"] == 930

    def test_reset_clears_entries(self):
        record("grounding", 100, 20)
        assert get_totals()["total_tokens"] == 120
        reset()
        assert get_totals()["total_tokens"] == 0
        assert get_entries() == []

    def test_get_entries_returns_copy(self):
        record("grounding", 100, 20, "m1")
        entries = get_entries()
        assert len(entries) == 1
        assert entries[0]["phase"] == "grounding"
        assert entries[0]["input_tokens"] == 100
        # Mutating the returned list should not affect the accumulator
        entries.clear()
        assert len(get_entries()) == 1

    def test_entries_preserve_phase_and_model(self):
        record("judge", 300, 50, "claude-sonnet-4-6")
        entry = get_entries()[0]
        assert entry["phase"] == "judge"
        assert entry["model"] == "claude-sonnet-4-6"

    def test_model_defaults_to_empty(self):
        record("grounding", 10, 5)
        assert get_entries()[0]["model"] == ""
